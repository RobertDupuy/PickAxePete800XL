# Pick Axe Pete — Atari 800XL 64K development prototype

**UNFINISHED. This is not the requested exact replica or a release-quality port.**

The original 4 KB cartridge and 1 KB Odyssey BIOS were loaded and disassembled. The reachable 8048 instruction paths were translated ahead of time to native NMOS 6502 code. This is not a runtime 8048 interpreter. The code uses translated registers and hardware service routines, so it is also not a hand-optimized Atari game engine.

## Current architecture

- The loader disables interrupts and DMA, writes `$FE` to PORTB `$D301`, disables the OS and BASIC mappings, and copies resident platform code under the OS ROM.
- Custom NMI and IRQ vectors are installed at `$FFFA` and `$FFFE`. No Atari OS VBI service runs.
- Game logic runs in the foreground. There is now one ANTIC 4 character playfield, not two full-screen bitmaps. Foreground graphics preparation constructs a list of changed glyph and character-map stores. VBI executes that list and updates PMG. DLIs set character banks and playfield colors.
- The extra wait for an entire scanout before preparing another screen has been removed. The foreground still waits for its pending display update to be committed at VBI.
- The static mine map is rebuilt with display DMA stopped during scene setup. Ordinary updates use the changed-cell list.
- All four Odyssey sprites map directly to GTIA players P0–P3. PMBASE is `$C8`; player data occupy `$CC00`–`$CFFF`. Missiles are unused.
- P0PL–P3PL and P0PF–P3PF supply the principal collision path. Software pixel tests remain for characters sharing PF0 with the grid.
- Six BIOS square-wave patterns use POKEY joined-channel tones. Noise uses a timer IRQ. Sound equivalence has not been established.

## Confirmed checks and failed performance target

The current game build assembles and runs in Atari800 configured as an NTSC 800XL with 64 KB. The diagnostic produces collision flags `05 81 00 81 00` for five contact cases. The same-color case also latched PF1 in the latest run, so it does not independently isolate the PF0 software fallback.

In the latest 120-frame gameplay sample, the game entered its frame-wait routine only 28 times, approximately 14 updates per second. The foreground still fails the required one-tick-per-frame budget. Do not interpret this as a hardware limitation.

For 27 sampled display commits, time between `nmi_vblank` and `nmi_retain` was 1,106–2,730 Atari clock cycles. This excludes the common NMI entry/exit and final palette setup. It supports the small-update design; it is not a worst-case timing proof for all scenes. One update-queue overflow was observed during setup. `docs/validation.json` and `build/timing.json` record these results.

## Outstanding work

The expensive foreground object conversion, palette rebuilding and translated 8048 register operations still need replacement or simplification. Removing screen double buffering did not by itself fix the port. The original 8048 state must be checked against the translated program, not merely against screenshots.

Known correctness gaps include: the raster-wait stub omits original register/control side effects; the original timer-based randomness is replaced by POKEY RANDOM; exact timing is not reproduced; some palette combinations exceed the selected band's color capacity; half-pixel shifts and double-sized sprites are incomplete; grid collision category bits and collision/frame ordering are incomplete or unverified. Exhaustive differential game-state, sound, scoring, death/restart, all-layout and real-machine validation remain undone.

The `experiments/` directory and archived renderer sources retain earlier failed approaches. They are not release implementations.

## Running the diagnostic game build

Load `build/PickAxePete-64K.xex` with an Atari binary loader, using an NTSC 800XL with 64 KB and BASIC disabled. Select a mine with digit 0–9. Use joystick port 1 and its fire button. This build is for development inspection only.

## Building

Python 3 and cc65's ca65/ld65 are required. Linux x86-64 assembler binaries from the pinned cc65 revision are included. Alternatively set `CC65_BIN` to your own cc65 binary directory.

```sh
python3 tools/disassemble.py
python3 tools/translate.py
python3 tools/assets.py
python3 tools/build.py
```

The linear disassemblies include data interpreted as opcodes; consult `build/reachable.json` for the compiler's reachable instruction set. Generated 6502 code is `src/game_generated.s`.

To build the GTIA test program, set `PETE_HARDWARE_TEST=1` when invoking `tools/build.py`. After running about 600 emulated frames, RAM `$7FCF` should equal `$A5`, and `$7FC0..$7FC4` should contain `05 81 00 81 00`. Rebuild without the environment variable to restore the game executable.

## Source provenance

- Cartridge: https://archive.org/download/PickAxePete-MagnavoxOdyssey2/PickAxePete.bin
- Odyssey BIOS: https://raw.githubusercontent.com/Abdess/retrobios/main/bios/Magnavox/Odyssey2/o2rom.bin
- O2EM: https://github.com/libretro/libretro-o2em at `679d6fec04963f6e70a7ec217e3d0ebb1fe472fc`.
- Atari800 libretro: https://github.com/libretro/libretro-atari800 at `4e7fbc73765c1a9670c7506616046ad1d4ccda51`.
- cc65: https://github.com/cc65/cc65 at `8d86ca7e7ed15300cc4bfaba61a40a3d00f3114d`.

ROM checksums, reference screenshots, disassemblies, source attribution, and emulator instrumentation patches are included. Original game/BIOS material retains its original ownership; third-party tooling licenses are in `licenses/`.
