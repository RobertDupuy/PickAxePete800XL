000: 8400  JMP $400
002: 00    NOP
003: 8402  JMP $402
005: 00    NOP
006: 00    NOP
007: 8404  JMP $404
009: c5    SEL RB0
00a: ad    MOV R5,A
00b: 09    IN A,P1
00c: ae    MOV R6,A
00d: 14e7  CALL $0e7
00f: b8a1  MOV R0, #$a1
011: 80    MOVX A,@R0
012: 7218  JB3 $018
014: fe    MOV A,R6
015: 39    OUTL P1,A
016: fd    MOV A,R5
017: 93    RETR
018: 8406  JMP $406
01a: a5    CLR F1
01b: b5    CPL F1
01c: b9a2  MOV R1, #$a2
01e: b83d  MOV R0, #$3d
020: 81    MOVX A,@R1
021: a0    MOV @R0,A
022: 18    INC R0
023: 10    INC @R0
024: f0    MOV A,@R0
025: 533f  ANL A, #$3f
027: d33c  XRL A, #$3c
029: 962f  JNZ $02f
02b: f0    MOV A,@R0
02c: 53c0  ANL A, #$c0
02e: a0    MOV @R0,A
02f: 18    INC R0
030: f0    MOV A,@R0
031: 37    CPL A
032: f23a  JB7 $03a
034: 37    CPL A
035: 537f  ANL A, #$7f
037: a0    MOV @R0,A
038: 1489  CALL $089
03a: b93f  MOV R1, #$3f
03c: f1    MOV A,@R1
03d: 37    CPL A
03e: d214  JB6 $014
040: eb14  DJNZ R3, $014
042: 840a  JMP $40a
044: fc    MOV A,R4
045: e3    MOVP3 A,@A
046: a9    MOV R1,A
047: 1c    INC R4
048: fc    MOV A,R4
049: e3    MOVP3 A,@A
04a: aa    MOV R2,A
04b: f9    MOV A,R1
04c: f25c  JB7 $05c
04e: d273  JB6 $073
050: b27d  JB5 $07d
052: 9284  JB4 $084
054: b93f  MOV R1, #$3f
056: f1    MOV A,@R1
057: 53bf  ANL A, #$bf
059: a1    MOV @R1,A
05a: 0414  JMP $014
05c: 537f  ANL A, #$7f
05e: ab    MOV R3,A
05f: b8aa  MOV R0, #$aa
061: 27    CLR A
062: 90    MOVX @R0,A
063: b8a7  MOV R0, #$a7
065: b903  MOV R1, #$03
067: fa    MOV A,R2
068: e3    MOVP3 A,@A
069: 90    MOVX @R0,A
06a: 18    INC R0
06b: 1a    INC R2
06c: e967  DJNZ R1, $067
06e: fa    MOV A,R2
06f: e3    MOVP3 A,@A
070: aa    MOV R2,A
071: 0476  JMP $076
073: 533f  ANL A, #$3f
075: ab    MOV R3,A
076: 1c    INC R4
077: b8aa  MOV R0, #$aa
079: fa    MOV A,R2
07a: 90    MOVX @R0,A
07b: 0414  JMP $014
07d: 531f  ANL A, #$1f
07f: ab    MOV R3,A
080: ba00  MOV R2, #$00
082: 0477  JMP $077
084: fa    MOV A,R2
085: ac    MOV R4,A
086: 840a  JMP $40a
088: 00    NOP
089: b87f  MOV R0, #$7f
08b: b9a0  MOV R1, #$a0
08d: 81    MOVX A,@R1
08e: 53d6  ANL A, #$d6
090: 91    MOVX @R1,A
091: 897c  ORL P1, #$7c
093: 99e7  ANL P1, #$e7
095: 80    MOVX A,@R0
096: 96a3  JNZ $0a3
098: 89bc  ORL P1, #$bc
09a: 99b7  ANL P1, #$b7
09c: b9a0  MOV R1, #$a0
09e: 81    MOVX A,@R1
09f: 4328  ORL A, #$28
0a1: 91    MOVX @R1,A
0a2: 83    RET
0a3: aa    MOV R2,A
0a4: c8    DEC R0
0a5: 80    MOVX A,@R0
0a6: a9    MOV R1,A
0a7: c8    DEC R0
0a8: 80    MOVX A,@R0
0a9: 91    MOVX @R1,A
0aa: c8    DEC R0
0ab: 19    INC R1
0ac: eaa8  DJNZ R2, $0a8
0ae: 0495  JMP $095
0b0: 15    DIS I
0b1: c5    SEL RB0
0b2: 09    IN A,P1
0b3: ae    MOV R6,A
0b4: 89bc  ORL P1, #$bc
0b6: 99bb  ANL P1, #$bb
0b8: b8f0  MOV R0, #$f0
0ba: ba06  MOV R2, #$06
0bc: f8    MOV A,R0
0bd: 3a    OUTL P2,A
0be: 0a    IN A,P2
0bf: 92da  JB4 $0da
0c1: ba30  MOV R2, #$30
0c3: a8    MOV R0,A
0c4: 0a    IN A,P2
0c5: d8    XRL A,R0
0c6: 96df  JNZ $0df
0c8: eac4  DJNZ R2, $0c4
0ca: f8    MOV A,R0
0cb: 47    SWAP
0cc: 77    RR A
0cd: d307  XRL A, #$07
0cf: 533f  ANL A, #$3f
0d1: a9    MOV R1,A
0d2: ff    MOV A,R7
0d3: 533f  ANL A, #$3f
0d5: d9    XRL A,R1
0d6: 96e5  JNZ $0e5
0d8: 04df  JMP $0df
0da: 18    INC R0
0db: eabc  DJNZ R2, $0bc
0dd: bfff  MOV R7, #$ff
0df: ff    MOV A,R7
0e0: 43c0  ORL A, #$c0
0e2: af    MOV R7,A
0e3: 6478  JMP $378
0e5: 6476  JMP $376
0e7: 89bc  ORL P1, #$bc
0e9: 99b7  ANL P1, #$b7
0eb: 83    RET
0ec: 89bc  ORL P1, #$bc
0ee: 99af  ANL P1, #$af
0f0: 83    RET
0f1: 89bc  ORL P1, #$bc
0f3: 99b7  ANL P1, #$b7
0f5: 2320  MOV A, #$20
0f7: a8    MOV R0,A
0f8: a9    MOV R1,A
0f9: 27    CLR A
0fa: a0    MOV @R0,A
0fb: 18    INC R0
0fc: e9fa  DJNZ R1, $0fa
0fe: 14ec  CALL $0ec
100: b9ff  MOV R1, #$ff
102: 91    MOVX @R1,A
103: e902  DJNZ R1, $102
105: 91    MOVX @R1,A
106: 14e7  CALL $0e7
108: 341c  CALL $11c
10a: b8ff  MOV R0, #$ff
10c: b980  MOV R1, #$80
10e: 27    CLR A
10f: 90    MOVX @R0,A
110: c8    DEC R0
111: e90f  DJNZ R1, $10f
113: 23f8  MOV A, #$f8
115: 90    MOVX @R0,A
116: e815  DJNZ R0, $115
118: 90    MOVX @R0,A
119: 3427  CALL $127
11b: 83    RET
11c: 15    DIS I
11d: c5    SEL RB0
11e: b8a0  MOV R0, #$a0
120: 80    MOVX A,@R0
121: 53d6  ANL A, #$d6
123: 90    MOVX @R0,A
124: d5    SEL RB1
125: 05    EN I
126: 83    RET
127: 15    DIS I
128: c5    SEL RB0
129: b8a0  MOV R0, #$a0
12b: 80    MOVX A,@R0
12c: 4328  ORL A, #$28
12e: 90    MOVX @R0,A
12f: d5    SEL RB1
130: 05    EN I
131: 83    RET
132: 27    CLR A
133: 90    MOVX @R0,A
134: b83f  MOV R0, #$3f
136: f0    MOV A,@R0
137: 4380  ORL A, #$80
139: a0    MOV @R0,A
13a: 14e7  CALL $0e7
13c: 83    RET
13d: 3476  CALL $176
13f: 14b0  CALL $0b0
141: f23d  JB7 $13d
143: 2356  MOV A, #$56
145: 34a2  CALL $1a2
147: c5    SEL RB0
148: ff    MOV A,R7
149: d5    SEL RB1
14a: 83    RET
14b: fe    MOV A,R6
14c: 53fe  ANL A, #$fe
14e: ae    MOV R6,A
14f: fd    MOV A,R5
150: 97    CLR C
151: f7    RLC A
152: f7    RLC A
153: f7    RLC A
154: ad    MOV R5,A
155: 27    CLR A
156: f7    RLC A
157: 4e    ORL A,R6
158: ae    MOV R6,A
159: fc    MOV A,R4
15a: 67    RRC A
15b: 37    CPL A
15c: 17    INC A
15d: 6d    ADD A,R5
15e: ad    MOV R5,A
15f: f66a  JC $16a
161: fe    MOV A,R6
162: 37    CPL A
163: 5301  ANL A, #$01
165: 2e    XCH A,R6
166: 53fe  ANL A, #$fe
168: 4e    ORL A,R6
169: ae    MOV R6,A
16a: 83    RET
16b: 23f8  MOV A, #$f8
16d: b810  MOV R0, #$10
16f: ba30  MOV R2, #$30
171: 90    MOVX @R0,A
172: 18    INC R0
173: ea71  DJNZ R2, $171
175: 83    RET
176: a5    CLR F1
177: 05    EN I
178: 7675  JF1 $175
17a: 2478  JMP $178
17c: 14ec  CALL $0ec
17e: aa    MOV R2,A
17f: b87f  MOV R0, #$7f
181: 2308  MOV A, #$08
183: 90    MOVX @R0,A
184: c8    DEC R0
185: f9    MOV A,R1
186: 90    MOVX @R0,A
187: c8    DEC R0
188: fa    MOV A,R2
189: 47    SWAP
18a: 530f  ANL A, #$0f
18c: ad    MOV R5,A
18d: 3497  CALL $197
18f: fa    MOV A,R2
190: 530f  ANL A, #$0f
192: ad    MOV R5,A
193: 3497  CALL $197
195: 2432  JMP $132
197: fc    MOV A,R4
198: 90    MOVX @R0,A
199: c8    DEC R0
19a: fb    MOV A,R3
19b: 90    MOVX @R0,A
19c: c8    DEC R0
19d: 0308  ADD A, #$08
19f: ab    MOV R3,A
1a0: 442c  JMP $22c
1a2: 15    DIS I
1a3: c5    SEL RB0
1a4: ac    MOV R4,A
1a5: bb01  MOV R3, #$01
1a7: b83f  MOV R0, #$3f
1a9: f0    MOV A,@R0
1aa: 4340  ORL A, #$40
1ac: a0    MOV @R0,A
1ad: d5    SEL RB1
1ae: 05    EN I
1af: 83    RET
1b0: b83e  MOV R0, #$3e
1b2: f0    MOV A,@R0
1b3: f23a  JB7 $13a
1b5: 533f  ANL A, #$3f
1b7: d33b  XRL A, #$3b
1b9: 963a  JNZ $13a
1bb: 14ec  CALL $0ec
1bd: f0    MOV A,@R0
1be: b802  MOV R0, #$02
1c0: b901  MOV R1, #$01
1c2: d2e2  JB6 $1e2
1c4: ba99  MOV R2, #$99
1c6: 80    MOVX A,@R0
1c7: c6ce  JZ $1ce
1c9: 6a    ADD A,R2
1ca: 57    ILL
1cb: 90    MOVX @R0,A
1cc: 24fc  JMP $1fc
1ce: 81    MOVX A,@R1
1cf: c6da  JZ $1da
1d1: 2359  MOV A, #$59
1d3: 90    MOVX @R0,A
1d4: 81    MOVX A,@R1
1d5: 6a    ADD A,R2
1d6: 57    ILL
1d7: 91    MOVX @R1,A
1d8: 24fc  JMP $1fc
1da: b83e  MOV R0, #$3e
1dc: f0    MOV A,@R0
1dd: 4380  ORL A, #$80
1df: a0    MOV @R0,A
1e0: 243a  JMP $13a
1e2: ba01  MOV R2, #$01
1e4: 80    MOVX A,@R0
1e5: d359  XRL A, #$59
1e7: c6ef  JZ $1ef
1e9: 80    MOVX A,@R0
1ea: 6a    ADD A,R2
1eb: 57    ILL
1ec: 90    MOVX @R0,A
1ed: 24fc  JMP $1fc
1ef: 90    MOVX @R0,A
1f0: 81    MOVX A,@R1
1f1: d359  XRL A, #$59
1f3: 96f8  JNZ $1f8
1f5: 91    MOVX @R1,A
1f6: 24fc  JMP $1fc
1f8: 81    MOVX A,@R1
1f9: 6a    ADD A,R2
1fa: 57    ILL
1fb: 91    MOVX @R1,A
1fc: b87f  MOV R0, #$7f
1fe: 5435  CALL $235
200: 2342  MOV A, #$42
202: 90    MOVX @R0,A
203: c8    DEC R0
204: b901  MOV R1, #$01
206: 81    MOVX A,@R1
207: 47    SWAP
208: 5429  CALL $229
20a: 5435  CALL $235
20c: 2352  MOV A, #$52
20e: 90    MOVX @R0,A
20f: c8    DEC R0
210: 81    MOVX A,@R1
211: 5429  CALL $229
213: 5435  CALL $235
215: 2356  MOV A, #$56
217: 90    MOVX @R0,A
218: c8    DEC R0
219: 19    INC R1
21a: 81    MOVX A,@R1
21b: 47    SWAP
21c: 5429  CALL $229
21e: 5435  CALL $235
220: 234a  MOV A, #$4a
222: 90    MOVX @R0,A
223: c8    DEC R0
224: 81    MOVX A,@R1
225: 5429  CALL $229
227: 2432  JMP $132
229: 530f  ANL A, #$0f
22b: ad    MOV R5,A
22c: 344b  CALL $14b
22e: fd    MOV A,R5
22f: 90    MOVX @R0,A
230: c8    DEC R0
231: fe    MOV A,R6
232: 90    MOVX @R0,A
233: c8    DEC R0
234: 83    RET
235: 2302  MOV A, #$02
237: 90    MOVX @R0,A
238: c8    DEC R0
239: 83    RET
23a: b840  MOV R0, #$40
23c: b950  MOV R1, #$50
23e: fc    MOV A,R4
23f: 90    MOVX @R0,A
240: 91    MOVX @R1,A
241: 18    INC R0
242: 19    INC R1
243: fb    MOV A,R3
244: 90    MOVX @R0,A
245: 0308  ADD A, #$08
247: 91    MOVX @R1,A
248: bd0a  MOV R5, #$0a
24a: b846  MOV R0, #$46
24c: 5461  CALL $261
24e: bd0c  MOV R5, #$0c
250: b84e  MOV R0, #$4e
252: 5461  CALL $261
254: bd0c  MOV R5, #$0c
256: b85a  MOV R0, #$5a
258: 5461  CALL $261
25a: bd0c  MOV R5, #$0c
25c: b85e  MOV R0, #$5e
25e: 5461  CALL $261
260: 83    RET
261: 344b  CALL $14b
263: fd    MOV A,R5
264: 90    MOVX @R0,A
265: 18    INC R0
266: fe    MOV A,R6
267: 90    MOVX @R0,A
268: 18    INC R0
269: 83    RET
26a: 07    DEC A
26b: baf8  MOV R2, #$f8
26d: 6a    ADD A,R2
26e: c9    DEC R1
26f: f66d  JC $26d
271: 6a    ADD A,R2
272: 5307  ANL A, #$07
274: 17    INC A
275: aa    MOV R2,A
276: 27    CLR A
277: 97    CLR C
278: a7    CPL C
279: f7    RLC A
27a: ea79  DJNZ R2, $279
27c: aa    MOV R2,A
27d: 81    MOVX A,@R1
27e: 5a    ANL A,R2
27f: 83    RET
280: 546a  CALL $26a
282: c689  JZ $289
284: 81    MOVX A,@R1
285: da    XRL A,R2
286: 91    MOVX @R1,A
287: 27    CLR A
288: 17    INC A
289: 83    RET
28a: 546a  CALL $26a
28c: 9692  JNZ $292
28e: 81    MOVX A,@R1
28f: da    XRL A,R2
290: 91    MOVX @R1,A
291: 27    CLR A
292: 83    RET
293: 42    MOV A,T
294: ac    MOV R4,A
295: 530f  ANL A, #$0f
297: ad    MOV R5,A
298: 54a4  CALL $2a4
29a: 2a    XCH A,R2
29b: af    MOV R7,A
29c: fc    MOV A,R4
29d: 53f0  ANL A, #$f0
29f: 47    SWAP
2a0: ad    MOV R5,A
2a1: 54a4  CALL $2a4
2a3: 83    RET
2a4: fd    MOV A,R5
2a5: 03b3  ADD A, #$b3
2a7: a3    MOVP A,@A
2a8: 96ac  JNZ $2ac
2aa: ad    MOV R5,A
2ab: cd    DEC R5
2ac: 1d    INC R5
2ad: ab    MOV R3,A
2ae: 6f    ADD A,R7
2af: f6a4  JC $2a4
2b1: fb    MOV A,R3
2b2: 83    RET
2b3: 0f    MOVD A,P7
2b4: 0e    MOVD A,P6
2b5: 0d    MOVD A,P5
2b6: 02    OUTL BUS,A
2b7: 0a    IN A,P2
2b8: 05    EN I
2b9: 0b    ILL
2ba: 0306  ADD A, #$06
2bc: 0c    MOVD A,P4
2bd: 09    IN A,P1
2be: 01    ILL
2bf: 0408  JMP $008
2c1: 07    DEC A
2c2: 00    NOP
2c3: bfff  MOV R7, #$ff
2c5: d5    SEL RB1
2c6: 14f1  CALL $0f1
2c8: b9f2  MOV R1, #$f2
2ca: b810  MOV R0, #$10
2cc: ba0b  MOV R2, #$0b
2ce: bb28  MOV R3, #$28
2d0: bc70  MOV R4, #$70
2d2: be04  MOV R6, #$04
2d4: 341c  CALL $11c
2d6: f9    MOV A,R1
2d7: a3    MOVP A,@A
2d8: ad    MOV R5,A
2d9: 74ea  CALL $3ea
2db: 19    INC R1
2dc: 1e    INC R6
2dd: 1e    INC R6
2de: ead6  DJNZ R2, $2d6
2e0: 3427  CALL $127
2e2: 234a  MOV A, #$4a
2e4: 34a2  CALL $1a2
2e6: 343d  CALL $13d
2e8: a9    MOV R1,A
2e9: 341c  CALL $11c
2eb: 346b  CALL $16b
2ed: 3427  CALL $127
2ef: f9    MOV A,R1
2f0: 8408  JMP $408
2f2: 19    INC R1
2f3: 120e  JB0 $20e
2f5: 1223  JB0 $223
2f7: 140c  CALL $00c
2f9: 1c    INC R4
2fa: 20    XCH A,@R0
2fb: 2612  JNT0 $212
2fd: 20    XCH A,@R0
2fe: 20    XCH A,@R0
2ff: 20    XCH A,@R0
300: 00    NOP
301: 0f    MOVD A,P7
302: ff    MOV A,R7
303: cf    DEC R7
304: 03f0  ADD A, #$f0
306: 3f    MOVD P7,A
307: cf    DEC R7
308: 0f    MOVD A,P7
309: 0f    MOVD A,P7
30a: 0f    MOVD A,P7
30b: cf    DEC R7
30c: 1c    INC R4
30d: 71    ADDC A,@R1
30e: c7    MOV A,PSW
30f: cf    DEC R7
310: 33    ILL
311: 33    ILL
312: 33    ILL
313: cf    DEC R7
314: 03f0  ADD A, #$f0
316: 3f    MOVD P7,A
317: ef0f  DJNZ R7, $30f
319: 0f    MOVD A,P7
31a: 0f    MOVD A,P7
31b: ef1c  DJNZ R7, $31c
31d: 71    ADDC A,@R1
31e: c7    MOV A,PSW
31f: ef33  DJNZ R7, $333
321: 33    ILL
322: 33    ILL
323: ef55  DJNZ R7, $355
325: 55    STRT T
326: 55    STRT T
327: ef90  DJNZ R7, $390
329: 10    INC @R0
32a: 9400  CALL $400
32c: 21    XCH A,@R1
32d: 00    NOP
32e: 56df  JT1 $3df
330: 53dd  ANL A, #$dd
332: 50    ANL A,@R0
333: da    XRL A,R2
334: 4d    ORL A,R5
335: d8    XRL A,R0
336: 4a    ORL A,R2
337: d5    SEL RB1
338: 47    SWAP
339: d221  JB6 $321
33b: 00    NOP
33c: 9220  JB4 $320
33e: 4a    ORL A,R2
33f: cd    DEC R5
340: 52eb  JB2 $3eb
342: 4a    ORL A,R2
343: c9    DEC R1
344: 52e7  JB2 $3e7
346: 4a    ORL A,R2
347: c5    SEL RB0
348: 21    XCH A,@R1
349: 00    NOP
34a: 85    CLR F0
34b: 0485  JMP $085
34d: 0c    MOVD A,P4
34e: 85    CLR F0
34f: 1485  CALL $085
351: 1c    INC R4
352: 85    CLR F0
353: 2421  JMP $121
355: 00    NOP
356: 82    ILL
357: 1c    INC R4
358: 21    XCH A,@R1
359: 00    NOP
35a: 8a00  ORL P2, #$00
35c: 21    XCH A,@R1
35d: 00    NOP
35e: 85    CLR F0
35f: 2485  JMP $185
361: 1c    INC R4
362: 85    CLR F0
363: 1485  CALL $085
365: 0c    MOVD A,P4
366: 85    CLR F0
367: 0421  JMP $021
369: 00    NOP
36a: 44ff  JMP $2ff
36c: 4d    ORL A,R5
36d: dd    XRL A,R5
36e: 48    ORL A,R0
36f: da    XRL A,R2
370: 44d5  JMP $2d5
372: 42    MOV A,T
373: d321  XRL A, #$21
375: 00    NOP
376: f9    MOV A,R1
377: af    MOV R7,A
378: fe    MOV A,R6
379: 39    OUTL P1,A
37a: ff    MOV A,R7
37b: d5    SEL RB1
37c: 05    EN I
37d: 83    RET
37e: 20    XCH A,@R0
37f: 99fe  ANL P1, #$fe
381: 8408  JMP $408
383: 99fd  ANL P1, #$fd
385: 8408  JMP $408
387: 99fc  ANL P1, #$fc
389: 8408  JMP $408
38b: 8903  ORL P1, #$03
38d: 8408  JMP $408
38f: 09    IN A,P1
390: a8    MOV R0,A
391: 89bc  ORL P1, #$bc
393: 999b  ANL P1, #$9b
395: f9    MOV A,R1
396: 43f0  ORL A, #$f0
398: 3a    OUTL P2,A
399: 85    CLR F0
39a: 27    CLR A
39b: aa    MOV R2,A
39c: ab    MOV R3,A
39d: 08    INS A,BUS
39e: a9    MOV R1,A
39f: 12a2  JB0 $3a2
3a1: cb    DEC R3
3a2: 32a5  JB1 $3a5
3a4: 1a    INC R2
3a5: 52a8  JB2 $3a8
3a7: 1b    INC R3
3a8: 72ab  JB3 $3ab
3aa: ca    DEC R2
3ab: 92ae  JB4 $3ae
3ad: 95    CPL F0
3ae: f8    MOV A,R0
3af: 39    OUTL P1,A
3b0: 83    RET
3b1: fb    MOV A,R3
3b2: 530f  ANL A, #$0f
3b4: a8    MOV R0,A
3b5: fa    MOV A,R2
3b6: 530f  ANL A, #$0f
3b8: 47    SWAP
3b9: 48    ORL A,R0
3ba: a8    MOV R0,A
3bb: b907  MOV R1, #$07
3bd: 23c7  MOV A, #$c7
3bf: 69    ADD A,R1
3c0: a3    MOVP A,@A
3c1: d8    XRL A,R0
3c2: c6c6  JZ $3c6
3c4: e9bd  DJNZ R1, $3bd
3c6: 83    RET
3c7: 10    INC @R0
3c8: 1f    INC R7
3c9: 0f    MOVD A,P7
3ca: ff    MOV A,R7
3cb: f0    MOV A,@R0
3cc: f1    MOV A,@R1
3cd: 01    ILL
3ce: 11    INC @R1
3cf: bcff  MOV R4, #$ff
3d1: fb    MOV A,R3
3d2: 37    CPL A
3d3: 17    INC A
3d4: ae    MOV R6,A
3d5: fa    MOV A,R2
3d6: 6e    ADD A,R6
3d7: 1c    INC R4
3d8: f6d6  JC $3d6
3da: 6b    ADD A,R3
3db: ad    MOV R5,A
3dc: 83    RET
3dd: fa    MOV A,R2
3de: 96e1  JNZ $3e1
3e0: 83    RET
3e1: fb    MOV A,R3
3e2: 96e5  JNZ $3e5
3e4: 83    RET
3e5: 27    CLR A
3e6: 6b    ADD A,R3
3e7: eae6  DJNZ R2, $3e6
3e9: 83    RET
3ea: fc    MOV A,R4
3eb: 90    MOVX @R0,A
3ec: 18    INC R0
3ed: f8    MOV A,R0
3ee: d2f9  JB6 $3f9
3f0: fb    MOV A,R3
3f1: 90    MOVX @R0,A
3f2: 0308  ADD A, #$08
3f4: ab    MOV R3,A
3f5: 18    INC R0
3f6: 5461  CALL $261
3f8: 83    RET
3f9: 530f  ANL A, #$0f
3fb: 07    DEC A
3fc: c6f0  JZ $3f0
3fe: 64f5  JMP $3f5
