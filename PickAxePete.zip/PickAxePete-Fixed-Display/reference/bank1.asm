400: 44c3  JMP $2c3
402: 0409  JMP $009
404: 93    RETR
405: 00    NOP
406: 041a  JMP $01a
408: 44c3  JMP $2c3
40a: fc    MOV A,R4
40b: 03a0  ADD A, #$a0
40d: 0444  JMP $044
40f: 00    NOP
410: 00    NOP
411: 8903  ORL P1, #$03
413: 00    NOP
414: 8423  JMP $423
416: 8903  ORL P1, #$03
418: 00    NOP
419: 00    NOP
41a: 00    NOP
41b: 00    NOP
41c: 00    NOP
41d: 00    NOP
41e: 00    NOP
41f: 00    NOP
420: 00    NOP
421: 00    NOP
422: 83    RET
423: b835  MOV R0, #$35
425: f0    MOV A,@R0
426: 9688  JNZ $488
428: 763e  JF1 $43e
42a: 944c  CALL $44c
42c: 9468  CALL $468
42e: f5    SEL MB1
42f: 5400  CALL $200
431: e5    SEL MB0
432: b82b  MOV R0, #$2b
434: f0    MOV A,@R0
435: c63b  JZ $43b
437: b831  MOV R0, #$31
439: b080  MOV @R0, #$80
43b: a5    CLR F1
43c: 8411  JMP $411
43e: b825  MOV R0, #$25
440: f0    MOV A,@R0
441: 37    CPL A
442: 1246  JB0 $446
444: b427  CALL $527
446: f400  CALL $700
448: a5    CLR F1
449: b5    CPL F1
44a: 8411  JMP $411
44c: bf09  MOV R7, #$09
44e: b814  MOV R0, #$14
450: 80    MOVX A,@R0
451: 9622  JNZ $422
453: b82e  MOV R0, #$2e
455: 80    MOVX A,@R0
456: 03f6  ADD A, #$f6
458: e65c  JNC $45c
45a: 27    CLR A
45b: 90    MOVX @R0,A
45c: 80    MOVX A,@R0
45d: ae    MOV R6,A
45e: 1e    INC R6
45f: 239a  MOV A, #$9a
461: 0309  ADD A, #$09
463: ee61  DJNZ R6, $461
465: ac    MOV R4,A
466: c499  JMP $699
468: b834  MOV R0, #$34
46a: f0    MOV A,@R0
46b: 9671  JNZ $471
46d: b901  MOV R1, #$01
46f: 648f  JMP $38f
471: 85    CLR F0
472: ba00  MOV R2, #$00
474: bb01  MOV R3, #$01
476: 83    RET
477: a0    MOV @R0,A
478: b826  MOV R0, #$26
47a: b002  MOV @R0, #$02
47c: c8    DEC R0
47d: a0    MOV @R0,A
47e: b822  MOV R0, #$22
480: f0    MOV A,@R0
481: 97    CLR C
482: 67    RRC A
483: 97    CLR C
484: 67    RRC A
485: a0    MOV @R0,A
486: c400  JMP $600
488: 9490  CALL $490
48a: f400  CALL $700
48c: a5    CLR F1
48d: b5    CPL F1
48e: 8411  JMP $411
490: 17    INC A
491: a0    MOV @R0,A
492: 17    INC A
493: c677  JZ $477
495: b97d  MOV R1, #$7d
497: 2368  MOV A, #$68
499: 91    MOVX @R1,A
49a: c9    DEC R1
49b: 2348  MOV A, #$48
49d: 91    MOVX @R1,A
49e: c9    DEC R1
49f: 231c  MOV A, #$1c
4a1: 91    MOVX @R1,A
4a2: c9    DEC R1
4a3: c9    DEC R1
4a4: bf0b  MOV R7, #$0b
4a6: 23f8  MOV A, #$f8
4a8: 91    MOVX @R1,A
4a9: c9    DEC R1
4aa: 91    MOVX @R1,A
4ab: c9    DEC R1
4ac: c9    DEC R1
4ad: 27    CLR A
4ae: 91    MOVX @R1,A
4af: c9    DEC R1
4b0: efa6  DJNZ R7, $4a6
4b2: c9    DEC R1
4b3: 2380  MOV A, #$80
4b5: 91    MOVX @R1,A
4b6: 85    CLR F0
4b7: ba00  MOV R2, #$00
4b9: bb00  MOV R3, #$00
4bb: f5    SEL MB1
4bc: 3400  CALL $100
4be: e5    SEL MB0
4bf: b82a  MOV R0, #$2a
4c1: b0a0  MOV @R0, #$a0
4c3: b835  MOV R0, #$35
4c5: f0    MOV A,@R0
4c6: b824  MOV R0, #$24
4c8: 5303  ANL A, #$03
4ca: 96d4  JNZ $4d4
4cc: 10    INC @R0
4cd: f0    MOV A,@R0
4ce: 03fb  ADD A, #$fb
4d0: e6d4  JNC $4d4
4d2: b000  MOV @R0, #$00
4d4: f0    MOV A,@R0
4d5: af    MOV R7,A
4d6: 23f4  MOV A, #$f4
4d8: 0302  ADD A, #$02
4da: efd8  DJNZ R7, $4d8
4dc: ac    MOV R4,A
4dd: bf09  MOV R7, #$09
4df: b832  MOV R0, #$32
4e1: 27    CLR A
4e2: 90    MOVX @R0,A
4e3: 18    INC R0
4e4: efe2  DJNZ R7, $4e2
4e6: fc    MOV A,R4
4e7: a3    MOVP A,@A
4e8: a8    MOV R0,A
4e9: 1c    INC R4
4ea: fc    MOV A,R4
4eb: a3    MOVP A,@A
4ec: af    MOV R7,A
4ed: 23ff  MOV A, #$ff
4ef: 90    MOVX @R0,A
4f0: 18    INC R0
4f1: efef  DJNZ R7, $4ef
4f3: 83    RET
4f4: 3209  JB1 $409
4f6: 33    ILL
4f7: 07    DEC A
4f8: 3405  CALL $105
4fa: 35    DIS TCNTI
4fb: 0336  ADD A, #$36
4fd: 01    ILL
4fe: 00    NOP
4ff: 00    NOP
500: b832  MOV R0, #$32
502: f0    MOV A,@R0
503: 18    INC R0
504: 40    ORL A,@R0
505: c61e  JZ $51e
507: b87d  MOV R0, #$7d
509: bf06  MOV R7, #$06
50b: bd21  MOV R5, #$21
50d: bc00  MOV R4, #$00
50f: fd    MOV A,R5
510: a3    MOVP A,@A
511: a9    MOV R1,A
512: 80    MOVX A,@R0
513: 69    ADD A,R1
514: f61a  JC $51a
516: 1d    INC R5
517: 1c    INC R4
518: ef0f  DJNZ R7, $50f
51a: b937  MOV R1, #$37
51c: fc    MOV A,R4
51d: a1    MOV @R1,A
51e: b979  MOV R1, #$79
520: 83    RET
521: 55    STRT T
522: 6d    ADD A,R5
523: 85    CLR F0
524: 9d    ANLD P5,A
525: bbcd  MOV R3, #$cd
527: b932  MOV R1, #$32
529: f1    MOV A,@R1
52a: 96d6  JNZ $5d6
52c: 85    CLR F0
52d: 95    CPL F0
52e: f0    MOV A,@R0
52f: 77    RR A
530: 77    RR A
531: 5303  ANL A, #$03
533: ae    MOV R6,A
534: b875  MOV R0, #$75
536: 80    MOVX A,@R0
537: d3f8  XRL A, #$f8
539: c68f  JZ $58f
53b: b973  MOV R1, #$73
53d: bafe  MOV R2, #$fe
53f: 81    MOVX A,@R1
540: bdae  MOV R5, #$ae
542: 9248  JB4 $548
544: bd8e  MOV R5, #$8e
546: ba02  MOV R2, #$02
548: 80    MOVX A,@R0
549: 6a    ADD A,R2
54a: 90    MOVX @R0,A
54b: bce4  MOV R4, #$e4
54d: 6c    ADD A,R4
54e: e65c  JNC $55c
550: bc50  MOV R4, #$50
552: 80    MOVX A,@R0
553: 6c    ADD A,R4
554: f65c  JC $55c
556: b92a  MOV R1, #$2a
558: b184  MOV @R1, #$84
55a: a474  JMP $574
55c: fc    MOV A,R4
55d: 37    CPL A
55e: 17    INC A
55f: 90    MOVX @R0,A
560: b936  MOV R1, #$36
562: f1    MOV A,@R1
563: 0302  ADD A, #$02
565: a1    MOV @R1,A
566: c690  JZ $590
568: 37    CPL A
569: f272  JB7 $572
56b: b92a  MOV R1, #$2a
56d: b182  MOV @R1, #$82
56f: 42    MOV A,T
570: aa    MOV R2,A
571: 85    CLR F0
572: be00  MOV R6, #$00
574: fd    MOV A,R5
575: 1e    INC R6
576: 0308  ADD A, #$08
578: ee76  DJNZ R6, $576
57a: ac    MOV R4,A
57b: b84b  MOV R0, #$4b
57d: bf08  MOV R7, #$08
57f: fc    MOV A,R4
580: a3    MOVP A,@A
581: 90    MOVX @R0,A
582: b68b  JF0 $58b
584: fa    MOV A,R2
585: 37    CPL A
586: 77    RR A
587: aa    MOV R2,A
588: 80    MOVX A,@R0
589: 5a    ANL A,R2
58a: 90    MOVX @R0,A
58b: c8    DEC R0
58c: 1c    INC R4
58d: ef7f  DJNZ R7, $57f
58f: 83    RET
590: 23f8  MOV A, #$f8
592: 90    MOVX @R0,A
593: c8    DEC R0
594: 90    MOVX @R0,A
595: 83    RET
596: 10    INC @R0
597: 10    INC @R0
598: 10    INC @R0
599: 10    INC @R0
59a: 10    INC @R0
59b: 927c  JB4 $57c
59d: 10    INC @R0
59e: 20    XCH A,@R0
59f: 40    ORL A,@R0
5a0: 40    ORL A,@R0
5a1: ff    MOV A,R7
5a2: 40    ORL A,@R0
5a3: 40    ORL A,@R0
5a4: 20    XCH A,@R0
5a5: 00    NOP
5a6: 10    INC @R0
5a7: 7c    ADDC A,R4
5a8: 9210  JB4 $510
5aa: 10    INC @R0
5ab: 10    INC @R0
5ac: 10    INC @R0
5ad: 10    INC @R0
5ae: 0402  JMP $002
5b0: 02    OUTL BUS,A
5b1: ff    MOV A,R7
5b2: 02    OUTL BUS,A
5b3: 02    OUTL BUS,A
5b4: 0400  JMP $000
5b6: 10    INC @R0
5b7: 28    XCH A,R0
5b8: 10    INC @R0
5b9: 10    INC @R0
5ba: 10    INC @R0
5bb: 70    ADDC A,@R0
5bc: 30    XCHD A,@R0
5bd: 70    ADDC A,@R0
5be: 00    NOP
5bf: a0    MOV @R0,A
5c0: e2    ILL
5c1: fd    MOV A,R5
5c2: 02    OUTL BUS,A
5c3: 00    NOP
5c4: 00    NOP
5c5: 00    NOP
5c6: 0e    MOVD A,P6
5c7: 0c    MOVD A,P4
5c8: 0e    MOVD A,P6
5c9: 08    INS A,BUS
5ca: 08    INS A,BUS
5cb: 08    INS A,BUS
5cc: 1408  CALL $008
5ce: 00    NOP
5cf: 00    NOP
5d0: 40    ORL A,@R0
5d1: bf47  MOV R7, #$47
5d3: 05    EN I
5d4: 00    NOP
5d5: 00    NOP
5d6: 033f  ADD A, #$3f
5d8: e68f  JNC $58f
5da: b82a  MOV R0, #$2a
5dc: b082  MOV @R0, #$82
5de: b825  MOV R0, #$25
5e0: f0    MOV A,@R0
5e1: ba28  MOV R2, #$28
5e3: 72e7  JB3 $5e7
5e5: ba38  MOV R2, #$38
5e7: b973  MOV R1, #$73
5e9: fa    MOV A,R2
5ea: 91    MOVX @R1,A
5eb: f0    MOV A,@R0
5ec: 328f  JB1 $58f
5ee: 42    MOV A,T
5ef: aa    MOV R2,A
5f0: bf05  MOV R7, #$05
5f2: b84a  MOV R0, #$4a
5f4: 80    MOVX A,@R0
5f5: 5a    ANL A,R2
5f6: 90    MOVX @R0,A
5f7: c8    DEC R0
5f8: fa    MOV A,R2
5f9: 37    CPL A
5fa: 77    RR A
5fb: aa    MOV R2,A
5fc: eff4  DJNZ R7, $5f4
5fe: 83    RET
5ff: 00    NOP
600: 42    MOV A,T
601: 5307  ANL A, #$07
603: aa    MOV R2,A
604: f207  JB7 $607
606: 1a    INC R2
607: 2310  MOV A, #$10
609: 6a    ADD A,R2
60a: a8    MOV R0,A
60b: bf08  MOV R7, #$08
60d: f8    MOV A,R0
60e: d314  XRL A, #$14
610: 9613  JNZ $613
612: 18    INC R0
613: f8    MOV A,R0
614: d319  XRL A, #$19
616: 961a  JNZ $61a
618: b810  MOV R0, #$10
61a: 42    MOV A,T
61b: 5307  ANL A, #$07
61d: ac    MOV R4,A
61e: ae    MOV R6,A
61f: 80    MOVX A,@R0
620: 537e  ANL A, #$7e
622: c638  JZ $638
624: e7    RL A
625: ec24  DJNZ R4, $624
627: bc08  MOV R4, #$08
629: f22f  JB7 $62f
62b: 1e    INC R6
62c: e7    RL A
62d: ec29  DJNZ R4, $629
62f: 537f  ANL A, #$7f
631: 77    RR A
632: ee31  DJNZ R6, $631
634: 4381  ORL A, #$81
636: 90    MOVX @R0,A
637: 83    RET
638: 18    INC R0
639: ef0d  DJNZ R7, $60d
63b: 83    RET
63c: c9    DEC R1
63d: c9    DEC R1
63e: 81    MOVX A,@R1
63f: 77    RR A
640: 5302  ANL A, #$02
642: aa    MOV R2,A
643: 81    MOVX A,@R1
644: 3255  JB1 $655
646: 37    CPL A
647: 724a  JB3 $64a
649: 1a    INC R2
64a: fa    MOV A,R2
64b: b823  MOV R0, #$23
64d: a0    MOV @R0,A
64e: b821  MOV R0, #$21
650: f0    MOV A,@R0
651: 0314  ADD A, #$14
653: a0    MOV @R0,A
654: 83    RET
655: 2304  MOV A, #$04
657: 4a    ORL A,R2
658: aa    MOV R2,A
659: 81    MOVX A,@R1
65a: c446  JMP $646
65c: b87c  MOV R0, #$7c
65e: bc71  MOV R4, #$71
660: 80    MOVX A,@R0
661: 6c    ADD A,R4
662: e668  JNC $668
664: fc    MOV A,R4
665: 37    CPL A
666: 17    INC A
667: 90    MOVX @R0,A
668: b827  MOV R0, #$27
66a: f0    MOV A,@R0
66b: 9687  JNZ $687
66d: c5    SEL RB0
66e: fb    MOV A,R3
66f: d5    SEL RB1
670: 9687  JNZ $687
672: b92a  MOV R1, #$2a
674: f1    MOV A,@R1
675: c687  JZ $687
677: b100  MOV @R1, #$00
679: f288  JB7 $688
67b: ba74  MOV R2, #$74
67d: 5285  JB2 $685
67f: ba97  MOV R2, #$97
681: 7285  JB3 $685
683: ba64  MOV R2, #$64
685: fa    MOV A,R2
686: a0    MOV @R0,A
687: 83    RET
688: bab1  MOV R2, #$b1
68a: b285  JB5 $685
68c: ba78  MOV R2, #$78
68e: 7285  JB3 $685
690: ba7f  MOV R2, #$7f
692: 5285  JB2 $685
694: ba91  MOV R2, #$91
696: 3285  JB1 $685
698: 83    RET
699: b810  MOV R0, #$10
69b: fc    MOV A,R4
69c: a3    MOVP A,@A
69d: 90    MOVX @R0,A
69e: 18    INC R0
69f: 1c    INC R4
6a0: ef9b  DJNZ R7, $69b
6a2: 83    RET
6a3: a9    MOV R1,A
6a4: ff    MOV A,R7
6a5: ff    MOV A,R7
6a6: ff    MOV A,R7
6a7: ff    MOV A,R7
6a8: ff    MOV A,R7
6a9: ff    MOV A,R7
6aa: df    XRL A,R7
6ab: 95    CPL F0
6ac: ff    MOV A,R7
6ad: ff    MOV A,R7
6ae: ff    MOV A,R7
6af: a9    MOV R1,A
6b0: ff    MOV A,R7
6b1: ff    MOV A,R7
6b2: ff    MOV A,R7
6b3: df    XRL A,R7
6b4: 95    CPL F0
6b5: d7    MOV PSW,A
6b6: ff    MOV A,R7
6b7: ff    MOV A,R7
6b8: a9    MOV R1,A
6b9: ff    MOV A,R7
6ba: a9    MOV R1,A
6bb: ff    MOV A,R7
6bc: ff    MOV A,R7
6bd: d7    MOV PSW,A
6be: bbf7  MOV R3, #$f7
6c0: ff    MOV A,R7
6c1: cd    DEC R5
6c2: ff    MOV A,R7
6c3: cd    DEC R5
6c4: f7    RLC A
6c5: ff    MOV A,R7
6c6: bbff  MOV R3, #$ff
6c8: e7    RL A
6c9: db    XRL A,R3
6ca: bdff  MOV R5, #$ff
6cc: bddb  MOV R5, #$db
6ce: e7    RL A
6cf: ff    MOV A,R7
6d0: bddb  MOV R5, #$db
6d2: e7    RL A
6d3: ff    MOV A,R7
6d4: ff    MOV A,R7
6d5: ff    MOV A,R7
6d6: e7    RL A
6d7: db    XRL A,R3
6d8: bdab  MOV R5, #$ab
6da: ff    MOV A,R7
6db: ff    MOV A,R7
6dc: ff    MOV A,R7
6dd: ff    MOV A,R7
6de: ff    MOV A,R7
6df: ff    MOV A,R7
6e0: ff    MOV A,R7
6e1: d5    SEL RB1
6e2: 99ff  ANL P1, #$ff
6e4: e7    RL A
6e5: ff    MOV A,R7
6e6: ff    MOV A,R7
6e7: ff    MOV A,R7
6e8: e7    RL A
6e9: ff    MOV A,R7
6ea: 99f9  ANL P1, #$f9
6ec: ff    MOV A,R7
6ed: e7    RL A
6ee: 9f    ANLD P7,A
6ef: ff    MOV A,R7
6f0: 9f    ANLD P7,A
6f1: e7    RL A
6f2: ff    MOV A,R7
6f3: f9    MOV A,R1
6f4: 81    MOVX A,@R1
6f5: ff    MOV A,R7
6f6: ff    MOV A,R7
6f7: ff    MOV A,R7
6f8: ff    MOV A,R7
6f9: ff    MOV A,R7
6fa: ff    MOV A,R7
6fb: ff    MOV A,R7
6fc: 81    MOVX A,@R1
6fd: 00    NOP
6fe: 00    NOP
6ff: 00    NOP
700: d45c  CALL $65c
702: b825  MOV R0, #$25
704: f0    MOV A,@R0
705: 1247  JB0 $747
707: b834  MOV R0, #$34
709: f0    MOV A,@R0
70a: c6bb  JZ $7bb
70c: 17    INC A
70d: a0    MOV @R0,A
70e: 03a0  ADD A, #$a0
710: f635  JC $735
712: b94c  MOV R1, #$4c
714: 81    MOVX A,@R1
715: 926b  JB4 $76b
717: c9    DEC R1
718: f0    MOV A,@R0
719: 03e0  ADD A, #$e0
71b: bcbd  MOV R4, #$bd
71d: f62b  JC $72b
71f: f0    MOV A,@R0
720: 77    RR A
721: 5303  ANL A, #$03
723: 17    INC A
724: af    MOV R7,A
725: fc    MOV A,R4
726: 0308  ADD A, #$08
728: ef26  DJNZ R7, $726
72a: ac    MOV R4,A
72b: bf08  MOV R7, #$08
72d: fc    MOV A,R4
72e: a3    MOVP A,@A
72f: 91    MOVX @R1,A
730: c9    DEC R1
731: 1c    INC R4
732: ef2d  DJNZ R7, $72d
734: 83    RET
735: b923  MOV R1, #$23
737: 27    CLR A
738: bf1c  MOV R7, #$1c
73a: b81a  MOV R0, #$1a
73c: a1    MOV @R1,A
73d: 19    INC R1
73e: ef3c  DJNZ R7, $73c
740: bf14  MOV R7, #$14
742: 90    MOVX @R0,A
743: 18    INC R0
744: ef42  DJNZ R7, $742
746: 83    RET
747: b820  MOV R0, #$20
749: f0    MOV A,@R0
74a: c64e  JZ $74e
74c: 07    DEC A
74d: a0    MOV @R0,A
74e: b87d  MOV R0, #$7d
750: bf08  MOV R7, #$08
752: b96d  MOV R1, #$6d
754: f4b1  CALL $7b1
756: ad    MOV R5,A
757: 03f6  ADD A, #$f6
759: f665  JC $765
75b: c8    DEC R0
75c: c9    DEC R1
75d: f4b1  CALL $7b1
75f: 03f9  ADD A, #$f9
761: e66c  JNC $76c
763: 18    INC R0
764: 19    INC R1
765: c9    DEC R1
766: c9    DEC R1
767: c9    DEC R1
768: c9    DEC R1
769: ef54  DJNZ R7, $754
76b: 83    RET
76c: f9    MOV A,R1
76d: 03a6  ADD A, #$a6
76f: e69d  JNC $79d
771: fc    MOV A,R4
772: 03fd  ADD A, #$fd
774: f66b  JC $76b
776: b83d  MOV R0, #$3d
778: f0    MOV A,@R0
779: b82e  MOV R0, #$2e
77b: 128e  JB0 $78e
77d: f0    MOV A,@R0
77e: c6bb  JZ $7bb
780: b820  MOV R0, #$20
782: f0    MOV A,@R0
783: 96bb  JNZ $7bb
785: b009  MOV @R0, #$09
787: 18    INC R0
788: 10    INC @R0
789: b827  MOV R0, #$27
78b: b056  MOV @R0, #$56
78d: 83    RET
78e: f0    MOV A,@R0
78f: c696  JZ $796
791: 23fa  MOV A, #$fa
793: 6d    ADD A,R5
794: f67d  JC $77d
796: b834  MOV R0, #$34
798: f0    MOV A,@R0
799: 96bb  JNZ $7bb
79b: 10    INC @R0
79c: 83    RET
79d: fd    MOV A,R5
79e: 03fa  ADD A, #$fa
7a0: f6bb  JC $7bb
7a2: b833  MOV R0, #$33
7a4: f0    MOV A,@R0
7a5: c6e5  JZ $7e5
7a7: d43c  CALL $63c
7a9: b928  MOV R1, #$28
7ab: f437  CALL $737
7ad: b835  MOV R0, #$35
7af: 10    INC @R0
7b0: 83    RET
7b1: 80    MOVX A,@R0
7b2: ac    MOV R4,A
7b3: 81    MOVX A,@R1
7b4: 37    CPL A
7b5: 17    INC A
7b6: 6c    ADD A,R4
7b7: f6bb  JC $7bb
7b9: 37    CPL A
7ba: 17    INC A
7bb: ac    MOV R4,A
7bc: 83    RET
7bd: 00    NOP
7be: 18    INC R0
7bf: 18    INC R0
7c0: 3c    MOVD P4,A
7c1: 5a    ANL A,R2
7c2: 99ff  ANL P1, #$ff
7c4: 00    NOP
7c5: 28    XCH A,R0
7c6: 987e  ANL BUS, #$7e
7c8: 19    INC R1
7c9: 18    INC R0
7ca: 18    INC R0
7cb: 2442  JMP $142
7cd: 20    XCH A,@R0
7ce: 21    XCH A,@R1
7cf: 22    ILL
7d0: fc    MOV A,R4
7d1: f622  JC $722
7d3: 21    XCH A,@R1
7d4: 20    XCH A,@R0
7d5: 42    MOV A,T
7d6: 2418  JMP $118
7d8: 18    INC R0
7d9: 18    INC R0
7da: 7e    ADDC A,R6
7db: 9918  ANL P1, #$18
7dd: 02    OUTL BUS,A
7de: 82    ILL
7df: 443f  JMP $23f
7e1: 3f    MOVD P7,A
7e2: 4488  JMP $288
7e4: 08    INS A,BUS
7e5: c9    DEC R1
7e6: c9    DEC R1
7e7: 81    MOVX A,@R1
7e8: 43c0  ORL A, #$c0
7ea: 91    MOVX @R1,A
7eb: b82c  MOV R0, #$2c
7ed: b001  MOV @R0, #$01
7ef: 42    MOV A,T
7f0: b927  MOV R1, #$27
7f2: b1a5  MOV @R1, #$a5
7f4: 12fa  JB0 $7fa
7f6: b1ab  MOV @R1, #$ab
7f8: b0ff  MOV @R0, #$ff
7fa: 18    INC R0
7fb: b0ff  MOV @R0, #$ff
7fd: 18    INC R0
7fe: 10    INC @R0
7ff: 83    RET
800: 140a  CALL $00a
802: b82b  MOV R0, #$2b
804: f0    MOV A,@R0
805: 9609  JNZ $809
807: 2400  JMP $100
809: 83    RET
80a: b977  MOV R1, #$77
80c: 2338  MOV A, #$38
80e: 91    MOVX @R1,A
80f: fb    MOV A,R3
810: f21b  JB7 $81b
812: b83d  MOV R0, #$3d
814: f0    MOV A,@R0
815: 521b  JB2 $81b
817: 721b  JB3 $81b
819: f247  JB7 $847
81b: b979  MOV R1, #$79
81d: b87d  MOV R0, #$7d
81f: 80    MOVX A,@R0
820: 37    CPL A
821: 17    INC A
822: ac    MOV R4,A
823: 81    MOVX A,@R1
824: 6c    ADD A,R4
825: f62a  JC $82a
827: 37    CPL A
828: 17    INC A
829: ac    MOV R4,A
82a: 03f7  ADD A, #$f7
82c: f647  JC $847
82e: c9    DEC R1
82f: c8    DEC R0
830: 80    MOVX A,@R0
831: 37    CPL A
832: 17    INC A
833: ac    MOV R4,A
834: 81    MOVX A,@R1
835: 6c    ADD A,R4
836: f63b  JC $83b
838: 37    CPL A
839: 17    INC A
83a: ac    MOV R4,A
83b: 03f7  ADD A, #$f7
83d: f647  JC $847
83f: b93a  MOV R1, #$3a
841: b101  MOV @R1, #$01
843: b92b  MOV R1, #$2b
845: b101  MOV @R1, #$01
847: b839  MOV R0, #$39
849: b93a  MOV R1, #$3a
84b: f1    MOV A,@R1
84c: 1264  JB0 $864
84e: f0    MOV A,@R0
84f: c66b  JZ $86b
851: 07    DEC A
852: a0    MOV @R0,A
853: 77    RR A
854: 77    RR A
855: 5303  ANL A, #$03
857: 17    INC A
858: af    MOV R7,A
859: 2304  MOV A, #$04
85b: 0308  ADD A, #$08
85d: ef5b  DJNZ R7, $85b
85f: ac    MOV R4,A
860: b943  MOV R1, #$43
862: 6402  JMP $302
864: f0    MOV A,@R0
865: 17    INC A
866: 92d6  JB4 $8d6
868: a0    MOV @R0,A
869: 0453  JMP $053
86b: 11    INC @R1
86c: e5    SEL MB0
86d: b400  CALL $500
86f: f5    SEL MB1
870: b837  MOV R0, #$37
872: f0    MOV A,@R0
873: ad    MOV R5,A
874: 17    INC A
875: a0    MOV @R0,A
876: 03f9  ADD A, #$f9
878: e67e  JNC $87e
87a: 27    CLR A
87b: a0    MOV @R0,A
87c: 10    INC @R0
87d: ad    MOV R5,A
87e: fd    MOV A,R5
87f: e7    RL A
880: 03ca  ADD A, #$ca
882: ad    MOV R5,A
883: a3    MOVP A,@A
884: ac    MOV R4,A
885: 1d    INC R5
886: fd    MOV A,R5
887: a3    MOVP A,@A
888: 91    MOVX @R1,A
889: 42    MOV A,T
88a: 5307  ANL A, #$07
88c: 0310  ADD A, #$10
88e: a8    MOV R0,A
88f: bf09  MOV R7, #$09
891: 42    MOV A,T
892: d2a8  JB6 $8a8
894: 80    MOVX A,@R0
895: 5c    ANL A,R4
896: 96b8  JNZ $8b8
898: 18    INC R0
899: f8    MOV A,R0
89a: d319  XRL A, #$19
89c: 96a0  JNZ $8a0
89e: b810  MOV R0, #$10
8a0: ef94  DJNZ R7, $894
8a2: 23f8  MOV A, #$f8
8a4: c9    DEC R1
8a5: 91    MOVX @R1,A
8a6: 04f7  JMP $0f7
8a8: 80    MOVX A,@R0
8a9: 5c    ANL A,R4
8aa: 96b8  JNZ $8b8
8ac: c8    DEC R0
8ad: f8    MOV A,R0
8ae: d30f  XRL A, #$0f
8b0: 96b4  JNZ $8b4
8b2: b818  MOV R0, #$18
8b4: efa8  DJNZ R7, $8a8
8b6: 04a2  JMP $0a2
8b8: f8    MOV A,R0
8b9: 530f  ANL A, #$0f
8bb: 03c1  ADD A, #$c1
8bd: a3    MOVP A,@A
8be: c9    DEC R1
8bf: 04a5  JMP $0a5
8c1: 0d    MOVD A,P5
8c2: 1d    INC R5
8c3: 2d    XCH A,R5
8c4: 3d    MOVD P5,A
8c5: 4d    ORL A,R5
8c6: 5d    ANL A,R5
8c7: 6d    ADD A,R5
8c8: 7d    ADDC A,R5
8c9: 8d    ORLD P5,A
8ca: 40    ORL A,@R0
8cb: ab    MOV R3,A
8cc: 20    XCH A,@R0
8cd: 93    RETR
8ce: 10    INC @R0
8cf: 7b    ADDC A,R3
8d0: 08    INS A,BUS
8d1: 63    ILL
8d2: 044b  JMP $04b
8d4: 02    OUTL BUS,A
8d5: 33    ILL
8d6: b97d  MOV R1, #$7d
8d8: b879  MOV R0, #$79
8da: 80    MOVX A,@R0
8db: 37    CPL A
8dc: 17    INC A
8dd: ac    MOV R4,A
8de: 81    MOVX A,@R1
8df: 6c    ADD A,R4
8e0: b938  MOV R1, #$38
8e2: e6ed  JNC $8ed
8e4: 03f4  ADD A, #$f4
8e6: f6ed  JC $8ed
8e8: f1    MOV A,@R1
8e9: 96ed  JNZ $8ed
8eb: b110  MOV @R1, #$10
8ed: f1    MOV A,@R1
8ee: c6f4  JZ $8f4
8f0: 07    DEC A
8f1: a1    MOV @R1,A
8f2: 96f7  JNZ $8f7
8f4: b93a  MOV R1, #$3a
8f6: 11    INC @R1
8f7: b839  MOV R0, #$39
8f9: f0    MOV A,@R0
8fa: 0453  JMP $053
8fc: 00    NOP
8fd: 00    NOP
8fe: 00    NOP
8ff: 00    NOP
900: b82e  MOV R0, #$2e
902: f0    MOV A,@R0
903: 969f  JNZ $99f
905: b92c  MOV R1, #$2c
907: fa    MOV A,R2
908: c60b  JZ $90b
90a: a1    MOV @R1,A
90b: fb    MOV A,R3
90c: c610  JZ $910
90e: fa    MOV A,R2
90f: a1    MOV @R1,A
910: 19    INC R1
911: fb    MOV A,R3
912: c615  JZ $915
914: a1    MOV @R1,A
915: b931  MOV R1, #$31
917: f1    MOV A,@R1
918: f26b  JB7 $96b
91a: 37    CPL A
91b: 326b  JB1 $96b
91d: b69f  JF0 $99f
91f: b87d  MOV R0, #$7d
921: 80    MOVX A,@R0
922: 0302  ADD A, #$02
924: 90    MOVX @R0,A
925: bb01  MOV R3, #$01
927: e5    SEL MB0
928: 9416  CALL $416
92a: f5    SEL MB1
92b: fe    MOV A,R6
92c: 96e9  JNZ $9e9
92e: b97d  MOV R1, #$7d
930: 81    MOVX A,@R1
931: 03fe  ADD A, #$fe
933: 6b    ADD A,R3
934: 91    MOVX @R1,A
935: c9    DEC R1
936: 81    MOVX A,@R1
937: 6a    ADD A,R2
938: 91    MOVX @R1,A
939: b82e  MOV R0, #$2e
93b: f0    MOV A,@R0
93c: 9647  JNZ $947
93e: fe    MOV A,R6
93f: b831  MOV R0, #$31
941: a0    MOV @R0,A
942: f271  JB7 $971
944: 37    CPL A
945: 3271  JB1 $971
947: b92f  MOV R1, #$2f
949: 11    INC @R1
94a: f1    MOV A,@R1
94b: d303  XRL A, #$03
94d: 96e4  JNZ $9e4
94f: a1    MOV @R1,A
950: fa    MOV A,R2
951: c683  JZ $983
953: bcb4  MOV R4, #$b4
955: f259  JB7 $959
957: bcd4  MOV R4, #$d4
959: 19    INC R1
95a: 11    INC @R1
95b: f1    MOV A,@R1
95c: d305  XRL A, #$05
95e: 9662  JNZ $962
960: a1    MOV @R1,A
961: 11    INC @R1
962: f1    MOV A,@R1
963: af    MOV R7,A
964: fc    MOV A,R4
965: 0308  ADD A, #$08
967: ef65  DJNZ R7, $965
969: 2497  JMP $197
96b: ba00  MOV R2, #$00
96d: b82c  MOV R0, #$2c
96f: 24e0  JMP $1e0
971: bc24  MOV R4, #$24
973: b825  MOV R0, #$25
975: f0    MOV A,@R0
976: 77    RR A
977: 77    RR A
978: 5303  ANL A, #$03
97a: 17    INC A
97b: af    MOV R7,A
97c: fc    MOV A,R4
97d: 0308  ADD A, #$08
97f: ef7d  DJNZ R7, $97d
981: 2497  JMP $197
983: b82d  MOV R0, #$2d
985: bc6c  MOV R4, #$6c
987: f0    MOV A,@R0
988: c68e  JZ $98e
98a: f28e  JB7 $98e
98c: bc84  MOV R4, #$84
98e: c8    DEC R0
98f: f0    MOV A,@R0
990: c69a  JZ $99a
992: f298  JB7 $998
994: fc    MOV A,R4
995: 0308  ADD A, #$08
997: ac    MOV R4,A
998: 6400  JMP $300
99a: fc    MOV A,R4
99b: 0310  ADD A, #$10
99d: 2497  JMP $197
99f: f0    MOV A,@R0
9a0: 17    INC A
9a1: 531f  ANL A, #$1f
9a3: a0    MOV @R0,A
9a4: 85    CLR F0
9a5: c605  JZ $905
9a7: c8    DEC R0
9a8: f0    MOV A,@R0
9a9: ab    MOV R3,A
9aa: c8    DEC R0
9ab: f0    MOV A,@R0
9ac: aa    MOV R2,A
9ad: b82e  MOV R0, #$2e
9af: bc4c  MOV R4, #$4c
9b1: fb    MOV A,R3
9b2: 96b6  JNZ $9b6
9b4: bbff  MOV R3, #$ff
9b6: fb    MOV A,R3
9b7: f2bb  JB7 $9bb
9b9: bc9c  MOV R4, #$9c
9bb: fa    MOV A,R2
9bc: 37    CPL A
9bd: f2c3  JB7 $9c3
9bf: fc    MOV A,R4
9c0: 0310  ADD A, #$10
9c2: ac    MOV R4,A
9c3: fb    MOV A,R3
9c4: f2cd  JB7 $9cd
9c6: bb00  MOV R3, #$00
9c8: f0    MOV A,@R0
9c9: 12cd  JB0 $9cd
9cb: ba00  MOV R2, #$00
9cd: f0    MOV A,@R0
9ce: 92d4  JB4 $9d4
9d0: 72da  JB3 $9da
9d2: 44d2  JMP $2d2
9d4: 72dc  JB3 $9dc
9d6: fb    MOV A,R3
9d7: 37    CPL A
9d8: 17    INC A
9d9: ab    MOV R3,A
9da: 44cc  JMP $2cc
9dc: bb00  MOV R3, #$00
9de: b82d  MOV R0, #$2d
9e0: b000  MOV @R0, #$00
9e2: 241f  JMP $11f
9e4: b84d  MOV R0, #$4d
9e6: 27    CLR A
9e7: 90    MOVX @R0,A
9e8: 83    RET
9e9: 12f3  JB0 $9f3
9eb: 92f3  JB4 $9f3
9ed: f22e  JB7 $92e
9ef: 32fa  JB1 $9fa
9f1: 242e  JMP $12e
9f3: b828  MOV R0, #$28
9f5: f0    MOV A,@R0
9f6: aa    MOV R2,A
9f7: fe    MOV A,R6
9f8: 24ed  JMP $1ed
9fa: b829  MOV R0, #$29
9fc: f0    MOV A,@R0
9fd: ab    MOV R3,A
9fe: 242e  JMP $12e
a00: b825  MOV R0, #$25
a02: b94d  MOV R1, #$4d
a04: 2310  MOV A, #$10
a06: 91    MOVX @R1,A
a07: c9    DEC R1
a08: f0    MOV A,@R0
a09: 1210  JB0 $a10
a0b: 2380  MOV A, #$80
a0d: 91    MOVX @R1,A
a0e: 0400  JMP $000
a10: 2390  MOV A, #$90
a12: 91    MOVX @R1,A
a13: b943  MOV R1, #$43
a15: b829  MOV R0, #$29
a17: 80    MOVX A,@R0
a18: c67b  JZ $a7b
a1a: af    MOV R7,A
a1b: 23b3  MOV A, #$b3
a1d: 0308  ADD A, #$08
a1f: ef1d  DJNZ R7, $a1d
a21: ac    MOV R4,A
a22: bf08  MOV R7, #$08
a24: fc    MOV A,R4
a25: a3    MOVP A,@A
a26: 91    MOVX @R1,A
a27: 1c    INC R4
a28: c9    DEC R1
a29: ef24  DJNZ R7, $a24
a2b: 18    INC R0
a2c: 80    MOVX A,@R0
a2d: 9633  JNZ $a33
a2f: b927  MOV R1, #$27
a31: b16a  MOV @R1, #$6a
a33: 17    INC A
a34: 90    MOVX @R0,A
a35: 03f0  ADD A, #$f0
a37: f66a  JC $a6a
a39: 80    MOVX A,@R0
a3a: 03f7  ADD A, #$f7
a3c: c65b  JZ $a5b
a3e: be18  MOV R6, #$18
a40: e644  JNC $a44
a42: be1c  MOV R6, #$1c
a44: 80    MOVX A,@R0
a45: 03fb  ADD A, #$fb
a47: 964e  JNZ $a4e
a49: c8    DEC R0
a4a: 80    MOVX A,@R0
a4b: 17    INC A
a4c: 90    MOVX @R0,A
a4d: 18    INC R0
a4e: 18    INC R0
a4f: b971  MOV R1, #$71
a51: 80    MOVX A,@R0
a52: 91    MOVX @R1,A
a53: 18    INC R0
a54: c9    DEC R1
a55: 80    MOVX A,@R0
a56: 91    MOVX @R1,A
a57: c9    DEC R1
a58: fe    MOV A,R6
a59: 91    MOVX @R1,A
a5a: 83    RET
a5b: 18    INC R0
a5c: 80    MOVX A,@R0
a5d: 03f6  ADD A, #$f6
a5f: 90    MOVX @R0,A
a60: 18    INC R0
a61: 80    MOVX A,@R0
a62: 03fb  ADD A, #$fb
a64: 90    MOVX @R0,A
a65: c8    DEC R0
a66: be04  MOV R6, #$04
a68: 444f  JMP $24f
a6a: 27    CLR A
a6b: c8    DEC R0
a6c: 90    MOVX @R0,A
a6d: 18    INC R0
a6e: 90    MOVX @R0,A
a6f: 18    INC R0
a70: 90    MOVX @R0,A
a71: 18    INC R0
a72: 90    MOVX @R0,A
a73: b970  MOV R1, #$70
a75: 23f8  MOV A, #$f8
a77: 91    MOVX @R1,A
a78: 19    INC R1
a79: 91    MOVX @R1,A
a7a: 83    RET
a7b: b82d  MOV R0, #$2d
a7d: 80    MOVX A,@R0
a7e: c684  JZ $a84
a80: d356  XRL A, #$56
a82: 9687  JNZ $a87
a84: 236a  MOV A, #$6a
a86: 90    MOVX @R0,A
a87: 80    MOVX A,@R0
a88: a9    MOV R1,A
a89: 81    MOVX A,@R1
a8a: b294  JB5 $a94
a8c: c9    DEC R1
a8d: c9    DEC R1
a8e: c9    DEC R1
a8f: c9    DEC R1
a90: f9    MOV A,R1
a91: 90    MOVX @R0,A
a92: 4473  JMP $273
a94: f9    MOV A,R1
a95: 03fc  ADD A, #$fc
a97: 90    MOVX @R0,A
a98: b86f  MOV R0, #$6f
a9a: 2308  MOV A, #$08
a9c: 90    MOVX @R0,A
a9d: 18    INC R0
a9e: 19    INC R1
a9f: 19    INC R1
aa0: 81    MOVX A,@R1
aa1: 90    MOVX @R0,A
aa2: 18    INC R0
aa3: 19    INC R1
aa4: 81    MOVX A,@R1
aa5: 90    MOVX @R0,A
aa6: b925  MOV R1, #$25
aa8: f1    MOV A,@R1
aa9: bcbb  MOV R4, #$bb
aab: 72af  JB3 $aaf
aad: bcc3  MOV R4, #$c3
aaf: bf08  MOV R7, #$08
ab1: b943  MOV R1, #$43
ab3: fc    MOV A,R4
ab4: a3    MOVP A,@A
ab5: 91    MOVX @R1,A
ab6: c9    DEC R1
ab7: 1c    INC R4
ab8: efb3  DJNZ R7, $ab3
aba: 83    RET
abb: 00    NOP
abc: 2418  JMP $118
abe: 7e    ADDC A,R6
abf: 18    INC R0
ac0: 2400  JMP $100
ac2: 00    NOP
ac3: 10    INC @R0
ac4: 91    MOVX @R1,A
ac5: 5204  JB2 $a04
ac7: c3    ILL
ac8: 2452  JMP $152
aca: 91    MOVX @R1,A
acb: 00    NOP
acc: fc    MOV A,R4
acd: 0308  ADD A, #$08
acf: ac    MOV R4,A
ad0: bb00  MOV R3, #$00
ad2: f0    MOV A,@R0
ad3: 07    DEC A
ad4: 96df  JNZ $adf
ad6: b927  MOV R1, #$27
ad8: b1a5  MOV @R1, #$a5
ada: fb    MOV A,R3
adb: f2df  JB7 $adf
add: b1ab  MOV @R1, #$ab
adf: b97d  MOV R1, #$7d
ae1: 81    MOVX A,@R1
ae2: 6b    ADD A,R3
ae3: 91    MOVX @R1,A
ae4: c9    DEC R1
ae5: 81    MOVX A,@R1
ae6: 6a    ADD A,R2
ae7: 91    MOVX @R1,A
ae8: bff6  MOV R7, #$f6
aea: 6f    ADD A,R7
aeb: e6f3  JNC $af3
aed: 81    MOVX A,@R1
aee: bf70  MOV R7, #$70
af0: 6f    ADD A,R7
af1: e6fd  JNC $afd
af3: ff    MOV A,R7
af4: 37    CPL A
af5: 17    INC A
af6: 91    MOVX @R1,A
af7: b000  MOV @R0, #$00
af9: b831  MOV R0, #$31
afb: b080  MOV @R0, #$80
afd: 6400  JMP $300
aff: 00    NOP
b00: b94b  MOV R1, #$4b
b02: bf08  MOV R7, #$08
b04: fc    MOV A,R4
b05: a3    MOVP A,@A
b06: 91    MOVX @R1,A
b07: c9    DEC R1
b08: 1c    INC R4
b09: ef04  DJNZ R7, $b04
b0b: 83    RET
b0c: 3e    MOVD P6,A
b0d: 3e    MOVD P6,A
b0e: 00    NOP
b0f: 00    NOP
b10: 00    NOP
b11: 00    NOP
b12: 00    NOP
b13: 00    NOP
b14: 3e    MOVD P6,A
b15: 22    ILL
b16: 3e    MOVD P6,A
b17: 3e    MOVD P6,A
b18: 00    NOP
b19: 00    NOP
b1a: 00    NOP
b1b: 00    NOP
b1c: 3e    MOVD P6,A
b1d: 22    ILL
b1e: 3e    MOVD P6,A
b1f: 22    ILL
b20: 3e    MOVD P6,A
b21: 3e    MOVD P6,A
b22: 00    NOP
b23: 00    NOP
b24: 3e    MOVD P6,A
b25: 22    ILL
b26: 3e    MOVD P6,A
b27: 22    ILL
b28: 3e    MOVD P6,A
b29: 22    ILL
b2a: 3e    MOVD P6,A
b2b: 22    ILL
b2c: 18    INC R0
b2d: 997e  ANL P1, #$7e
b2f: 18    INC R0
b30: 18    INC R0
b31: 18    INC R0
b32: 2442  JMP $142
b34: 5a    ANL A,R2
b35: 5a    ANL A,R2
b36: 3c    MOVD P4,A
b37: 18    INC R0
b38: 18    INC R0
b39: 18    INC R0
b3a: 18    INC R0
b3b: 2418  JMP $118
b3d: 997e  ANL P1, #$7e
b3f: 18    INC R0
b40: 18    INC R0
b41: 18    INC R0
b42: 2442  JMP $142
b44: 18    INC R0
b45: 18    INC R0
b46: ff    MOV A,R7
b47: 18    INC R0
b48: 99ff  ANL P1, #$ff
b4a: 00    NOP
b4b: 00    NOP
b4c: 30    XCHD A,@R0
b4d: 30    XCHD A,@R0
b4e: 08    INS A,BUS
b4f: 78    ADDC A,R0
b50: 98fe  ANL BUS, #$fe
b52: 01    ILL
b53: 00    NOP
b54: 60    ADD A,@R0
b55: f0    MOV A,@R0
b56: fe    MOV A,R6
b57: 01    ILL
b58: 00    NOP
b59: 00    NOP
b5a: 00    NOP
b5b: 00    NOP
b5c: 0c    MOVD A,P4
b5d: 0c    MOVD A,P4
b5e: 10    INC @R0
b5f: 1e    INC R6
b60: 19    INC R1
b61: 7f    ADDC A,R7
b62: 80    MOVX A,@R0
b63: 00    NOP
b64: 06    ILL
b65: 0f    MOVD A,P7
b66: 7f    ADDC A,R7
b67: 80    MOVX A,@R0
b68: 00    NOP
b69: 00    NOP
b6a: 00    NOP
b6b: 00    NOP
b6c: 19    INC R1
b6d: 19    INC R1
b6e: 3e    MOVD P6,A
b6f: 58    ANL A,R0
b70: 38    ILL
b71: 18    INC R0
b72: 2466  JMP $166
b74: 9898  ANL BUS, #$98
b76: 7c    ADDC A,R4
b77: 1a    INC R2
b78: 1c    INC R4
b79: 18    INC R0
b7a: 2466  JMP $166
b7c: 995a  ANL P1, #$5a
b7e: 3c    MOVD P4,A
b7f: 18    INC R0
b80: 18    INC R0
b81: 18    INC R0
b82: 2466  JMP $166
b84: 18    INC R0
b85: 18    INC R0
b86: 3c    MOVD P4,A
b87: 5a    ANL A,R2
b88: 39    OUTL P1,A
b89: 18    INC R0
b8a: 2466  JMP $166
b8c: 18    INC R0
b8d: 18    INC R0
b8e: 3c    MOVD P4,A
b8f: 5a    ANL A,R2
b90: 9c    ANLD P4,A
b91: 18    INC R0
b92: 2466  JMP $166
b94: 18    INC R0
b95: 18    INC R0
b96: 3c    MOVD P4,A
b97: 5a    ANL A,R2
b98: 9918  ANL P1, #$18
b9a: 2466  JMP $166
b9c: 00    NOP
b9d: 00    NOP
b9e: 00    NOP
b9f: 40    ORL A,@R0
ba0: 60    ADD A,@R0
ba1: 3c    MOVD P4,A
ba2: 42    MOV A,T
ba3: 83    RET
ba4: 00    NOP
ba5: 00    NOP
ba6: 00    NOP
ba7: 00    NOP
ba8: 00    NOP
ba9: c0    ILL
baa: ff    MOV A,R7
bab: 39    OUTL P1,A
bac: 00    NOP
bad: 00    NOP
bae: 00    NOP
baf: 02    OUTL BUS,A
bb0: 06    ILL
bb1: 3c    MOVD P4,A
bb2: 42    MOV A,T
bb3: c1    ILL
bb4: 00    NOP
bb5: 00    NOP
bb6: 00    NOP
bb7: 00    NOP
bb8: 00    NOP
bb9: 03ff  ADD A, #$ff
bbb: 9c    ANLD P4,A
bbc: 18    INC R0
bbd: 18    INC R0
bbe: 10    INC @R0
bbf: 10    INC @R0
bc0: 10    INC @R0
bc1: 10    INC @R0
bc2: 10    INC @R0
bc3: 18    INC R0
bc4: 18    INC R0
bc5: 18    INC R0
bc6: 10    INC @R0
bc7: 10    INC @R0
bc8: 18    INC R0
bc9: 1416  CALL $016
bcb: 18    INC R0
bcc: 18    INC R0
bcd: 18    INC R0
bce: 10    INC @R0
bcf: 18    INC R0
bd0: 1418  CALL $018
bd2: 2436  JMP $136
bd4: 0c    MOVD A,P4
bd5: 0c    MOVD A,P4
bd6: 08    INS A,BUS
bd7: 08    INS A,BUS
bd8: 18    INC R0
bd9: 28    XCH A,R0
bda: 28    XCH A,R0
bdb: 0c    MOVD A,P4
bdc: 18    INC R0
bdd: 18    INC R0
bde: 08    INS A,BUS
bdf: 08    INS A,BUS
be0: 08    INS A,BUS
be1: 08    INS A,BUS
be2: 08    INS A,BUS
be3: 18    INC R0
be4: 18    INC R0
be5: 18    INC R0
be6: 08    INS A,BUS
be7: 08    INS A,BUS
be8: 18    INC R0
be9: 28    XCH A,R0
bea: 68    ADD A,R0
beb: 18    INC R0
bec: 18    INC R0
bed: 18    INC R0
bee: 08    INS A,BUS
bef: 18    INC R0
bf0: 28    XCH A,R0
bf1: 18    INC R0
bf2: 246c  JMP $16c
bf4: 30    XCHD A,@R0
bf5: 30    XCHD A,@R0
bf6: 10    INC @R0
bf7: 10    INC @R0
bf8: 18    INC R0
bf9: 1414  CALL $014
bfb: 30    XCHD A,@R0
bfc: 00    NOP
bfd: 00    NOP
bfe: 00    NOP
bff: 00    NOP
