400: 8471  JMP $471
402: 0409  JMP $009
404: 93    RETR
405: 00    NOP
406: 041a  JMP $01a
408: e40d  JMP $70d
40a: fc    MOV A,R4
40b: 03a0  ADD A, #$a0
40d: e400  JMP $700
40f: 0444  JMP $044
411: 99fe  ANL P1, #$fe
413: 00    NOP
414: 8421  JMP $421
416: 00    NOP
417: 00    NOP
418: 00    NOP
419: 00    NOP
41a: f5    SEL MB1
41b: 3400  CALL $100
41d: e5    SEL MB0
41e: 99fe  ANL P1, #$fe
420: 00    NOP
421: 7645  JF1 $445
423: 9474  CALL $474
425: b834  MOV R0, #$34
427: 27    CLR A
428: aa    MOV R2,A
429: 17    INC A
42a: a9    MOV R1,A
42b: ab    MOV R3,A
42c: 85    CLR F0
42d: f0    MOV A,@R0
42e: 9632  JNZ $432
430: 748f  CALL $38f
432: f5    SEL MB1
433: 5400  CALL $200
435: 1400  CALL $000
437: bf05  MOV R7, #$05
439: 27    CLR A
43a: aa    MOV R2,A
43b: ab    MOV R3,A
43c: b875  MOV R0, #$75
43e: 7402  CALL $302
440: e5    SEL MB0
441: a5    CLR F1
442: b5    CPL F1
443: 8411  JMP $411
445: bf03  MOV R7, #$03
447: b84e  MOV R0, #$4e
449: b92f  MOV R1, #$2f
44b: 80    MOVX A,@R0
44c: d25c  JB6 $45c
44e: 81    MOVX A,@R1
44f: 17    INC A
450: c665  JZ $465
452: 91    MOVX @R1,A
453: 18    INC R0
454: 18    INC R0
455: 18    INC R0
456: 18    INC R0
457: 19    INC R1
458: ef4b  DJNZ R7, $44b
45a: a400  JMP $500
45c: 538f  ANL A, #$8f
45e: 43a0  ORL A, #$a0
460: 90    MOVX @R0,A
461: 23c0  MOV A, #$c0
463: 8452  JMP $452
465: 91    MOVX @R1,A
466: 42    MOV A,T
467: 530e  ANL A, #$0e
469: aa    MOV R2,A
46a: 80    MOVX A,@R0
46b: 5381  ANL A, #$81
46d: 4a    ORL A,R2
46e: 90    MOVX @R0,A
46f: 8453  JMP $453
471: 55    STRT T
472: 44c3  JMP $2c3
474: b925  MOV R1, #$25
476: f1    MOV A,@R1
477: 531f  ANL A, #$1f
479: 969f  JNZ $49f
47b: 42    MOV A,T
47c: 129f  JB0 $49f
47e: b922  MOV R1, #$22
480: f1    MOV A,@R1
481: ad    MOV R5,A
482: 4301  ORL A, #$01
484: ae    MOV R6,A
485: 03ec  ADD A, #$ec
487: f68b  JC $48b
489: be0f  MOV R6, #$0f
48b: bf05  MOV R7, #$05
48d: b86d  MOV R0, #$6d
48f: b91a  MOV R1, #$1a
491: 80    MOVX A,@R0
492: d3f8  XRL A, #$f8
494: c6a0  JZ $4a0
496: c8    DEC R0
497: c8    DEC R0
498: c8    DEC R0
499: c8    DEC R0
49a: 19    INC R1
49b: 19    INC R1
49c: 19    INC R1
49d: ef91  DJNZ R7, $491
49f: 83    RET
4a0: 42    MOV A,T
4a1: e7    RL A
4a2: 62    MOV T,A
4a3: 5e    ANL A,R6
4a4: 91    MOVX @R1,A
4a5: ba08  MOV R2, #$08
4a7: 5303  ANL A, #$03
4a9: 6a    ADD A,R2
4aa: aa    MOV R2,A
4ab: 81    MOVX A,@R1
4ac: 37    CPL A
4ad: 12b3  JB0 $4b3
4af: fa    MOV A,R2
4b0: 37    CPL A
4b1: 17    INC A
4b2: aa    MOV R2,A
4b3: 19    INC R1
4b4: 42    MOV A,T
4b5: 37    CPL A
4b6: 5e    ANL A,R6
4b7: 91    MOVX @R1,A
4b8: 27    CLR A
4b9: 19    INC R1
4ba: 91    MOVX @R1,A
4bb: fd    MOV A,R5
4bc: 03ec  ADD A, #$ec
4be: b93b  MOV R1, #$3b
4c0: e6c8  JNC $4c8
4c2: 42    MOV A,T
4c3: e7    RL A
4c4: e7    RL A
4c5: 5303  ANL A, #$03
4c7: a1    MOV @R1,A
4c8: 11    INC @R1
4c9: f1    MOV A,@R1
4ca: d304  XRL A, #$04
4cc: 96d0  JNZ $4d0
4ce: 17    INC A
4cf: a1    MOV @R1,A
4d0: 42    MOV A,T
4d1: 92de  JB4 $4de
4d3: b97d  MOV R1, #$7d
4d5: 81    MOVX A,@R1
4d6: 03ab  ADD A, #$ab
4d8: b93b  MOV R1, #$3b
4da: f6de  JC $4de
4dc: b103  MOV @R1, #$03
4de: f1    MOV A,@R1
4df: af    MOV R7,A
4e0: b94a  MOV R1, #$4a
4e2: 19    INC R1
4e3: 19    INC R1
4e4: 19    INC R1
4e5: 19    INC R1
4e6: efe2  DJNZ R7, $4e2
4e8: 81    MOVX A,@R1
4e9: 43c0  ORL A, #$c0
4eb: 91    MOVX @R1,A
4ec: 19    INC R1
4ed: 19    INC R1
4ee: 19    INC R1
4ef: 81    MOVX A,@R1
4f0: 90    MOVX @R0,A
4f1: c9    DEC R1
4f2: c8    DEC R0
4f3: 81    MOVX A,@R1
4f4: 6a    ADD A,R2
4f5: 90    MOVX @R0,A
4f6: c8    DEC R0
4f7: c8    DEC R0
4f8: 27    CLR A
4f9: 90    MOVX @R0,A
4fa: b92a  MOV R1, #$2a
4fc: b108  MOV @R1, #$08
4fe: 83    RET
4ff: 00    NOP
500: 14ec  CALL $0ec
502: d48c  CALL $68c
504: d4d5  CALL $6d5
506: b925  MOV R1, #$25
508: 11    INC @R1
509: f1    MOV A,@R1
50a: 5303  ANL A, #$03
50c: 9623  JNZ $523
50e: b833  MOV R0, #$33
510: f0    MOV A,@R0
511: c61a  JZ $51a
513: f1    MOV A,@R1
514: 5307  ANL A, #$07
516: ba00  MOV R2, #$00
518: c61c  JZ $51c
51a: ba18  MOV R2, #$18
51c: b87b  MOV R0, #$7b
51e: 80    MOVX A,@R0
51f: 5307  ANL A, #$07
521: 4a    ORL A,R2
522: 90    MOVX @R0,A
523: 19    INC R1
524: f1    MOV A,@R1
525: 3235  JB1 $535
527: 9659  JNZ $559
529: b814  MOV R0, #$14
52b: 90    MOVX @R0,A
52c: b823  MOV R0, #$23
52e: b004  MOV @R0, #$04
530: c8    DEC R0
531: b000  MOV @R0, #$00
533: b4c3  CALL $5c3
535: b926  MOV R1, #$26
537: b101  MOV @R1, #$01
539: b832  MOV R0, #$32
53b: 10    INC @R0
53c: bf0c  MOV R7, #$0c
53e: 23f8  MOV A, #$f8
540: b87d  MOV R0, #$7d
542: 90    MOVX @R0,A
543: c8    DEC R0
544: 90    MOVX @R0,A
545: c8    DEC R0
546: c8    DEC R0
547: c8    DEC R0
548: ef42  DJNZ R7, $542
54a: f414  CALL $714
54c: b859  MOV R0, #$59
54e: bc8f  MOV R4, #$8f
550: bf0c  MOV R7, #$0c
552: fc    MOV A,R4
553: a3    MOVP A,@A
554: 90    MOVX @R0,A
555: 1c    INC R4
556: c8    DEC R0
557: ef52  DJNZ R7, $552
559: b827  MOV R0, #$27
55b: b934  MOV R1, #$34
55d: f4ea  CALL $7ea
55f: f0    MOV A,@R0
560: c666  JZ $566
562: b000  MOV @R0, #$00
564: 34a2  CALL $1a2
566: ba26  MOV R2, #$26
568: bb2a  MOV R3, #$2a
56a: b835  MOV R0, #$35
56c: f0    MOV A,@R0
56d: c671  JZ $571
56f: bbaa  MOV R3, #$aa
571: 15    DIS I
572: 14e7  CALL $0e7
574: b8a3  MOV R0, #$a3
576: b923  MOV R1, #$23
578: f1    MOV A,@R1
579: 90    MOVX @R0,A
57a: f42f  CALL $72f
57c: d484  CALL $684
57e: d400  CALL $600
580: 3476  CALL $176
582: 3434  CALL $134
584: b8a2  MOV R0, #$a2
586: 238f  MOV A, #$8f
588: 90    MOVX @R0,A
589: 14ec  CALL $0ec
58b: 15    DIS I
58c: a5    CLR F1
58d: 8411  JMP $411
58f: 22    ILL
590: 4d    ORL A,R5
591: 00    NOP
592: 82    ILL
593: 6a    ADD A,R2
594: 4d    ORL A,R5
595: 00    NOP
596: 84b2  JMP $4b2
598: 4d    ORL A,R5
599: 00    NOP
59a: 8880  ORL BUS, #$80
59c: be0e  MOV R6, #$0e
59e: d2b0  JB6 $5b0
5a0: f2ae  JB7 $5ae
5a2: f8    MOV A,R0
5a3: 03f5  ADD A, #$f5
5a5: f6b0  JC $5b0
5a7: be06  MOV R6, #$06
5a9: f8    MOV A,R0
5aa: d304  XRL A, #$04
5ac: 96b0  JNZ $5b0
5ae: be02  MOV R6, #$02
5b0: 80    MOVX A,@R0
5b1: 533f  ANL A, #$3f
5b3: ad    MOV R5,A
5b4: 18    INC R0
5b5: 18    INC R0
5b6: 344b  CALL $14b
5b8: fd    MOV A,R5
5b9: 91    MOVX @R1,A
5ba: 19    INC R1
5bb: fe    MOV A,R6
5bc: 91    MOVX @R1,A
5bd: 19    INC R1
5be: 19    INC R1
5bf: 19    INC R1
5c0: eb9b  DJNZ R3, $59b
5c2: 83    RET
5c3: b800  MOV R0, #$00
5c5: b90c  MOV R1, #$0c
5c7: bf04  MOV R7, #$04
5c9: 81    MOVX A,@R1
5ca: 17    INC A
5cb: 37    CPL A
5cc: 17    INC A
5cd: aa    MOV R2,A
5ce: 80    MOVX A,@R0
5cf: 17    INC A
5d0: 6a    ADD A,R2
5d1: c6da  JZ $5da
5d3: 85    CLR F0
5d4: 95    CPL F0
5d5: f6e6  JC $5e6
5d7: 85    CLR F0
5d8: e6de  JNC $5de
5da: 18    INC R0
5db: 19    INC R1
5dc: efc9  DJNZ R7, $5c9
5de: bf06  MOV R7, #$06
5e0: f459  CALL $759
5e2: b819  MOV R0, #$19
5e4: 27    CLR A
5e5: 90    MOVX @R0,A
5e6: b80f  MOV R0, #$0f
5e8: b903  MOV R1, #$03
5ea: bf04  MOV R7, #$04
5ec: 80    MOVX A,@R0
5ed: b6f0  JF0 $5f0
5ef: 91    MOVX @R1,A
5f0: 27    CLR A
5f1: 90    MOVX @R0,A
5f2: c9    DEC R1
5f3: c8    DEC R0
5f4: efec  DJNZ R7, $5ec
5f6: 83    RET
5f7: 00    NOP
5f8: 00    NOP
5f9: 00    NOP
5fa: 00    NOP
5fb: 00    NOP
5fc: 00    NOP
5fd: 00    NOP
5fe: 00    NOP
5ff: 00    NOP
600: 15    DIS I
601: 897c  ORL P1, #$7c
603: 99e7  ANL P1, #$e7
605: b825  MOV R0, #$25
607: f0    MOV A,@R0
608: a5    CLR F1
609: 15    DIS I
60a: 5303  ANL A, #$03
60c: c63f  JZ $63f
60e: 1211  JB0 $611
610: b5    CPL F1
611: f43c  CALL $73c
613: bcc7  MOV R4, #$c7
615: b808  MOV R0, #$08
617: b962  MOV R1, #$62
619: 761f  JF1 $61f
61b: b800  MOV R0, #$00
61d: b942  MOV R1, #$42
61f: bb04  MOV R3, #$04
621: b49b  CALL $59b
623: b972  MOV R1, #$72
625: b809  MOV R0, #$09
627: 762d  JF1 $62d
629: b952  MOV R1, #$52
62b: b801  MOV R0, #$01
62d: bb04  MOV R3, #$04
62f: b49b  CALL $59b
631: 14e7  CALL $0e7
633: b835  MOV R0, #$35
635: f0    MOV A,@R0
636: ba28  MOV R2, #$28
638: c63c  JZ $63c
63a: baa8  MOV R2, #$a8
63c: fa    MOV A,R2
63d: c486  JMP $686
63f: bf09  MOV R7, #$09
641: b9c0  MOV R1, #$c0
643: b835  MOV R0, #$35
645: f0    MOV A,@R0
646: 966a  JNZ $66a
648: b810  MOV R0, #$10
64a: 80    MOVX A,@R0
64b: 91    MOVX @R1,A
64c: 18    INC R0
64d: 19    INC R1
64e: ef4a  DJNZ R7, $64a
650: bf09  MOV R7, #$09
652: b8d0  MOV R0, #$d0
654: 2301  MOV A, #$01
656: 90    MOVX @R0,A
657: 18    INC R0
658: ef56  DJNZ R7, $656
65a: bf09  MOV R7, #$09
65c: b8e0  MOV R0, #$e0
65e: 23ff  MOV A, #$ff
660: 90    MOVX @R0,A
661: 27    CLR A
662: 18    INC R0
663: 90    MOVX @R0,A
664: ef62  DJNZ R7, $662
666: 37    CPL A
667: 90    MOVX @R0,A
668: c431  JMP $631
66a: 2380  MOV A, #$80
66c: 91    MOVX @R1,A
66d: 19    INC R1
66e: ef6c  DJNZ R7, $66c
670: bf09  MOV R7, #$09
672: b9e0  MOV R1, #$e0
674: b832  MOV R0, #$32
676: 80    MOVX A,@R0
677: 91    MOVX @R1,A
678: 18    INC R0
679: 19    INC R1
67a: ef76  DJNZ R7, $676
67c: 27    CLR A
67d: 91    MOVX @R1,A
67e: 14e7  CALL $0e7
680: 23a8  MOV A, #$a8
682: c486  JMP $686
684: 14e7  CALL $0e7
686: c5    SEL RB0
687: b8a0  MOV R0, #$a0
689: 90    MOVX @R0,A
68a: d5    SEL RB1
68b: 83    RET
68c: bf08  MOV R7, #$08
68e: b86d  MOV R0, #$6d
690: 80    MOVX A,@R0
691: ac    MOV R4,A
692: b925  MOV R1, #$25
694: c8    DEC R0
695: c8    DEC R0
696: c8    DEC R0
697: 80    MOVX A,@R0
698: f2c8  JB7 $6c8
69a: be06  MOV R6, #$06
69c: b2a0  JB5 $6a0
69e: be08  MOV R6, #$08
6a0: f1    MOV A,@R1
6a1: bd31  MOV R5, #$31
6a3: cc    DEC R4
6a4: cc    DEC R4
6a5: 12b9  JB0 $6b9
6a7: 32b9  JB1 $6b9
6a9: 1c    INC R4
6aa: 1c    INC R4
6ab: be0a  MOV R6, #$0a
6ad: bd29  MOV R5, #$29
6af: 92b3  JB4 $6b3
6b1: bd10  MOV R5, #$10
6b3: 80    MOVX A,@R0
6b4: 37    CPL A
6b5: b2b9  JB5 $6b9
6b7: be02  MOV R6, #$02
6b9: 344b  CALL $14b
6bb: 18    INC R0
6bc: fd    MOV A,R5
6bd: 90    MOVX @R0,A
6be: c8    DEC R0
6bf: 80    MOVX A,@R0
6c0: 53f0  ANL A, #$f0
6c2: 4e    ORL A,R6
6c3: 90    MOVX @R0,A
6c4: c8    DEC R0
6c5: ef90  DJNZ R7, $690
6c7: 83    RET
6c8: ae    MOV R6,A
6c9: 37    CPL A
6ca: b2d1  JB5 $6d1
6cc: f1    MOV A,@R1
6cd: bd16  MOV R5, #$16
6cf: 52d3  JB2 $6d3
6d1: bd2f  MOV R5, #$2f
6d3: c4b9  JMP $6b9
6d5: f4bc  CALL $7bc
6d7: b904  MOV R1, #$04
6d9: 2336  MOV A, #$36
6db: 91    MOVX @R1,A
6dc: b821  MOV R0, #$21
6de: f0    MOV A,@R0
6df: c6ff  JZ $6ff
6e1: 07    DEC A
6e2: a0    MOV @R0,A
6e3: be01  MOV R6, #$01
6e5: 42    MOV A,T
6e6: 12ee  JB0 $6ee
6e8: 18    INC R0
6e9: f0    MOV A,@R0
6ea: 17    INC A
6eb: c6ee  JZ $6ee
6ed: a0    MOV @R0,A
6ee: b90f  MOV R1, #$0f
6f0: bf04  MOV R7, #$04
6f2: 81    MOVX A,@R1
6f3: 6e    ADD A,R6
6f4: 91    MOVX @R1,A
6f5: 03f6  ADD A, #$f6
6f7: e6ff  JNC $6ff
6f9: 91    MOVX @R1,A
6fa: be01  MOV R6, #$01
6fc: c9    DEC R1
6fd: eff2  DJNZ R7, $6f2
6ff: 83    RET
700: e60b  JNC $70b
702: fc    MOV A,R4
703: a3    MOVP A,@A
704: a9    MOV R1,A
705: 1c    INC R4
706: fc    MOV A,R4
707: a3    MOVP A,@A
708: aa    MOV R2,A
709: 044b  JMP $04b
70b: 0444  JMP $044
70d: 14ec  CALL $0ec
70f: b82e  MOV R0, #$2e
711: 90    MOVX @R0,A
712: a400  JMP $500
714: b97f  MOV R1, #$7f
716: bf0d  MOV R7, #$0d
718: b822  MOV R0, #$22
71a: f8    MOV A,R0
71b: a3    MOVP A,@A
71c: 91    MOVX @R1,A
71d: 18    INC R0
71e: c9    DEC R1
71f: ef1a  DJNZ R7, $71a
721: 83    RET
722: 30    XCHD A,@R0
723: 00    NOP
724: 80    MOVX A,@R0
725: 4c    ORL A,R4
726: 18    INC R0
727: 00    NOP
728: ab    MOV R3,A
729: 69    ADD A,R1
72a: 38    ILL
72b: 00    NOP
72c: 80    MOVX A,@R0
72d: 4c    ORL A,R4
72e: 28    XCH A,R0
72f: b8a0  MOV R0, #$a0
731: b9a5  MOV R1, #$a5
733: fb    MOV A,R3
734: 90    MOVX @R0,A
735: 81    MOVX A,@R1
736: c9    DEC R1
737: 81    MOVX A,@R1
738: 6a    ADD A,R2
739: e631  JNC $731
73b: 83    RET
73c: b841  MOV R0, #$41
73e: bbc7  MOV R3, #$c7
740: 2311  MOV A, #$11
742: f454  CALL $754
744: b851  MOV R0, #$51
746: 2319  MOV A, #$19
748: f454  CALL $754
74a: b861  MOV R0, #$61
74c: 2352  MOV A, #$52
74e: f454  CALL $754
750: b871  MOV R0, #$71
752: 235a  MOV A, #$5a
754: 90    MOVX @R0,A
755: c8    DEC R0
756: fb    MOV A,R3
757: 90    MOVX @R0,A
758: 83    RET
759: b805  MOV R0, #$05
75b: 230d  MOV A, #$0d
75d: 90    MOVX @R0,A
75e: 18    INC R0
75f: ef5d  DJNZ R7, $75d
761: 07    DEC A
762: 90    MOVX @R0,A
763: 83    RET
764: 41    ORL A,@R1
765: d5    SEL RB1
766: 81    MOVX A,@R1
767: 0421  JMP $021
769: 00    NOP
76a: 42    MOV A,T
76b: ff    MOV A,R7
76c: 81    MOVX A,@R1
76d: 0448  JMP $048
76f: df    XRL A,R7
770: 81    MOVX A,@R1
771: 08    INS A,BUS
772: 48    ORL A,R0
773: d8    XRL A,R0
774: 45    STRT CNT
775: d421  CALL $621
777: 00    NOP
778: 81    MOVX A,@R1
779: 1c    INC R4
77a: 81    MOVX A,@R1
77b: 00    NOP
77c: 2621  JNT0 $721
77e: 00    NOP
77f: 81    MOVX A,@R1
780: 20    XCH A,@R0
781: 47    SWAP
782: c8    DEC R0
783: 48    ORL A,R0
784: c421  JMP $621
786: 00    NOP
787: 81    MOVX A,@R1
788: 1447  CALL $047
78a: c5    SEL RB0
78b: 81    MOVX A,@R1
78c: 18    INC R0
78d: 48    ORL A,R0
78e: c8    DEC R0
78f: 21    XCH A,@R1
790: 00    NOP
791: 81    MOVX A,@R1
792: 2442  JMP $142
794: e621  JNC $721
796: 00    NOP
797: 83    RET
798: 20    XCH A,@R0
799: 83    RET
79a: 1483  CALL $083
79c: 10    INC @R0
79d: 21    XCH A,@R1
79e: 00    NOP
79f: 83    RET
7a0: 20    XCH A,@R0
7a1: 8424  JMP $424
7a3: 21    XCH A,@R1
7a4: 00    NOP
7a5: 82    ILL
7a6: 18    INC R0
7a7: 8820  ORL BUS, #$20
7a9: 21    XCH A,@R1
7aa: 00    NOP
7ab: 82    ILL
7ac: 18    INC R0
7ad: 8804  ORL BUS, #$04
7af: 21    XCH A,@R1
7b0: 00    NOP
7b1: 81    MOVX A,@R1
7b2: 20    XCH A,@R0
7b3: 45    STRT CNT
7b4: ff    MOV A,R7
7b5: 45    STRT CNT
7b6: f7    RLC A
7b7: 45    STRT CNT
7b8: f426  CALL $726
7ba: 21    XCH A,@R1
7bb: 00    NOP
7bc: 14b0  CALL $0b0
7be: 15    DIS I
7bf: aa    MOV R2,A
7c0: b919  MOV R1, #$19
7c2: f2d3  JB7 $7d3
7c4: 81    MOVX A,@R1
7c5: f2d2  JB7 $7d2
7c7: 17    INC A
7c8: 4380  ORL A, #$80
7ca: 91    MOVX @R1,A
7cb: d387  XRL A, #$87
7cd: 96d2  JNZ $7d2
7cf: 2386  MOV A, #$86
7d1: 91    MOVX @R1,A
7d2: 83    RET
7d3: b804  MOV R0, #$04
7d5: 81    MOVX A,@R1
7d6: 5307  ANL A, #$07
7d8: 91    MOVX @R1,A
7d9: 68    ADD A,R0
7da: a8    MOV R0,A
7db: fa    MOV A,R2
7dc: 533f  ANL A, #$3f
7de: aa    MOV R2,A
7df: 03d2  ADD A, #$d2
7e1: f6e9  JC $7e9
7e3: fa    MOV A,R2
7e4: 90    MOVX @R0,A
7e5: b827  MOV R0, #$27
7e7: b056  MOV @R0, #$56
7e9: 83    RET
7ea: f1    MOV A,@R1
7eb: c6ff  JZ $7ff
7ed: 03e0  ADD A, #$e0
7ef: f6ff  JC $7ff
7f1: f0    MOV A,@R0
7f2: d387  XRL A, #$87
7f4: c6ff  JZ $7ff
7f6: b000  MOV @R0, #$00
7f8: c5    SEL RB0
7f9: fb    MOV A,R3
7fa: d5    SEL RB1
7fb: 96ff  JNZ $7ff
7fd: b087  MOV @R0, #$87
7ff: 83    RET
800: 141f  CALL $01f
802: 041f  JMP $01f
804: b832  MOV R0, #$32
806: 80    MOVX A,@R0
807: af    MOV R7,A
808: b817  MOV R0, #$17
80a: 18    INC R0
80b: 18    INC R0
80c: 18    INC R0
80d: ef0a  DJNZ R7, $80a
80f: 83    RET
810: b832  MOV R0, #$32
812: 80    MOVX A,@R0
813: af    MOV R7,A
814: b871  MOV R0, #$71
816: c8    DEC R0
817: c8    DEC R0
818: c8    DEC R0
819: c8    DEC R0
81a: ef16  DJNZ R7, $816
81c: 83    RET
81d: 24ce  JMP $1ce
81f: b832  MOV R0, #$32
821: 80    MOVX A,@R0
822: 03fb  ADD A, #$fb
824: e628  JNC $828
826: 27    CLR A
827: 90    MOVX @R0,A
828: 80    MOVX A,@R0
829: 17    INC A
82a: 90    MOVX @R0,A
82b: af    MOV R7,A
82c: b817  MOV R0, #$17
82e: b970  MOV R1, #$70
830: 18    INC R0
831: 18    INC R0
832: 18    INC R0
833: c9    DEC R1
834: c9    DEC R1
835: c9    DEC R1
836: c9    DEC R1
837: ef30  DJNZ R7, $830
839: 81    MOVX A,@R1
83a: d3f8  XRL A, #$f8
83c: c60f  JZ $80f
83e: c9    DEC R1
83f: c9    DEC R1
840: 81    MOVX A,@R1
841: b21d  JB5 $81d
843: 80    MOVX A,@R0
844: f2cf  JB7 $8cf
846: d2c7  JB6 $8c7
848: baff  MOV R2, #$ff
84a: 124e  JB0 $84e
84c: ba01  MOV R2, #$01
84e: 18    INC R0
84f: 80    MOVX A,@R0
850: f2df  JB7 $8df
852: d2d7  JB6 $8d7
854: bbff  MOV R3, #$ff
856: 125a  JB0 $85a
858: bb01  MOV R3, #$01
85a: 1410  CALL $010
85c: 3400  CALL $100
85e: fe    MOV A,R6
85f: 96e7  JNZ $8e7
861: 1410  CALL $010
863: 7400  CALL $300
865: 80    MOVX A,@R0
866: 6b    ADD A,R3
867: 90    MOVX @R0,A
868: c8    DEC R0
869: 80    MOVX A,@R0
86a: 6a    ADD A,R2
86b: 90    MOVX @R0,A
86c: b92a  MOV R1, #$2a
86e: 1404  CALL $004
870: fe    MOV A,R6
871: 5311  ANL A, #$11
873: c67c  JZ $87c
875: 14bd  CALL $0bd
877: 80    MOVX A,@R0
878: d301  XRL A, #$01
87a: 90    MOVX @R0,A
87b: 11    INC @R1
87c: 18    INC R0
87d: fe    MOV A,R6
87e: 37    CPL A
87f: f287  JB7 $887
881: 80    MOVX A,@R0
882: 0302  ADD A, #$02
884: f687  JC $887
886: 90    MOVX @R0,A
887: fe    MOV A,R6
888: f29b  JB7 $89b
88a: 929b  JB4 $89b
88c: 37    CPL A
88d: 329b  JB1 $89b
88f: 80    MOVX A,@R0
890: 53fe  ANL A, #$fe
892: c69a  JZ $89a
894: 80    MOVX A,@R0
895: 03fe  ADD A, #$fe
897: 11    INC @R1
898: d301  XRL A, #$01
89a: 90    MOVX @R0,A
89b: 80    MOVX A,@R0
89c: 129f  JB0 $89f
89e: 83    RET
89f: 53e0  ANL A, #$e0
8a1: 969e  JNZ $89e
8a3: 80    MOVX A,@R0
8a4: 37    CPL A
8a5: 17    INC A
8a6: ac    MOV R4,A
8a7: 18    INC R0
8a8: 80    MOVX A,@R0
8a9: 0302  ADD A, #$02
8ab: 90    MOVX @R0,A
8ac: 6c    ADD A,R4
8ad: f6b0  JC $8b0
8af: 83    RET
8b0: 27    CLR A
8b1: 90    MOVX @R0,A
8b2: c8    DEC R0
8b3: 80    MOVX A,@R0
8b4: 53fe  ANL A, #$fe
8b6: 90    MOVX @R0,A
8b7: c6bc  JZ $8bc
8b9: 03fe  ADD A, #$fe
8bb: 90    MOVX @R0,A
8bc: c8    DEC R0
8bd: 80    MOVX A,@R0
8be: 53fe  ANL A, #$fe
8c0: c69e  JZ $89e
8c2: 80    MOVX A,@R0
8c3: 03fe  ADD A, #$fe
8c5: 90    MOVX @R0,A
8c6: 83    RET
8c7: bafe  MOV R2, #$fe
8c9: 124e  JB0 $84e
8cb: ba02  MOV R2, #$02
8cd: 044e  JMP $04e
8cf: bafd  MOV R2, #$fd
8d1: 124e  JB0 $84e
8d3: ba03  MOV R2, #$03
8d5: 044e  JMP $04e
8d7: bbfe  MOV R3, #$fe
8d9: 125a  JB0 $85a
8db: bb02  MOV R3, #$02
8dd: 045a  JMP $05a
8df: bbfd  MOV R3, #$fd
8e1: 125a  JB0 $85a
8e3: bb03  MOV R3, #$03
8e5: 045a  JMP $05a
8e7: 12f1  JB0 $8f1
8e9: 92f1  JB4 $8f1
8eb: f261  JB7 $861
8ed: 32f8  JB1 $8f8
8ef: 0461  JMP $061
8f1: b828  MOV R0, #$28
8f3: f0    MOV A,@R0
8f4: aa    MOV R2,A
8f5: fe    MOV A,R6
8f6: 04eb  JMP $0eb
8f8: b829  MOV R0, #$29
8fa: f0    MOV A,@R0
8fb: ab    MOV R3,A
8fc: 0461  JMP $061
8fe: 00    NOP
8ff: 00    NOP
900: 85    CLR F0
901: a5    CLR F1
902: 27    CLR A
903: ae    MOV R6,A
904: b928  MOV R1, #$28
906: a1    MOV @R1,A
907: 19    INC R1
908: a1    MOV @R1,A
909: fa    MOV A,R2
90a: f20d  JB7 $90d
90c: 95    CPL F0
90d: fb    MOV A,R3
90e: f211  JB7 $911
910: b5    CPL F1
911: 80    MOVX A,@R0
912: 6b    ADD A,R3
913: 37    CPL A
914: 17    INC A
915: ac    MOV R4,A
916: c8    DEC R0
917: 80    MOVX A,@R0
918: 6a    ADD A,R2
919: 37    CPL A
91a: 17    INC A
91b: ad    MOV R5,A
91c: b800  MOV R0, #$00
91e: 0308  ADD A, #$08
920: f63a  JC $93a
922: fd    MOV A,R5
923: 0392  ADD A, #$92
925: c638  JZ $938
927: e638  JNC $938
929: b911  MOV R1, #$11
92b: bf09  MOV R7, #$09
92d: fd    MOV A,R5
92e: 69    ADD A,R1
92f: f63c  JC $93c
931: f9    MOV A,R1
932: 0310  ADD A, #$10
934: a9    MOV R1,A
935: 18    INC R0
936: ef2d  DJNZ R7, $92d
938: b808  MOV R0, #$08
93a: be01  MOV R6, #$01
93c: b928  MOV R1, #$28
93e: a1    MOV @R1,A
93f: f8    MOV A,R0
940: 0310  ADD A, #$10
942: a8    MOV R0,A
943: fc    MOV A,R4
944: b901  MOV R1, #$01
946: bd27  MOV R5, #$27
948: bf07  MOV R7, #$07
94a: fc    MOV A,R4
94b: 6d    ADD A,R5
94c: f65b  JC $95b
94e: fd    MOV A,R5
94f: 0318  ADD A, #$18
951: ad    MOV R5,A
952: 19    INC R1
953: ef4a  DJNZ R7, $94a
955: fe    MOV A,R6
956: 4302  ORL A, #$02
958: ae    MOV R6,A
959: 24b4  JMP $1b4
95b: 85    CLR F0
95c: 7660  JF1 $960
95e: 2466  JMP $166
960: 23fd  MOV A, #$fd
962: 6c    ADD A,R4
963: 6d    ADD A,R5
964: e67c  JNC $97c
966: 23f1  MOV A, #$f1
968: c9    DEC R1
969: 6c    ADD A,R4
96a: 6d    ADD A,R5
96b: e6aa  JNC $9aa
96d: c67a  JZ $97a
96f: af    MOV R7,A
970: 0302  ADD A, #$02
972: f675  JC $975
974: 95    CPL F0
975: ff    MOV A,R7
976: 767a  JF1 $97a
978: 247c  JMP $17c
97a: 37    CPL A
97b: 17    INC A
97c: ad    MOV R5,A
97d: fb    MOV A,R3
97e: c681  JZ $981
980: 6d    ADD A,R5
981: ad    MOV R5,A
982: fe    MOV A,R6
983: 4302  ORL A, #$02
985: ae    MOV R6,A
986: f9    MOV A,R1
987: af    MOV R7,A
988: ac    MOV R4,A
989: b929  MOV R1, #$29
98b: fd    MOV A,R5
98c: a1    MOV @R1,A
98d: 80    MOVX A,@R0
98e: 77    RR A
98f: ef8e  DJNZ R7, $98e
991: 12ab  JB0 $9ab
993: b928  MOV R1, #$28
995: 23f6  MOV A, #$f6
997: 61    ADD A,@R1
998: e6a6  JNC $9a6
99a: f8    MOV A,R0
99b: 03f0  ADD A, #$f0
99d: c6a6  JZ $9a6
99f: c8    DEC R0
9a0: 80    MOVX A,@R0
9a1: 77    RR A
9a2: eca1  DJNZ R4, $9a1
9a4: 12ab  JB0 $9ab
9a6: fe    MOV A,R6
9a7: 4380  ORL A, #$80
9a9: ae    MOV R6,A
9aa: 83    RET
9ab: b928  MOV R1, #$28
9ad: 23f6  MOV A, #$f6
9af: 61    ADD A,@R1
9b0: e6b4  JNC $9b4
9b2: b6b9  JF0 $9b9
9b4: 237f  MOV A, #$7f
9b6: 5e    ANL A,R6
9b7: ae    MOV R6,A
9b8: 83    RET
9b9: f1    MOV A,@R1
9ba: 03f0  ADD A, #$f0
9bc: af    MOV R7,A
9bd: fa    MOV A,R2
9be: f2c3  JB7 $9c3
9c0: ff    MOV A,R7
9c1: 24c6  JMP $1c6
9c3: ff    MOV A,R7
9c4: 37    CPL A
9c5: 17    INC A
9c6: 6a    ADD A,R2
9c7: a1    MOV @R1,A
9c8: fe    MOV A,R6
9c9: 4310  ORL A, #$10
9cb: ae    MOV R6,A
9cc: 24b4  JMP $1b4
9ce: 19    INC R1
9cf: 19    INC R1
9d0: 19    INC R1
9d1: b82a  MOV R0, #$2a
9d3: b004  MOV @R0, #$04
9d5: f9    MOV A,R1
9d6: a8    MOV R0,A
9d7: ba00  MOV R2, #$00
9d9: bb02  MOV R3, #$02
9db: 7400  CALL $300
9dd: 80    MOVX A,@R0
9de: 6b    ADD A,R3
9df: 90    MOVX @R0,A
9e0: 034a  ADD A, #$4a
9e2: f6e5  JC $9e5
9e4: 83    RET
9e5: 00    NOP
9e6: b929  MOV R1, #$29
9e8: 2301  MOV A, #$01
9ea: 91    MOVX @R1,A
9eb: 19    INC R1
9ec: 27    CLR A
9ed: 91    MOVX @R1,A
9ee: 19    INC R1
9ef: 80    MOVX A,@R0
9f0: 91    MOVX @R1,A
9f1: 19    INC R1
9f2: c8    DEC R0
9f3: 80    MOVX A,@R0
9f4: 91    MOVX @R1,A
9f5: 23f8  MOV A, #$f8
9f7: 90    MOVX @R0,A
9f8: 18    INC R0
9f9: 90    MOVX @R0,A
9fa: 83    RET
9fb: 00    NOP
9fc: 00    NOP
9fd: 00    NOP
9fe: 00    NOP
9ff: 00    NOP
a00: b925  MOV R1, #$25
a02: f1    MOV A,@R1
a03: 1254  JB0 $a54
a05: b82b  MOV R0, #$2b
a07: f0    MOV A,@R0
a08: c653  JZ $a53
a0a: 27    CLR A
a0b: bf04  MOV R7, #$04
a0d: a0    MOV @R0,A
a0e: 18    INC R0
a0f: fa    MOV A,R2
a10: c613  JZ $a13
a12: a0    MOV @R0,A
a13: 27    CLR A
a14: 18    INC R0
a15: a0    MOV @R0,A
a16: ef14  DJNZ R7, $a14
a18: b97c  MOV R1, #$7c
a1a: b878  MOV R0, #$78
a1c: 81    MOVX A,@R1
a1d: 6a    ADD A,R2
a1e: 91    MOVX @R1,A
a1f: fa    MOV A,R2
a20: 9625  JNZ $a25
a22: 80    MOVX A,@R0
a23: 07    DEC A
a24: 91    MOVX @R1,A
a25: 19    INC R1
a26: 81    MOVX A,@R1
a27: 6b    ADD A,R3
a28: 91    MOVX @R1,A
a29: 18    INC R0
a2a: 80    MOVX A,@R0
a2b: 37    CPL A
a2c: 17    INC A
a2d: ad    MOV R5,A
a2e: 81    MOVX A,@R1
a2f: 0306  ADD A, #$06
a31: 6d    ADD A,R5
a32: bc7f  MOV R4, #$7f
a34: e651  JNC $a51
a36: bc97  MOV R4, #$97
a38: fb    MOV A,R3
a39: c648  JZ $a48
a3b: c9    DEC R1
a3c: b825  MOV R0, #$25
a3e: f0    MOV A,@R0
a3f: bc9f  MOV R4, #$9f
a41: 5248  JB2 $a48
a43: bca7  MOV R4, #$a7
a45: 81    MOVX A,@R1
a46: 17    INC A
a47: 91    MOVX @R1,A
a48: fa    MOV A,R2
a49: c651  JZ $a51
a4b: bc87  MOV R4, #$87
a4d: f251  JB7 $a51
a4f: bc8f  MOV R4, #$8f
a51: 6473  JMP $373
a53: 83    RET
a54: b832  MOV R0, #$32
a56: f0    MOV A,@R0
a57: 9691  JNZ $a91
a59: b83d  MOV R0, #$3d
a5b: f0    MOV A,@R0
a5c: 5305  ANL A, #$05
a5e: d305  XRL A, #$05
a60: 96f3  JNZ $af3
a62: b875  MOV R0, #$75
a64: b97d  MOV R1, #$7d
a66: 745f  CALL $35f
a68: 03f5  ADD A, #$f5
a6a: f6f3  JC $af3
a6c: c9    DEC R1
a6d: c8    DEC R0
a6e: 745f  CALL $35f
a70: 03f9  ADD A, #$f9
a72: f6f3  JC $af3
a74: c8    DEC R0
a75: 80    MOVX A,@R0
a76: b821  MOV R0, #$21
a78: b932  MOV R1, #$32
a7a: 9283  JB4 $a83
a7c: 11    INC @R1
a7d: f0    MOV A,@R0
a7e: 0305  ADD A, #$05
a80: a0    MOV @R0,A
a81: 44f3  JMP $2f3
a83: 19    INC R1
a84: 11    INC @R1
a85: f0    MOV A,@R0
a86: 030a  ADD A, #$0a
a88: a0    MOV @R0,A
a89: b827  MOV R0, #$27
a8b: b09f  MOV @R0, #$9f
a8d: b875  MOV R0, #$75
a8f: 6444  JMP $344
a91: f1    MOV A,@R1
a92: 3299  JB1 $a99
a94: f0    MOV A,@R0
a95: 17    INC A
a96: a0    MOV @R0,A
a97: c68d  JZ $a8d
a99: b975  MOV R1, #$75
a9b: b87d  MOV R0, #$7d
a9d: 80    MOVX A,@R0
a9e: 17    INC A
a9f: af    MOV R7,A
aa0: 91    MOVX @R1,A
aa1: c8    DEC R0
aa2: c9    DEC R1
aa3: 80    MOVX A,@R0
aa4: 91    MOVX @R1,A
aa5: b825  MOV R0, #$25
aa7: 19    INC R1
aa8: f0    MOV A,@R0
aa9: bcaf  MOV R4, #$af
aab: bd01  MOV R5, #$01
aad: 52b7  JB2 $ab7
aaf: bdff  MOV R5, #$ff
ab1: bcb7  MOV R4, #$b7
ab3: 81    MOVX A,@R1
ab4: 03f8  ADD A, #$f8
ab6: 91    MOVX @R1,A
ab7: b831  MOV R0, #$31
ab9: f0    MOV A,@R0
aba: f2cd  JB7 $acd
abc: b82e  MOV R0, #$2e
abe: f0    MOV A,@R0
abf: 96e5  JNZ $ae5
ac1: b6d1  JF0 $ad1
ac3: c8    DEC R0
ac4: fa    MOV A,R2
ac5: 96d1  JNZ $ad1
ac7: fd    MOV A,R5
ac8: a0    MOV @R0,A
ac9: fb    MOV A,R3
aca: c6d1  JZ $ad1
acc: a0    MOV @R0,A
acd: bcaf  MOV R4, #$af
acf: ff    MOV A,R7
ad0: 91    MOVX @R1,A
ad1: fc    MOV A,R4
ad2: 74f7  CALL $3f7
ad4: b82c  MOV R0, #$2c
ad6: f0    MOV A,@R0
ad7: ba04  MOV R2, #$04
ad9: 37    CPL A
ada: f2e2  JB7 $ae2
adc: bafc  MOV R2, #$fc
ade: fc    MOV A,R4
adf: 0310  ADD A, #$10
ae1: ac    MOV R4,A
ae2: c9    DEC R1
ae3: 6470  JMP $370
ae5: c8    DEC R0
ae6: f0    MOV A,@R0
ae7: beff  MOV R6, #$ff
ae9: c6ef  JZ $aef
aeb: f2ef  JB7 $aef
aed: be08  MOV R6, #$08
aef: 81    MOVX A,@R1
af0: 6e    ADD A,R6
af1: 44d0  JMP $2d0
af3: b92a  MOV R1, #$2a
af5: 81    MOVX A,@R1
af6: d308  XRL A, #$08
af8: 96fc  JNZ $afc
afa: 64cf  JMP $3cf
afc: bcaf  MOV R4, #$af
afe: 4451  JMP $251
b00: bf08  MOV R7, #$08
b02: b96d  MOV R1, #$6d
b04: f9    MOV A,R1
b05: d8    XRL A,R0
b06: c61c  JZ $b1c
b08: 80    MOVX A,@R0
b09: 6b    ADD A,R3
b0a: 7460  CALL $360
b0c: 03f4  ADD A, #$f4
b0e: f61c  JC $b1c
b10: c9    DEC R1
b11: c8    DEC R0
b12: 80    MOVX A,@R0
b13: 6a    ADD A,R2
b14: 7460  CALL $360
b16: 03f8  ADD A, #$f8
b18: e623  JNC $b23
b1a: 18    INC R0
b1b: 19    INC R1
b1c: c9    DEC R1
b1d: c9    DEC R1
b1e: c9    DEC R1
b1f: c9    DEC R1
b20: ef04  DJNZ R7, $b04
b22: 83    RET
b23: 27    CLR A
b24: aa    MOV R2,A
b25: ab    MOV R3,A
b26: ae    MOV R6,A
b27: f8    MOV A,R0
b28: d374  XRL A, #$74
b2a: c650  JZ $b50
b2c: c9    DEC R1
b2d: c9    DEC R1
b2e: 81    MOVX A,@R1
b2f: f26b  JB7 $b6b
b31: 2320  MOV A, #$20
b33: 91    MOVX @R1,A
b34: b929  MOV R1, #$29
b36: 2301  MOV A, #$01
b38: 91    MOVX @R1,A
b39: 19    INC R1
b3a: 27    CLR A
b3b: 91    MOVX @R1,A
b3c: 19    INC R1
b3d: 19    INC R1
b3e: 80    MOVX A,@R0
b3f: 91    MOVX @R1,A
b40: c9    DEC R1
b41: 18    INC R0
b42: 80    MOVX A,@R0
b43: 91    MOVX @R1,A
b44: 23f8  MOV A, #$f8
b46: 90    MOVX @R0,A
b47: c8    DEC R0
b48: 90    MOVX @R0,A
b49: c8    DEC R0
b4a: c8    DEC R0
b4b: 27    CLR A
b4c: 90    MOVX @R0,A
b4d: 18    INC R0
b4e: 18    INC R0
b4f: 83    RET
b50: f9    MOV A,R1
b51: a8    MOV R0,A
b52: b932  MOV R1, #$32
b54: f1    MOV A,@R1
b55: c64f  JZ $b4f
b57: b921  MOV R1, #$21
b59: f1    MOV A,@R1
b5a: 0303  ADD A, #$03
b5c: a1    MOV @R1,A
b5d: 6434  JMP $334
b5f: 80    MOVX A,@R0
b60: ac    MOV R4,A
b61: 81    MOVX A,@R1
b62: 37    CPL A
b63: 17    INC A
b64: 6c    ADD A,R4
b65: f669  JC $b69
b67: 37    CPL A
b68: 17    INC A
b69: ac    MOV R4,A
b6a: 83    RET
b6b: 43c0  ORL A, #$c0
b6d: 18    INC R0
b6e: 6443  JMP $343
b70: 81    MOVX A,@R1
b71: 6a    ADD A,R2
b72: 91    MOVX @R1,A
b73: b84b  MOV R0, #$4b
b75: bf08  MOV R7, #$08
b77: fc    MOV A,R4
b78: a3    MOVP A,@A
b79: 90    MOVX @R0,A
b7a: c8    DEC R0
b7b: 1c    INC R4
b7c: ef77  DJNZ R7, $b77
b7e: 83    RET
b7f: 18    INC R0
b80: 18    INC R0
b81: 7e    ADDC A,R6
b82: 9918  ANL P1, #$18
b84: 18    INC R0
b85: 2442  JMP $142
b87: 18    INC R0
b88: 58    ANL A,R0
b89: 28    XCH A,R0
b8a: 78    ADDC A,R0
b8b: 08    INS A,BUS
b8c: 18    INC R0
b8d: 28    XCH A,R0
b8e: 18    INC R0
b8f: 18    INC R0
b90: 1a    INC R2
b91: 141e  CALL $01e
b93: 10    INC @R0
b94: 18    INC R0
b95: 1418  CALL $018
b97: 5a    ANL A,R2
b98: 997e  ANL P1, #$7e
b9a: 18    INC R0
b9b: 18    INC R0
b9c: 18    INC R0
b9d: 2442  JMP $142
b9f: 58    ANL A,R0
ba0: 9b    ILL
ba1: 7e    ADDC A,R6
ba2: 18    INC R0
ba3: 18    INC R0
ba4: 18    INC R0
ba5: 2420  JMP $120
ba7: 2a    XCH A,R2
ba8: d9    XRL A,R1
ba9: 7e    ADDC A,R6
baa: 18    INC R0
bab: 18    INC R0
bac: 18    INC R0
bad: 2404  JMP $104
baf: 20    XCH A,@R0
bb0: 40    ORL A,@R0
bb1: 40    ORL A,@R0
bb2: ff    MOV A,R7
bb3: 40    ORL A,@R0
bb4: 40    ORL A,@R0
bb5: 20    XCH A,@R0
bb6: 00    NOP
bb7: 08    INS A,BUS
bb8: 3e    MOVD P6,A
bb9: 49    ORL A,R1
bba: 08    INS A,BUS
bbb: 08    INS A,BUS
bbc: 08    INS A,BUS
bbd: 08    INS A,BUS
bbe: 08    INS A,BUS
bbf: 0402  JMP $002
bc1: 02    OUTL BUS,A
bc2: ff    MOV A,R7
bc3: 02    OUTL BUS,A
bc4: 02    OUTL BUS,A
bc5: 0400  JMP $000
bc7: 10    INC @R0
bc8: 7c    ADDC A,R4
bc9: 9210  JB4 $b10
bcb: 10    INC @R0
bcc: 10    INC @R0
bcd: 10    INC @R0
bce: 10    INC @R0
bcf: 19    INC R1
bd0: 42    MOV A,T
bd1: 5303  ANL A, #$03
bd3: bd28  MOV R5, #$28
bd5: c6e5  JZ $be5
bd7: b833  MOV R0, #$33
bd9: f0    MOV A,@R0
bda: 96e5  JNZ $be5
bdc: bd18  MOV R5, #$18
bde: 42    MOV A,T
bdf: 72e5  JB3 $be5
be1: 81    MOVX A,@R1
be2: 37    CPL A
be3: f2f5  JB7 $bf5
be5: b875  MOV R0, #$75
be7: 80    MOVX A,@R0
be8: d3f8  XRL A, #$f8
bea: 96f5  JNZ $bf5
bec: 81    MOVX A,@R1
bed: 90    MOVX @R0,A
bee: c8    DEC R0
bef: 19    INC R1
bf0: 81    MOVX A,@R1
bf1: 90    MOVX @R0,A
bf2: c8    DEC R0
bf3: fd    MOV A,R5
bf4: 90    MOVX @R0,A
bf5: 44fc  JMP $2fc
bf7: d3b7  XRL A, #$b7
bf9: 96ff  JNZ $bff
bfb: b82a  MOV R0, #$2a
bfd: b088  MOV @R0, #$88
bff: 83    RET
