"""Record startup and reproducible gameplay fixtures with real POKEY audio.

The footer identifies fixtures. Only RAM state and a temporary game-tick pause
set up the below-Pete boulder; the released engine handles the actual down input,
strike, scoring, key/door contact, and complete transition.
"""
from pathlib import Path
import ctypes as C
import json
import subprocess
import sys
import wave

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'tools'))
from core_host import Host
p = root / 'native/build'
out = Path(sys.argv[1]).resolve()
out.parent.mkdir(parents=True, exist_ok=True)
lab = {x.split()[2][1:]: int(x.split()[1], 16)
       for x in (p / 'labels.txt').read_text().splitlines()}
h = Host(root / 'tools/atari800core/atari800_libretro.so', root / 'reference',
         {'atari800_system': '800XL (64K)', 'atari800_ntscpal': 'NTSC',
          'atari800_internalbasic': 'disabled'})
h.load(p / 'PickAxePete-native-64K.xex')
h.run(180)
r = (C.c_ubyte * 65536).from_address(h.lib.retro_get_memory_data(2))
def put(name, value): r[lab['_' + name]] = value & 255
def get(name): return r[lab['_' + name]]

fps = 59.922745
segments = [(0, 120, 'Original SELECT GAME - fire starts'),
            (120, 240, 'Game running after fire'),
            (240, 330, 'Fixture - boulder below Pete; raised axe'),
            (330, 450, 'Down only - low strike breaks the boulder (+3)'),
            (450, 708, 'Door fixture - enter with key; no white rectangle'),
            (708, 840, 'New mine - normal display restored')]
filters = ['scale=1200:900:flags=neighbor', 'pad=1200:970:0:0:black']
for start, end, caption in segments:
    filters.append("drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:"
                   f"text='{caption}':fontsize=26:fontcolor=white:x=(w-tw)/2:y=920:"
                   f"enable='gte(n,{start})*lt(n,{end})'")
silent = out.with_suffix('.silent.mp4')
wav = out.with_suffix('.wav')
pipe = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo',
    '-pix_fmt', 'rgb24', '-s', '400x300', '-r', str(fps), '-i', '-',
    '-vf', ','.join(filters), '-c:v', 'libx264', '-preset', 'fast', '-crf', '18',
    '-pix_fmt', 'yuv420p', '-an', str(silent)], stdin=subprocess.PIPE)
h.audio = []
tick = lab['_game_tick']
saved_tick_byte = r[tick]
strike = None
for frame in range(840):
    if frame == 120:
        h.joy = {0}
    if frame == 123:
        h.joy = set()
    if frame == 240:
        r[tick] = 0x60
        for name, value in dict(mode=1, frame=1, pete_x=76, pete_y=130,
                pete_shape=9, pick_life=64, has_key=0, jump_phase=0, terrain=2,
                input_x=0, input_y=0, input_fire=0, last_x=1, last_y=255,
                item_kind=0, item_x=80, item_y=123, item_shape=1,
                ladder_y=248, effect_y=248, effect_phase=0, effect_clock=0,
                rock_cursor=0, score_pending=0).items():
            put(name, value)
        for i in range(5):
            r[lab['_rock_x'] + i] = r[lab['_rock_y'] + i] = 248
            r[lab['_rock_fall'] + i] = 0
            r[lab['_rock_x_energy'] + i] = r[lab['_rock_y_energy'] + i] = 0
        for i in range(8): r[lab['_item_mask'] + i] = 255
        for i in range(4): r[lab['_score'] + i] = 0
        put('score_changed', 1)
        r[lab['_rock_x']], r[lab['_rock_y']] = 80, 142
    if frame == 329:
        h.savepng(p / 'down-strike-before.png')
        assert r[lab['_rock_y']] == 142
    if frame == 330:
        h.joy = {5}
        r[tick] = saved_tick_byte
    if frame == 336:
        assert r[lab['_rock_y']] == 248, {k: get(k) for k in ('mode', 'frame', 'input_y', 'pete_y', 'item_x', 'item_y', 'pick_life', 'rock_x', 'rock_y', 'rock_cursor', 'terrain')}
        strike = dict(input_down=True, input_fire=False, boulder_destroyed=True,
                      item_y=get('item_y'), score=list(r[lab['_score']:lab['_score'] + 4]),
                      pending_points=get('score_pending'))
        assert sum(strike['score']) + strike['pending_points'] == 3
    if frame == 340: h.savepng(p / 'down-strike-after.png')
    if frame == 400: h.joy = set()
    if frame == 450:
        for name, value in dict(mode=1, has_key=1, pete_x=77, pete_y=106,
                                jump_phase=0, frame=51).items():
            put(name, value)
    h.run()
    if frame == 470:
        assert get('mode') == 3
        h.savepng(p / 'entry-preview.png')
    if frame == 730: assert get('mode') == 1
    pipe.stdin.write(h.video.tobytes())
pipe.stdin.close()
assert pipe.wait() == 0
with wave.open(str(wav), 'wb') as f:
    f.setnchannels(2)
    f.setsampwidth(2)
    f.setframerate(44100)
    f.writeframes(b''.join(h.audio))
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(silent), '-i', str(wav),
    '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart',
    str(out)], check=True)
silent.unlink()
wav.unlink()
(p / 'recorded-fixes.json').write_text(json.dumps(dict(video_frames=840,
    fps=fps, fixture_setup_disclosed=True, actual_joystick_down_strike=strike,
    door_transition_completed=True), indent=2))
print(out)
