"""Long NTSC deadline gate, including the original timer-driven sound IRQ."""
from pathlib import Path
import ctypes as C, sys, json
import numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'tools'))
from core_host import Host
p=root/'native/build';lab={x.split()[2][1:]:int(x.split()[1],16) for x in (p/'labels.txt').read_text().splitlines()}
h=Host(root/'tools/atari800core/atari800_libretro.so',root/'reference',{'atari800_system':'800XL (64K)','atari800_ntscpal':'NTSC','atari800_internalbasic':'disabled'})
h.load(p/'PickAxePete-display-demo.xex');h.run(180)
names=['frame_begin','frame_complete','vbi_begin','vbi_end','hud_font_switch']
for i,k in enumerate(names):h.lib.retro_debug_watch(i,lab[k])
h.lib.retro_debug_reset_log();m=h.memory();before=int.from_bytes(m[lab['missed_frames']:lab['missed_frames']+2],'little')
h.run(10000);m=h.memory();miss=int.from_bytes(m[lab['missed_frames']:lab['missed_frames']+2],'little')-before
h.lib.retro_debug_log.restype=C.c_void_p
n=h.lib.retro_debug_log_count();events=np.frombuffer(C.string_at(h.lib.retro_debug_log(),n*12),dtype=np.uint32).reshape(-1,3)
starts={};duration={'foreground':[],'blanking':[]};endlines=[];margins=[];last_complete=None
for idx,clock,y in events:
 idx,clock,y=int(idx),int(clock),int(y)
 if idx in (0,2):starts[idx]=clock
 if idx in (1,3) and idx-1 in starts:duration['foreground' if idx==1 else 'blanking'].append(clock-starts.pop(idx-1))
 if idx==1:last_complete=clock
 if idx==2 and last_complete is not None:margins.append(clock-last_complete);last_complete=None
 if idx==3:endlines.append(y)
hud_lines=events[events[:,0]==4,2]
report={'video_frames':10000,'game_tick_entries':int(sum(events[:,0]==0)),'missed_frames':miss,
        'blanking_overruns':sum(40<=y<234 for y in endlines),
        'max_foreground_clocks':max(duration['foreground']),'max_blanking_clocks':max(duration['blanking']),
        'minimum_prepare_margin_clocks':min(margins),
        'latest_wrapped_blanking_end_scanline':max((y for y in endlines if y<234),default=0),
        'hud_font_switches':len(hud_lines),'late_hud_switches':int(sum(hud_lines!=215)),
        'full_speed_gate_passed':miss==0 and not any(40<=y<234 for y in endlines) and len(hud_lines)==10000 and not any(hud_lines!=215)}
(p/'long-demo-timing.json').write_text(json.dumps(report,indent=2));print(report)
assert report['full_speed_gate_passed'],report
