"""Held-pick poses: original 8048 ROM, C model, and linked Atari 6502 code."""
from pathlib import Path
import ctypes as C
import itertools
import json
import sys
from py65.devices.mpu6502 import MPU

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'tools'))
from core_host import Host
p = root / 'native/build'
lab = {x.split()[2][1:]: int(x.split()[1], 16)
       for x in (p / 'labels.txt').read_text().splitlines()}
g = C.CDLL(str(p / 'game_host.so'))  # rebuilt by oracle_test.py
m = bytearray(65536)
for name, base in [('game.bin', 0x1000), ('extra.bin', 0xe000), ('aux.bin', 0xd800)]:
    data = (p / name).read_bytes()
    m[base:base + len(data)] = data
cpu = MPU(memory=m)
m[lab['c_sp']:lab['c_sp'] + 2] = b'\x00\x10'

def call(name):
    cpu.pc = lab[name]
    cpu.sp = 0xfd
    cpu.p = 0x24
    m[0x1fe:0x200] = b'\xff\x06'
    for _ in range(20000):
        if cpu.pc == 0x700:
            return
        cpu.step()
    raise RuntimeError(name)

def put(name, value):
    C.c_ubyte.in_dll(g, name).value = value & 255
    m[lab['_' + name]] = value & 255

def get(name):
    return m[lab['_' + name]]

def reverse(value):
    return int(f'{value:08b}'[::-1], 2)

cart = (root / 'reference/pickaxe.bin').read_bytes()
banks = [bytes(1024) + cart[2048:], bytes(1024) + cart[:2048]]
provenance = json.loads((root / 'native/asset-provenance.json').read_text())['pete_frames']
assert len(provenance) == 37
for shape, (bank, addr) in enumerate(provenance):
    at = lab['pete_shapes'] + shape * 8
    assert bytes(m[at:at + 8]) == bytes(reverse(v) for v in banks[bank][addr:addr + 8])
for shape in range(4):
    at = lab['pick_shapes'] + shape * 8
    assert bytes(m[at:at + 8]) == bytes(reverse(v) for v in banks[0][0xbaf + shape * 8:0xbb7 + shape * 8])

h = Host(root / 'tools/o2em/o2em_libretro.so', root / 'reference')
h.load(root / 'reference/pickaxe.bin')
h.lib.retro_debug_ram.restype = C.c_void_p
ir = (C.c_ubyte * 64).from_address(h.lib.retro_debug_ram(0))
ex = (C.c_ubyte * 256).from_address(h.lib.retro_debug_ram(1))
g.game_init()
call('_game_init')
count = 0
for frame, dx, dy, fire, jump, last_x, last_y, terrain in itertools.product(
        (1, 3, 5, 7), (-1, 0, 1), (-1, 0, 1), (0, 1), (0, 1, 17),
        (-1, 0, 1), (-1, 0, 1), (2, 128)):
    values = dict(pete_x=76, pete_y=129, pick_life=64, frame=frame,
                  input_x=dx, input_y=dy, input_fire=fire, jump_phase=jump,
                  last_x=last_x, last_y=last_y, terrain=terrain)
    for name, value in values.items():
        put(name, value)
    for addr, value in {0: fire, 26: dx, 27: dy, 0x25: frame, 0x32: 64,
                        0x31: terrain, 0x2c: last_x, 0x2d: last_y, 0x2e: jump}.items():
        ir[addr] = value & 255
    ex[0x7c], ex[0x7d] = 76, 129
    assert h.lib.retro_debug_invoke(0, 0xa00, 20000) == 0xfff
    expected = (ex[0x74], ex[0x75], ir[0x2d])
    original_art = bytes(ex[0x44:0x4c])[::-1]
    g.held_pick_step()
    call('_held_pick_step')
    for source in ('C', '6502'):
        read = (lambda k: C.c_ubyte.in_dll(g, k).value) if source == 'C' else get
        actual = tuple(read(k) for k in ('item_x', 'item_y', 'last_y'))
        shape = read('item_shape')
        assert actual == expected, (source, values, actual, expected)
        assert banks[0][0xbaf + shape * 8:0xbb7 + shape * 8] == original_art, (source, values, shape)
    # Drawing must use the same position and exact artwork as collision code.
    call('prepare_sprites')
    assert m[lab['pm_x'] + 2] == get('item_x')
    assert m[lab['pm_y'] + 2] == get('item_y')
    assert bytes(m[lab['pm_pattern'] + 16:lab['pm_pattern'] + 24]) == bytes(reverse(v) for v in original_art)
    count += 1

# A boulder below Pete is beyond the raised stroke but within the low stroke.
hits = []
for dy in (0, 1):
    for name, value in dict(pete_x=76, pete_y=129, pick_life=64, frame=1,
                            input_x=0, input_y=dy, input_fire=0, jump_phase=0,
                            last_x=1, last_y=0, terrain=2, score_pending=0).items():
        put(name, value)
    for i in range(5):
        m[lab['_rock_x'] + i] = m[lab['_rock_y'] + i] = 248
    m[lab['_rock_x']], m[lab['_rock_y']] = 80, 141
    call('_held_pick_step')
    call('_pick_rocks')
    hit = m[lab['_rock_y']] == 248
    assert hit == bool(dy)
    assert get('score_pending') == 3 * dy
    hits.append(dict(down=bool(dy), axe_y=get('item_y'), boulder_destroyed=hit,
                     points=get('score_pending')))

report = dict(rom_pose_cases=count, c_mismatches=0, native_6502_mismatches=0,
              rendered_pose_mismatches=0, pete_frames_verified=37,
              held_pick_frames_verified=4, downward_strike=hits)
(p / 'held-pick-oracle.json').write_text(json.dumps(report, indent=2))
print(report)
