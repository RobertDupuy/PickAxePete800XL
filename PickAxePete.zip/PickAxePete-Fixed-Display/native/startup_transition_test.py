"""Actual emulator pixels and input: number/fire startup and mine entry."""
from pathlib import Path
import ctypes as C
import json
import sys
import numpy as np

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'tools'))
from core_host import Host
p = root / 'native/build'
lab = {x.split()[2][1:]: int(x.split()[1], 16)
       for x in (p / 'labels.txt').read_text().splitlines()}

original = Host(root / 'tools/o2em/o2em_libretro.so', root / 'reference')
original.load(root / 'reference/pickaxe.bin')
original.run(180)
original.savepng(p / 'original-select-game.png')
original_title = original.video[112:126, 84:260].max(axis=2) > 32

h = Host(root / 'tools/atari800core/atari800_libretro.so', root / 'reference',
         {'atari800_system': '800XL (64K)', 'atari800_ntscpal': 'NTSC',
          'atari800_internalbasic': 'disabled'})
h.load(p / 'PickAxePete-native-64K.xex')
h.run(180)
r = (C.c_ubyte * 65536).from_address(h.lib.retro_get_memory_data(2))
def put(k, value): r[lab['_' + k]] = value
def get(k): return r[lab['_' + k]]

assert get('mode') == 0
title = h.video.copy()
actual_title = title[150:164, 124:300].max(axis=2) > 32
assert np.array_equal(actual_title, original_title)
whole_mask = np.zeros((300, 400), dtype=bool)
whole_mask[150:164, 124:300] = original_title
assert np.array_equal(title.max(axis=2) > 32, whole_mask)
colors = []
for i in (0, 1, 2, 3, 4, 5, 7, 8, 9, 10):
    letter = title[150:164, 124 + i * 16:140 + i * 16]
    used = np.unique(letter[letter.max(axis=2) > 32], axis=0)
    assert len(used) == 1
    colors.append(tuple(int(v) for v in used[0]))
assert len(set(colors)) == 7
assert colors[0] == colors[7] and colors[1] == colors[8] and colors[2] == colors[9]
h.run(90)
assert get('mode') == 0 and np.array_equal(title, h.video)
h.savepng(p / 'select-game-preview.png')
# Restore this booted machine state between keys; this core cannot reload
# content repeatedly in one process without retaining its launch arguments.
h.lib.retro_serialize_size.restype = C.c_size_t
snapshot = C.create_string_buffer(h.lib.retro_serialize_size())
h.lib.retro_serialize.argtypes = [C.c_void_p, C.c_size_t]
h.lib.retro_serialize.restype = C.c_bool
h.lib.retro_unserialize.argtypes = [C.c_void_p, C.c_size_t]
h.lib.retro_unserialize.restype = C.c_bool
assert h.lib.retro_serialize(snapshot, len(snapshot))
h.joy = {0}
h.run(3)
h.joy = set()
h.run(40)
assert get('mode') == 1 and get('mine_number') == 0

# Each numeric key must start its original layout from a fresh title screen,
# without a fire press. Check the real keyboard mapping and loaded floor data.
layouts = (root / 'reference/pickaxe.bin').read_bytes()[0x2a3:0x2fd]
number_starts = []
for mine in range(10):
    assert h.lib.retro_unserialize(snapshot, len(snapshot))
    h.run(2)
    r = (C.c_ubyte * 65536).from_address(h.lib.retro_get_memory_data(2))
    assert get('mode') == 0 and np.array_equal(title, h.video)
    h.keys = {48 + mine}
    h.run(3)
    assert get('mode') == 1 and get('mine_number') == mine
    h.keys = set()
    h.run(40)
    assert bytes(r[lab['_floors']:lab['_floors'] + 9]) == layouts[mine * 9:mine * 9 + 9]
    assert not np.array_equal(title, h.video)
    number_starts.append(mine)
h.savepng(p / 'gameplay-preview.png')

# Enter through the normal contact rule with a key, then inspect every frame.
for name, value in dict(has_key=1, pete_x=77, pete_y=106, frame=51).items():
    put(name, value)
h.run(10)
assert get('mode') == 3
transition_frames = 0
for n in range(300):
    h.run()
    if get('mode') != 3:
        break
    assert get('ladder_y') == get('item_y') == get('effect_y') == 248
    assert not any(r[0xcd00:0xd000]), 'stale ladder, item or effect pixels'
    # The old white ladder occupied this lower-right rectangle.
    assert int(h.video[198:230, 246:282].max()) < 240
    transition_frames += 1
    if n == 20:
        h.savepng(p / 'transition-preview.png')
assert transition_frames > 100 and get('mode') == 1
h.run(20)
assert get('ladder_y') != 248
report = dict(startup_title_pixels_compared=300 * 400,
              original_glyph_mismatches=0, original_color_groups=7,
              idle_keeps_title=True, number_keys_start_immediately=number_starts,
              fire_starts_default_mine=True, transition_frames_checked=transition_frames,
              stale_object_bytes=0, returned_to_playing=True)
(p / 'startup-transition-test.json').write_text(json.dumps(report, indent=2))
(p / 'transition-test.json').write_text(json.dumps(dict(entered_transition=True,
    returned_to_playing=True, display_restored=True, stale_object_bytes=0), indent=2))
print(report)
