# Pick Axe Pete — game logic map

This map describes gameplay independently of either machine's hardware. `game.c` is the executable rule model. `terrain.s` and `objects.s` implement the same hot routines directly in 6502 assembly. Only `platform.s` knows the Atari registers. The old register-based translation is a separate, superseded implementation.

```mermaid
flowchart TD
    select["SELECT GAME"] -->|"0–9, or fire for mine 0"| start["Load layout and start round"]
    start --> tick["Advance one game frame"]
    tick --> result{"Result of contacts?"}
    result -->|"Continue"| tick
    result -->|"Unprotected hit"| dead["Death animation and timer"]
    dead --> score["Keep high score; reset current score"]
    score --> start
    result -->|"Door with key"| change["Award 20; enter next mine"]
    change --> alter["Change color; remove a floor segment; reduce difficulty"]
    alter --> round["Start round with existing score and altered layout"]
    round --> tick
```

A frame is a scheduling unit, not a command to move every object. The original deliberately moves Pete and the ladder on alternate frames and processes two of five boulders each frame. The Atari engine preserves this cadence while calling the main game routine once per NTSC frame.

```mermaid
flowchart TD
    input["Read controls and previous frame's contact results"] --> phase{"Even or odd frame?"}
    phase -->|"Even"| pete["Ladder lifecycle and Pete movement"]
    phase -->|"Odd"| effect["Advance collision effect"]
    pete --> spawn["Check timed boulder spawn"]
    effect --> spawn
    spawn --> action{"Even or odd frame?"}
    action -->|"Even"| climb["Apply climbing movement"]
    action -->|"Odd"| item["Collect pick or key; age held pick; check item spawn"]
    climb --> rocks["Advance two boulders, round robin"]
    item --> rocks
    rocks --> strike["Resolve pick against boulders"]
    strike --> finish{"Even or odd frame?"}
    finish -->|"Odd"| contacts["Move loose item; resolve Pete, boulder and door contacts"]
    finish -->|"Even"| death["Advance death timer if dying"]
    contacts --> account["Door timers; queued score; difficulty; frame counter"]
    death --> account
```

Pete's movement has a separate, small state machine. The ROM tests identified an important detail: the jump has an initial rise, a hold, and then returns to the ordinary terrain step. It is not a generic parabolic jump.

```mermaid
flowchart TD
    pete["Update Pete"] --> ladder{"Attached to ladder?"}
    ladder -->|"Yes"| climb["Climb, step away, or hold position"]
    ladder -->|"No"| jumping{"Dodge or jump already active?"}
    jumping -->|"Yes"| phase["Advance 32-step dodge or jump sequence"]
    jumping -->|"No"| floor{"Supporting floor?"}
    floor -->|"No"| fall["Gravity and terrain correction"]
    floor -->|"Yes"| fire{"Fire held?"}
    fire -->|"Yes"| launch["Use remembered direction to start dodge or jump"]
    fire -->|"No"| walk["Walk and probe terrain"]
    phase --> shape["Choose pose or retain previous animation frame"]
    launch --> shape
    walk --> shape
    fall --> shape
    climb --> shape
```

## What the state means

| State | Meaning |
|---|---|
| `mode` | Mine selection, playing, dying, or entering another mine |
| `floors[9]` | Nine columns of platform segments, extracted from the ten original layouts |
| `pete_x`, `pete_y` | Game coordinates, independent of screen addresses |
| `terrain` | Side boundary, supporting surface, platform edge, or gap |
| `last_x`, `last_y`, `jump_phase` | Remembered direction and dodge/jump progress |
| `walk_clock`, `walk_phase`, `pete_shape` | Animation timing and selected artwork |
| `pick_life`, `has_key` | Remaining encoded pick lifetime and key ownership |
| `ladder_*` | Position, growth/retraction phase, hold timer, and selected level |
| `item_*` | Loose pick/key identity and lifetime; shared held/loose item position and artwork |
| `rock_*[5]` | Positions, directional energy, decay, and collision-fall state |
| `rock_cursor` | Which boulder will be processed next |
| `door_*[3]` | Door colors and opening/cooldown state |
| `effect_*` | Collision effect position and animation clock |
| `score_pending` | Points awaiting addition, one per frame as in the original |
| `difficulty` | Spawn/velocity intensity, reduced after entering a door |
| `pete_hits_*` | Semantic contact results supplied by the platform |

The velocity bytes retain the original game's direction/energy encoding because it defines the acceleration and bounce behavior. They are game data, not emulated CPU or device registers.

## Scoring and transitions

| Event | Points | Result |
|---|---:|---|
| Successful dodge near a boulder | 1 | Brief cooldown prevents repeated rewards |
| Break a boulder with the pick | 3 | Remove it and start the collision effect |
| Collect a loose pick | 5 | Restart the pick lifetime |
| Collect a key | 10 | Pete flashes; a door can be entered |
| Enter a door with a key | 20 | Change mine color, remove a segment, reduce difficulty |
| Enter a door without a key | 0 | Forced escape/dodge sequence |
| Unprotected boulder contact | 0 | Death animation, high-score update, automatic restart |

## How the map was recovered

Addresses below belong to the disassembly only. They are evidence anchors, not addresses used by the native game.

| Rule | Original routine | Native rule |
|---|---|---|
| Per-frame orchestration | Bank 0 `$421–58D`; bank 1 `$423–48E` | `game_tick` |
| Ten mine layouts | Bank 1 `$6A3–6FC` | `mine_layouts`, `start_game` |
| Terrain probe and edge correction | Bank 0 `$900–9CC` | `terrain_query` |
| Pete movement and jump | Bank 1 `$900–9FE`, `$ACC–AFD` | `pete_step`, `pete_ground_step` |
| Ladder lifecycle and attachment | Bank 1 `$80A–8FB` | `ladder_step` |
| Climbing and pick handling | Bank 0 `$A00–AFE` | `climb_step`, `pick_step` |
| Held-pick position, low stroke and facing | Bank 0 `$A99–AF1` | `held_pick_step`; shared display/contact state |
| Boulder spawn | Bank 0 `$474–4FE` | `spawn_rock` |
| Boulder movement, bounce and decay | Bank 0 `$81F–8FC`, `$9CE–9FA` | `rock_step` |
| Boulder/object and pick contacts | Bank 0 `$B00–B6E` | `rock_objects`, `pick_rocks` |
| Loose pick/key movement and expiration | Bank 1 `$527–5FE` | `item_step` |
| Item creation after collision | Bank 0 `$BCF–BF5` | `spawn_item` |
| Death, evasion and door contacts | Bank 1 `$700–7FF` | `pete_contacts`, death branch in `game_tick` |
| Mine transition and floor removal | Bank 1 `$490–4F3`, `$600–63B` | Transition branch, `remove_floor` |
| Score and difficulty accumulation | Bank 0 `$6D5–6FF` | `score_tick` |

## Evidence and limits

The test reports are included in `build/`. Terrain queries, Pete's movement/animation selection, and boulder movement were tested against execution of the original cartridge routines, not screenshots. A separate test executes the linked 6502 code and compares its state with the portable rule model.

Held-pick control has a separate 3,888-case original-ROM/C/linked-6502 comparison. It includes stationary up/down input without fire, jump offsets, gaps, facing, artwork and rendering. All 37 Pete frames and four held-pick frames match the cartridge artwork. A boulder below Pete survives the raised stroke and is destroyed for three points by the down stroke. Mine entry clears the ladder, item and effect; new-round setup restores their initial state.

Those tests are narrower than complete game equivalence. The entropy adapter follows an 8-bit counter with the original 32-machine-cycle prescaler. Isolated spawn results match when entry phase is supplied; the full branch-dependent timer timeline remains incomplete, so the original whole-game random sequence is not established. The sound command interpreter, noise recurrence, explosion and fading masks have separate ROM comparisons. Tone-to-noise phase and palette fidelity remain imperfect. The fixed character renderer passes the measured NTSC frame-deadline gate with a narrow blanking margin; see README.md and the current reports. Full-game replay, exhaustive collision timing, PAL operation and real-machine testing remain unverified.
