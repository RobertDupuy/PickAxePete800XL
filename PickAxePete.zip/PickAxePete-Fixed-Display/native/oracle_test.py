"""Compare the hardware-free terrain rule with actual cartridge execution."""
import ctypes as C, random, sys, subprocess, json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools'))
from core_host import Host
p=root/'native/build'
subprocess.run(['cc','-shared','-fPIC','-O2','-Dstatic=',str(root/'native/game.c'),str(root/'native/entropy.c'),'-o',str(p/'game_host.so')],check=True)
g=C.CDLL(str(p/'game_host.so'))
def put(k,v): C.c_ubyte.in_dll(g,k).value=v&255
def get(k):return C.c_ubyte.in_dll(g,k).value
floors=(C.c_ubyte*9).in_dll(g,'floors')
h=Host(root/'tools/o2em/o2em_libretro.so',root/'reference');h.load(root/'reference/pickaxe.bin')
h.lib.retro_debug_ram.restype=C.c_void_p
ir=(C.c_ubyte*64).from_address(h.lib.retro_debug_ram(0));ex=(C.c_ubyte*256).from_address(h.lib.retro_debug_ram(1))
rng=random.Random(20261022);layouts=(root/'reference/pickaxe.bin').read_bytes()[0x2a3:0x2fd]
fail=[]
for n in range(20000):
 layout=n%10;data=layouts[layout*9:layout*9+9]
 for i,v in enumerate(data): floors[i]=ex[0x10+i]=v
 x=rng.randrange(5,150);y=rng.randrange(20,200);dx=rng.randrange(-3,4);dy=rng.randrange(-3,4)
 ir[24]=0x6d;ir[26]=dx&255;ir[27]=dy&255;ex[0x6c]=x;ex[0x6d]=y
 pc=h.lib.retro_debug_invoke(0,0x900,10000)
 if pc!=0xfff:raise RuntimeError(hex(pc))
 original=(ir[30],ir[0x28],ir[0x29])
 for k,v in [('query_x',x),('query_y',y),('move_x',dx),('move_y',dy)]:put(k,v)
 g.terrain_query();actual=tuple(get(k) for k in ['contact_flags','correction_x','correction_y'])
 if actual!=original:
  fail.append({'layout':layout,'x':x,'y':y,'dx':dx,'dy':dy,'original':original,'native':actual})
  if len(fail)<=8:print(fail[-1])
report={'cases':20000,'mismatches':len(fail),'first_mismatches':fail[:30]}
(p/'terrain-oracle.json').write_text(json.dumps(report,indent=2));print(report['cases'],'cases;',report['mismatches'],'mismatches')

# Pete's complete movement routine, independent of spawning and randomness.
fail=[]
fields={'pete_x':('e',0x7c),'pete_y':('e',0x7d),'last_x':('i',0x2c),'last_y':('i',0x2d),'jump_phase':('i',0x2e),'walk_clock':('i',0x2f),'walk_phase':('i',0x30),'terrain':('i',0x31),'frame':('i',0x25)}
shape_fail=0
shape_examples=[]
shape_counts={}
provenance=json.loads((root/'native/asset-provenance.json').read_text())['pete_frames']
cart=(root/'reference/pickaxe.bin').read_bytes();banks=[bytes(1024)+cart[2048:],bytes(1024)+cart[:2048]]
for n in range(10000):
 layout=n%10
 for i,v in enumerate(layouts[layout*9:layout*9+9]):floors[i]=ex[0x10+i]=v
 state={'pete_x':rng.randrange(10,144),'pete_y':rng.randrange(28,181),'last_x':rng.randrange(-1,2),'last_y':rng.randrange(-1,2),'jump_phase':rng.randrange(32),'walk_clock':rng.randrange(3),'walk_phase':rng.randrange(5),'terrain':rng.choice([0,2,3,18,128,130]),'frame':rng.randrange(256)}
 for key,value in state.items():
  put(key,value);kind,addr=fields[key];(ir if kind=='i' else ex)[addr]=value&255
 oldshape=rng.randrange(len(provenance));put('pete_shape',oldshape)
 bank,addr=provenance[oldshape]
 for k,value in enumerate(banks[bank][addr:addr+8]):ex[0x4b-k]=value
 dx=rng.randrange(-1,2);dy=rng.randrange(-1,2);fire=rng.randrange(2)
 put('input_x',dx);put('input_y',dy);put('input_fire',fire)
 ir[0]=fire;ir[26]=dx&255;ir[27]=dy&255
 pc=h.lib.retro_debug_invoke(1,0x900,20000)
 if pc!=0xfff:raise RuntimeError(hex(pc))
 g.pete_step()
 bank,addr=provenance[get('pete_shape')]
 if bytes(ex[0x44:0x4c])[::-1]!=banks[bank][addr:addr+8]:
  shape_fail+=1
  original=[i for i,(b,a) in enumerate(provenance) if banks[b][a:a+8]==bytes(ex[0x44:0x4c])[::-1]]
  key=str((original,get('pete_shape')))
  shape_counts[key]=shape_counts.get(key,0)+1
  if len(shape_examples)<8:shape_examples.append({'before':state,'input':[dx,dy,fire],'old_shape':oldshape,'original':original,'native':get('pete_shape')})
 expected={key:(ir if kind=='i' else ex)[addr] for key,(kind,addr) in fields.items()}
 actual={key:get(key) for key in fields}
 if expected!=actual:
  fail.append({'state':state,'input':[dx,dy,fire],'expected':expected,'actual':actual})
  if len(fail)<=3:print(fail[-1])
report={'cases':10000,'shape_mismatches':shape_fail,'shape_examples':shape_examples,'shape_counts':shape_counts,'mismatches':len(fail),'first_mismatches':fail[:15]}
(p/'pete-oracle.json').write_text(json.dumps(report,indent=2));print(report['cases'],'Pete cases;',report['mismatches'],'state mismatches;',shape_fail,'shape mismatches')

# Boulder physics/contact scheduling. Compare live objects; hidden-object
# velocity bytes are intentionally discarded by the semantic model.
rock_fields=['rock_x','rock_y','rock_x_energy','rock_y_energy','rock_fall','rock_decay']
rock_arrays={k:(C.c_ubyte*5).in_dll(g,k) for k in rock_fields}
fail=[]
for n in range(5000):
 for k in range(128):ex[k]=0
 for k in range(32,64):ir[k]=0
 for i,v in enumerate(layouts[n%10*9:n%10*9+9]):floors[i]=ex[0x10+i]=v
 for i,y in enumerate([178,106,34]):ex[0x4e+i*4]=128;ex[0x50+i*4]=77;ex[0x51+i*4]=y
 for i in range(5):
  x=rng.randrange(9,146);y=rng.randrange(28,183) if rng.randrange(5) else 248
  if y==248:x=248
  fall=int(rng.randrange(12)==0);vx=rng.randrange(256);vy=rng.randrange(256);decay=rng.randrange(32)
  values=[x,y,vx,vy,fall,decay]
  for k,v in zip(rock_fields,values):rock_arrays[k][i]=v
  ex[0x6c-i*4]=x;ex[0x6d-i*4]=y;ex[0x6a-i*4]=fall*32
  ex[0x1a+i*3]=vx;ex[0x1b+i*3]=vy;ex[0x1c+i*3]=decay
 cursor=rng.randrange(5);put('rock_cursor',cursor);ex[0x32]=cursor+1
 ir[0]=0
 pc=h.lib.retro_debug_invoke(0,0x81f,20000)
 if pc!=0xfff:raise RuntimeError(hex(pc))
 g.rock_step()
 expected=[];actual=[]
 for i in range(5):
  e=[ex[0x6c-i*4],ex[0x6d-i*4]];a=[rock_arrays['rock_x'][i],rock_arrays['rock_y'][i]]
  if e[1]!=248 and a[1]!=248:
   e += [ex[0x1a+i*3],ex[0x1b+i*3],bool(ex[0x6a-i*4]&32),ex[0x1c+i*3]]
   a += [rock_arrays[k][i] for k in rock_fields[2:]]
  expected.append(e);actual.append(a)
 if expected!=actual:
  fail.append({'case':n,'cursor':cursor,'expected':expected,'actual':actual})
  if len(fail)<=3:print(fail[-1])
report={'cases':5000,'mismatches':len(fail),'first_mismatches':fail[:20]}
(p/'rock-oracle.json').write_text(json.dumps(report,indent=2));print(report['cases'],'rock cases;',report['mismatches'],'mismatches')
