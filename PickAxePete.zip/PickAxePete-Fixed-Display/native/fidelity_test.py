"""Original ROM oracles for sound, effects, and timer-driven choices."""
import ctypes as C,sys,json,subprocess,random
from pathlib import Path
from py65.devices.mpu6502 import MPU
root=Path(__file__).resolve().parents[1];p=root/'native/build';sys.path.insert(0,str(root/'tools'));from core_host import Host
lab={x.split()[2][1:]:int(x.split()[1],16) for x in (p/'labels.txt').read_text().splitlines()}
h=Host(root/'tools/o2em/o2em_libretro.so',root/'reference');h.load(root/'reference/pickaxe.bin')
h.lib.retro_debug_ram.restype=C.c_void_p;h.lib.retro_debug_entropy_log.restype=C.c_void_p
ir=(C.c_ubyte*64).from_address(h.lib.retro_debug_ram(0));ex=(C.c_ubyte*256).from_address(h.lib.retro_debug_ram(1));vdc=(C.c_ubyte*256).from_address(h.lib.retro_debug_ram(2))
mem=bytearray(65536)
for file,base in [('game.bin',0x1000),('extra.bin',0xe000),('aux.bin',0xd800)]:
 b=(p/file).read_bytes();mem[base:base+len(b)]=b
cpu=MPU(memory=mem)
def call(name):
 cpu.pc=lab[name];cpu.sp=0xfd;mem[0x1fe]=0xff;mem[0x1ff]=6;cpu.p=0x24
 for i in range(30000):
  if cpu.pc==0x700:return i
  cpu.step()
 raise RuntimeError((name,hex(cpu.pc)))
def put(k,v):mem[lab[k]]=v&255
def get(k):return mem[lab[k]]
report={};events=[0x56,0x64,0x6a,0x74,0x78,0x7f,0x87,0x91,0x97,0x9f,0xa5,0xab,0xb1]
sound_cases=0
for event in events:
 for i in range(64):ir[i]=0
 for i in range(256):vdc[i]=0
 mem[0x800:0xc00]=bytes(1024)
 # Audio IRQ state now lives in its own reserved zero-page bytes. Reset both
 # machines equally between independent sound-command cases.
 mem[lab["audio_shift"]:lab["audio_shift"]+3]=bytes(3)
 for key in ["audio_feedback","audio_noise_bits","audio_noise_byte"]:mem[lab[key]]=0
 call('audio_init');h.lib.retro_debug_sound_start(event)
 for frame in range(100):
  put('_sound_event',event if frame==0 else 0)
  call('sound_update');h.lib.retro_debug_sound_tick()
  expected=(ir[3],ir[4],vdc[0xaa]&0xbf,bool(ir[0x3f]&64),bytes(vdc[0xa7:0xaa]))
  actual=(get('sound_clock'),get('sound_cursor'),get('audio_control')&0xbf,bool(get('sound_active')),bytes(mem[lab['audio_shift']:lab['audio_shift']+3]))
  assert expected==actual,(hex(event),frame,expected,actual)
  sound_cases+=1
report['sound']={'requests':len(events),'frames':sound_cases,'mismatches':0}
print(report['sound'],flush=True)
# IRQ feedback against the documented 24-bit recurrence, independent of score.
noise_cases=0
rng=random.Random(717)
for case in range(50):
 signal=rng.randrange(1,1<<24)
 put('audio_noise_bits',0);mem[lab['noise_volume']+1]=0x1f
 for i in range(3):mem[lab['audio_shift']+i]=(signal>>(16-8*i))&255
 for tick in range(300):
  expected=0x1f if signal&1 else 0x10
  cpu.pc=lab['audio_irq'];cpu.sp=0xfc;mem[0x1fd]=0x24;mem[0x1fe]=0;mem[0x1ff]=7
  while cpu.pc!=0x700:cpu.step()
  assert mem[0xd205]==expected,(case,tick,mem[0xd205],expected)
  feedback=(signal^(signal>>5))&1;signal=((signal>>1)&~0x8000)|(feedback<<15)|(feedback<<23)
  noise_cases+=1
report['noise']={'shift_clock_checks':noise_cases,'mismatches':0}
(p/'fidelity.json').write_text(json.dumps(report,indent=2))
print(report['noise'],flush=True)
# Hardware-free visual state compared to the cartridge's actual effect routine.
g=C.CDLL(str(p/'game_host.so'))
def gp(k,v):C.c_ubyte.in_dll(g,k).value=v&255
def gg(k):return C.c_ubyte.in_dll(g,k).value
cart=(root/'reference/pickaxe.bin').read_bytes();bank=bytes(1024)+cart[:2048]
checked=0
for phase in (1,2):
 for clock in range(16):
  for i in range(64):ir[i]=0
  for i in range(256):ex[i]=0
  ir[0x25]=1;ex[0x29]=phase;ex[0x2a]=clock;ex[0x2b]=100;ex[0x2c]=70
  for k,v in {'frame':1,'effect_phase':phase,'effect_clock':clock,'effect_y':100,'effect_x':70,'sound_event':0}.items():gp(k,v)
  h.lib.retro_debug_invoke(1,0xa00,10000);g.effect_step()
  assert (ex[0x70],ex[0x71])==(gg('effect_x'),gg('effect_y')),(phase,clock,'position')
  if ex[0x71]!=248:
   assert ex[0x6f]>>3==gg('effect_color'),(phase,clock,'color')
   assert bool(ex[0x6f]&4)==bool(gg('effect_size')),(phase,clock,'size')
   expected=bytes(ex[0x3c:0x44])[::-1];a=0xabb+gg('effect_shape')*8
   assert expected==bank[a:a+8],(phase,clock,'shape')
  checked+=1
report['explosion']={'states':checked,'mismatches':0}
# Both fade paths, every animation phase and timer seed. These compare actual
# original bitmap bytes, not a second copy of the mask algorithm.
mask_cases=0
for held in (0,1):
 for age in (126,128,192,254):
  for f in (1,3,5,7,9,11,13,15):
   for seed in (0,1,0x35,0xa7,0xff):
    for i in range(64):ir[i]=0
    for i in range(256):ex[i]=0
    ir[24]=0x25;ir[0x25]=f;ir[0x32]=age if held else 0;ir[0x36]=age
    ex[0x75]=176;ex[0x74]=50;ex[0x73]=0x28
    for i in range(8):ex[0x4b-i]=255
    for k,v in {'frame':f,'pick_life':age if held else 0,'item_age':age,'item_kind':1,'item_y':176,'item_x':50,'entropy_value':seed,'entropy_fraction':0}.items():gp(k,v)
    # Freeze oracle time: injected timer value is shared by original and model.
    h.lib.retro_debug_set_timer(seed)
    h.lib.retro_debug_invoke(1,0x527,10000);g.item_step()
    if ex[0x75]==248:continue
    mask=list((C.c_ubyte*8).in_dll(g,'item_mask'))
    glyph=bytes([255]*8) if held else bank[0x596+gg('item_shape')*8:0x59e+gg('item_shape')*8]
    expected=bytes(ex[0x44:0x4c])[::-1];actual=bytes(a&b for a,b in zip(glyph,mask))
    assert expected==actual,(held,age,f,seed,expected.hex(),actual.hex())
    mask_cases+=1
report['item_fade']={'bitmap_checks':mask_cases,'mismatches':0}
(p/'fidelity.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
# Spawn decisions at every timer prescaler phase. Match original routine
# execution, including its write-back and later timer reads.
spawn_cases=0
for case in range(4096):
 seed=rng.randrange(256);phase=case&31;difficulty=rng.randrange(256);cursor=rng.randrange(1,4);slot=rng.randrange(5);py=rng.randrange(28,181)
 for i in range(64):ir[i]=0
 for i in range(256):ex[i]=0
 ir[0x22]=difficulty;ir[0x3b]=cursor;ex[0x7d]=py
 for i in range(5):ex[0x6c-4*i]=20+i*20;ex[0x6d-4*i]=100 if i<slot else 248
 for i,y in enumerate([178,106,34]):ex[0x51+4*i]=y;ex[0x50+4*i]=77;ex[0x4e+4*i]=128
 for k,v in {'frame':0,'difficulty':difficulty,'door_cursor':cursor,'pete_y':py,'entropy_value':seed,'entropy_fraction':phase}.items():gp(k,v)
 for k in ['rock_x','rock_y','rock_x_energy','rock_y_energy','rock_fall','rock_decay']:
  a=(C.c_ubyte*5).in_dll(g,k)
  for i in range(5):a[i]=ex[0x6c-4*i] if k=='rock_x' else ex[0x6d-4*i] if k=='rock_y' else 0
 h.lib.retro_debug_invoke_timed(0,0x474,seed,phase);g.spawn_rock()
 expected=(ex[0x6c-4*slot],ex[0x6d-4*slot],ex[0x1a+3*slot],ex[0x1b+3*slot],ir[0x3b])
 actual=tuple((C.c_ubyte*5).in_dll(g,k)[slot] for k in ['rock_x','rock_y','rock_x_energy','rock_y_energy'])+(gg('door_cursor'),)
 assert expected==actual,(case,seed,phase,difficulty,cursor,slot,expected,actual)
 spawn_cases+=1
report['spawn_randomness']={'cases':spawn_cases,'prescaler_phases':32,'mismatches':0,'scope':'given the same timer phase at routine entry; full-game phase replay remains unverified'}
(p/'fidelity.json').write_text(json.dumps(report,indent=2));print(report['spawn_randomness'],flush=True)
