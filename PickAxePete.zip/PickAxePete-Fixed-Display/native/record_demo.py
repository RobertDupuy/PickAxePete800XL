"""Record the actual emulator output with POKEY audio, at native NTSC cadence."""
from pathlib import Path
import sys, subprocess, wave, ctypes as C
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'tools'))
from core_host import Host
out=Path(sys.argv[1]).resolve();out.parent.mkdir(parents=True,exist_ok=True)
h=Host(root/'tools/atari800core/atari800_libretro.so',root/'reference',{'atari800_system':'800XL (64K)','atari800_ntscpal':'NTSC','atari800_internalbasic':'disabled'})
h.load(root/'native/build/PickAxePete-display-demo.xex');h.run(180);h.audio=[]
video=out.with_suffix('.silent.mp4');wav=out.with_suffix('.wav')
pipe=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','400x300','-r','59.922745','-i','-','-vf','scale=1200:900:flags=neighbor','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-an',str(video)],stdin=subprocess.PIPE)
for frame in range(960):
 h.run();pipe.stdin.write(h.video.tobytes())
 if frame==260:h.savepng(root/'native/build/display-preview.png')
pipe.stdin.close();assert pipe.wait()==0
with wave.open(str(wav),'wb') as f:
 f.setnchannels(2);f.setsampwidth(2);f.setframerate(44100);f.writeframes(b''.join(h.audio))
subprocess.run(['ffmpeg','-v','error','-y','-i',str(video),'-i',str(wav),'-c:v','copy','-c:a','aac','-b:a','192k','-shortest','-movflags','+faststart',str(out)],check=True)
video.unlink();wav.unlink();print(out)
