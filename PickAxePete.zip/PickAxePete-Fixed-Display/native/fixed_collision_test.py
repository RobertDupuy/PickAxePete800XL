"""Real GTIA checks: Pete on P0, boulders on PF2, item P2 and ladder P1."""
from pathlib import Path
import sys,ctypes as C,json
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'tools'))
from core_host import Host
p=root/'native/build';lab={x.split()[2][1:]:int(x.split()[1],16) for x in (p/'labels.txt').read_text().splitlines()}
h=Host(root/'tools/atari800core/atari800_libretro.so',root/'reference',{'atari800_system':'800XL (64K)','atari800_ntscpal':'NTSC','atari800_internalbasic':'disabled'})
h.load(p/'PickAxePete-native-64K.xex');h.run(160)
h.joy={0};h.run(3);h.joy=set();h.run(40)
r=(C.c_ubyte*65536).from_address(h.lib.retro_get_memory_data(2))
r[lab['_game_tick']]=0x60
r[lab['sound_update']]=0x60
results=[]
def put(k,v):r[lab['_'+k]]=v
for case in ['clear','boulder','item','ladder','grid','door','five_boulders','gray_pete','effect','wall']:
 for k,v in {'pete_x':76,'pete_y':130,'pete_shape':10,'pick_life':0,'has_key':0,'item_kind':0,'ladder_y':248,'effect_y':248,'frame':1}.items():put(k,v)
 for i in range(8):r[lab['_item_mask']+i]=255
 for i in range(5):r[lab['_rock_x']+i]=r[lab['_rock_y']+i]=248;r[lab['_rock_fall']+i]=0
 if case in ('boulder','gray_pete'):r[lab['_rock_x']]=76;r[lab['_rock_y']]=130
 if case=='gray_pete':put('has_key',1);put('frame',5)
 if case=='item':
  for k,v in {'item_kind':2,'item_x':76,'item_y':130,'item_shape':4}.items():put(k,v)
 if case=='ladder':
  for k,v in {'ladder_x':76,'ladder_y':130,'ladder_shape':3}.items():put(k,v)
 if case=='grid':put('pete_y',144)
 if case=='door':put('pete_y',106)
 if case=='wall':put('pete_x',8)
 if case=='effect':
  for k,v in {'effect_x':76,'effect_y':130,'effect_shape':1,'effect_size':1,'effect_color':7}.items():put(k,v)
 if case=='five_boulders':
  for i,x in enumerate([10,34,110,134,76]):r[lab['_rock_x']+i]=x;r[lab['_rock_y']+i]=130
 # Sample committed state, never partially rebuilt foreground arrays.
 h.run(10)
 stop=lab['frame_complete']+5
 resume=bytes(r[stop+1:stop+3])
 r[stop+1]=stop&255;r[stop+2]=stop>>8
 h.run(4)
 actual=[int(r[lab['_pete_hits_'+k]]!=0) for k in ['rock','item','ladder']]
 expected=[int(case in ['boulder','five_boulders','gray_pete']),int(case=='item'),int(case=='ladder')]
 result={'case':case,'contacts':actual,'expected':expected}
 print(result,flush=True);assert actual==expected,result
 results.append(result)
 r[stop+1:stop+3]=resume
(p/'fixed-collision-test.json').write_text(json.dumps({'cases':results,'mismatches':0},indent=2))
