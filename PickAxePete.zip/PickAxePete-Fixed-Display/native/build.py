from pathlib import Path
import subprocess,struct,os
root=Path(__file__).resolve().parents[1]
cc=Path(os.environ.get('CC65_BIN',str(root/'tools/cc65/bin')))
out=root/'native/build';out.mkdir(exist_ok=True)
def run(args):subprocess.run([str(x) for x in args],cwd=root,check=True)
run(['python3','native/extract_assets.py'])
run(['python3','native/generate_fixed.py'])
run(['python3','native/generate_hud.py'])
run(['python3','native/generate_select.py'])
run([cc/'cc65','-t','none','-Oirs','--static-locals','-g','native/game.c','-o',out/'game.s'])
for f in ('platform','assets','hud_generated','terrain','objects','contacts','audio','entropy','select'):
 run([cc/'ca65','-g','-I','native','native/'+f+'.s','-o',out/(f+'.o')])
run([cc/'ca65','-g','-I','native',out/'game.s','-o',out/'game.o'])
run([cc/'ld65','-C','native/link.cfg','-m',out/'map.txt','-Ln',out/'labels.txt','--dbgfile',out/'game.dbg','-o',out/'game.bin',out/'platform.o',out/'game.o',out/'assets.o',out/'hud_generated.o',out/'terrain.o',out/'objects.o',out/'contacts.o',out/'audio.o',out/'entropy.o',out/'select.o',cc.parent/'lib/none.lib'])
b=(out/'game.bin').read_bytes()
e=(out/'extra.bin').read_bytes()
aux=(out/'aux.bin').read_bytes()
x=b'\xff\xff'+struct.pack('<HH',0x1000,0x1000+len(b)-1)+b+struct.pack('<HH',0xa000,0xa000+len(e)-1)+e+struct.pack('<HH',0x8000,0x8000+len(aux)-1)+aux+struct.pack('<HHH',0x2e0,0x2e1,0x1000)
(out/'PickAxePete-native-64K.xex').write_bytes(x)
print('Native executable:',len(x),'bytes; code/data ends at',hex(0x1000+len(b)))

labels={line.split()[2][1:]:int(line.split()[1],16) for line in (out/'labels.txt').read_text().splitlines()}
demo=bytearray(x);at=6+labels['_game_tick']-0x1000
demo[at:at+3]=bytes([0x4c,labels['demo_tick']&255,labels['demo_tick']>>8])
(out/'PickAxePete-display-demo.xex').write_bytes(demo)
