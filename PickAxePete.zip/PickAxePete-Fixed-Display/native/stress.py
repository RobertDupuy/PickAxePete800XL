"""Exercise input, all layouts and deliberately crowded playfield states."""
import sys,ctypes as C,json,numpy as np
from pathlib import Path
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'tools'))
from core_host import Host
p=root/'native/build';lab={x.split()[2][1:]:int(x.split()[1],16) for x in (p/'labels.txt').read_text().splitlines()}
h=Host(root/'tools/atari800core/atari800_libretro.so',root/'reference',{'atari800_system':'800XL (64K)','atari800_ntscpal':'NTSC','atari800_internalbasic':'disabled'})
h.load(p/'PickAxePete-native-64K.xex');h.run(180)
h.joy={0};h.run(3);h.joy=set();h.run(40)
ram=(C.c_ubyte*65536).from_address(h.lib.retro_get_memory_data(2))
def get(k):return ram[lab[k]]
def put(k,v):ram[lab[k]]=v
names=['frame_begin','frame_complete','vbi_begin','vbi_end','scene_setup','commit_hud']
for i,k in enumerate(names):h.lib.retro_debug_watch(i,lab[k])
h.lib.retro_debug_log.restype=C.c_void_p
reports=[]
for layout in range(0 if len(sys.argv)>1 else 10):
 h.keys={48+layout};h.run(3);h.keys=set();h.run(40)
 assert get("_mine_number")==layout,(layout,get("_mine_number"))
 before=get('missed_frames')+256*ram[lab['missed_frames']+1]
 h.lib.retro_debug_reset_log()
 for f in range(600):
  h.joy=([{7},{7,0},{4},{6},{6,0},{5},set()][(f//31)%7])
  h.run()
 n=h.lib.retro_debug_log_count();a=np.frombuffer(C.string_at(h.lib.retro_debug_log(),n*12),dtype=np.uint32).reshape(-1,3)
 missed=get('missed_frames')+256*ram[lab['missed_frames']+1]-before
 reports.append({'layout':layout,'frames':600,'ticks':int(sum(a[:,0]==0)),'scene_setups':int(sum(a[:,0]==4)),'missed_gameplay_frames':missed})
 print(reports[-1],flush=True)
# All five rocks, high velocities, all four players visible, continuous scoring.
h.keys={49};h.run(3);h.keys=set();h.run(40);h.joy=set()
before=get('missed_frames')+256*ram[lab['missed_frames']+1]
h.lib.retro_debug_reset_log()
for f in range(1200):
 put('_mode',1);put('_difficulty',255);put('_pick_life',200);put('_score_pending',30)
 put('_effect_phase',1);put('_effect_clock',3);put('_effect_x',100);put('_effect_y',80)
 for i in range(5):
  if ram[lab['_rock_y']+i]==248:
   ram[lab['_rock_x']+i]=[20,46,72,106,136][i];ram[lab['_rock_y']+i]=[36,60,84,132,180][i]
  ram[lab['_rock_x_energy']+i]=128+((f+i)&1)
  ram[lab['_rock_y_energy']+i]=128+((f//30+i)&1)
  ram[lab['_rock_fall']+i]=0
 h.joy={0,7 if (f//60)&1 else 6}
 h.run()
n=h.lib.retro_debug_log_count();a=np.frombuffer(C.string_at(h.lib.retro_debug_log(),n*12),dtype=np.uint32).reshape(-1,3)
missed=get('missed_frames')+256*ram[lab['missed_frames']+1]-before
reports.append({'scenario':'five fast rocks, four players, continuous scoring','frames':1200,'ticks':int(sum(a[:,0]==0)),'scene_setups':int(sum(a[:,0]==4)),'missed_gameplay_frames':missed})
print(reports[-1],flush=True)
starts={};measures={'foreground':[],'vbi':[]}
for idx,clock,y in a:
 if idx in (0,2):starts[int(idx)]=int(clock)
 if idx in (1,3) and int(idx)-1 in starts:
  measures['foreground' if idx==1 else 'vbi'].append((int(clock)-starts.pop(int(idx)-1),int(y)))
print({k:max(v) for k,v in measures.items()},flush=True)
(p/'stress-timing.json').write_text(json.dumps(measures))
h.savepng(p/'stress.png');(p/'stress.json').write_text(json.dumps(reports,indent=2))
