# Pick Axe Pete — fixed display branch for NTSC Atari 800XL, 64 KB

This branch implements the approved dedicated-player allocation, reconnects it
to the native ROM-checked game logic, and passes the display timing gate.

Load `PickAxePete-800XL-fixed-display.xex` with BASIC disabled. The original
multicolored SELECT GAME lettering appears at startup. Press 0–9 to start that
mine immediately, or press joystick port 1 fire to start the default mine 0.
The joystick moves Pete; direction plus fire performs his jump/dodge.
Hold down without fire for the low pick-axe stroke. Enter the record holder name AFTER the qualifying game ends. The left-hand score and arrow point to its owner; the right-hand score is the current game. Leave the startup question marks alone. Name entry follows the Odyssey2: ?????? requests the record holder's name after a completed score equals or exceeds the record. Type up to six letters; use spaces to fill a shorter name. Entry stops advancing at the sixth position and never wraps to erase the beginning. Return/Enter is an optional shortcut to fill unused positions and lock the name against further typing. A lower score preserves the existing name; a qualifying score reopens entry for whoever earned it. No player-change key is needed. Names last until reset or power-off.

`PickAxePete-display-demo.xex` is the autonomous display-only test: five moving
boulders, Pete, ladder, item and effect, overlapping objects, changing colors,
and the game's POKEY sound IRQ. The accompanying MP4 records this demo directly
from the Atari emulator at its native NTSC cadence.

`PickAxePete-gameplay-fixes.mp4` records startup, the downward pick strike,
and a complete door transition with real emulator audio. Its footer identifies
the controlled boulder/door fixtures; actual joystick input and the running
game handle the strike, three-point award, transition, and return to play.

## Display and execution

| Resource | Assignment |
|---|---|
| P0 | Pete |
| P1 | Ladder |
| P2 | Pick/key |
| P3 | Explosion/effect |
| ANTIC 4 character graphics | Mine, doors and all five boulders |
| M0/M1 in fifth-player mode | Two stationary side walls |

There is no player multiplexer or software-sprite bitmap fallback in this
build. The OS and BASIC are disabled. The foreground advances one game tick
and prepares small changes. A fixed DLI immediately after the final visible
floor line starts the blanking commit. Ordinary VBI is acknowledged separately.
Other fixed DLIs select the three door colors and the HUD font/palette.

There is one visible character map. Three prebuilt 1 KB character sets contain
the three boulder animation frames at every needed fine position. The selected
character set contains up to 45 working glyphs; the foreground staging area is
360 bytes. Empty-background boulder cells use the prebuilt glyphs directly.
Rock/scenery combinations are also precomputed. Rock/rock overlaps are composed
into the bounded working glyphs. Positions are held in five fixed 3×3 records.
The blanking commit restores their previous cells and installs the new ones.

The static side walls use two previously unused missiles so eight potentially
empty character rows can omit playfield DMA when no boulder occupies them.
Pete, ladder, item and effect retain their dedicated players throughout.
Player Y movement uses padded writes; X-only movement with unchanged artwork
does not rewrite the player's bitmap. Large Y jumps and disappearing objects
clear the old span. All four players remain usable on the same scanline.

Pete/boulder contact uses P0PF's PF2 bit. Pete/item and Pete/ladder contacts use
P0PL's P2 and P1 bits. Mine, door, wall and effect contacts do not masquerade as
boulder contact. The native terrain and original proximity rules remain intact.

The sound interpreter and noise recurrence are preserved. IRQ-owned noise state
was moved to reserved zero-page bytes $64–$69 to shorten the interrupt. Its
output-bit sequence was checked again after that change.

## Door and HUD fixes

The original ROM does choose all eight door colors. Bank 0 $466–$46e uses the
timer's bits 1–3, without excluding zero. Odyssey² characters and sprites use
the bright palette: color zero is gray, not black. The shared object palette
now maps zero to Atari gray, fixing disappearing doors and the same mapping
in effects and Pete's key flash. The game rules and random color selection
are unchanged. Door artwork now comes directly from character ROM glyphs
$2f (closed) and $16 (open), selected by Bank 0 $6c8–$6d3.

The line across the numbers came from a late HUD font switch. The previous
interrupt dispatcher reached WSYNC on scanline 216 and sometimes changed the
font on 217; the HUD begins on 216. Palette DLIs now preserve only A and jump
directly to the next handler. The font changes at the end of scanline 215.
The redundant font switch after the HUD is removed; the bottom floor uses
bitmap graphics. The blanking handler waits for the last floor line to finish.

`door_hud_test.py` executes 8,192 color-update cases in the original ROM,
checks 96 rendered door states, and compares 4,194,304 actual emulator HUD
pixels against the original artwork with sound IRQs active. All pass. These
screen-pixel checks cover the raster defect that the earlier memory-only
renderer/HUD checks could not detect.

## Startup, mine entry, and downward pick fixes

The SELECT GAME screen uses the Odyssey² BIOS character sequence at $2f2–$2fc
and the original character ROM, including its spacing, doubled rows, and
seven simultaneous color groups. Atari hues approximate the original palette.
Startup has its own display list and VBI pacing. As in the original, pressing
0–9 immediately starts the corresponding mine. Fire also starts default mine 0.

The white rectangle during mine entry was a stale ladder. The shared object
clear now hides it; only new-round setup restores the initial ladder position.
The transition test checks 246 frames, finds no residual P1/P2/P3 bitmap bytes,
and confirms normal gameplay returns with the ladder restored.

All 37 Pete frames and four held-pick frames were already extracted. The
missing behavior was Bank 0 $a99–$af1's stationary vertical-input handling.
That rule now updates the pick's position, facing, and low/raised artwork.
Drawing and boulder contact use the same stored pick position. Down without
fire lowers the stroke and can break a boulder below Pete for three points.

`held_pick_test.py` compares 3,888 combinations of direction, fire, facing,
jump, floor/gap state and animation phase with the original 8048 routine,
the C model, and linked Atari 6502 code, including rendered axe bytes. It
also verifies all 37 Pete and four axe artwork frames against the ROM and
tests a boulder outside the raised stroke but inside the lowered stroke.
`startup_transition_test.py` compares actual title pixels with the original
emulator and verifies immediate startup for every numeric key, fire-to-start,
and transition cleanup.

## Measured verification

Timing uses the instrumented Atari800 core in NTSC 800XL 64K mode. Its wall
clocks include ANTIC DMA stalls and active POKEY interrupts.

| Test | Result |
|---|---|
| Display-only demo, 10,000 video frames | 10,000 game tick entries; 0 missed frames; 0 blanking overruns |
| Worst foreground duration in that run | 21,767 Atari clocks |
| Minimum preparation margin before commit | 1,294 clocks, about 0.72 ms |
| Worst blanking duration | 7,617 clocks |
| Latest blanking completion after frame wrap | Scanline 39; the playfield starts at 40 |
| HUD font-switch timing | Scanline 215, before the first HUD line at 216 |
| Ten starting layouts, 600 frames each | 0 missed gameplay frames in every layout |
| Five fast boulders, effects and continuous scoring, 1,200 frames | 0 missed gameplay frames |
| Character pixels and player-memory bytes | 7,296,000 comparisons; 0 mismatches |
| Hardware collision scenarios | 10 cases; 0 mismatches |
| HUD artwork | 114,688 pixels; 0 mismatches |
| Original ROM terrain / Pete / boulder comparisons | 20,000 / 10,000 / 5,000 cases; 0 mismatches |
| Linked 6502 game logic vs. rule model | 20,000 terrain cases and 5,000 integrated ticks across 66 state fields; 0 mismatches |
| Sound interpreter / noise sequence | 1,300 interpreter steps and 15,000 output-bit checks; 0 mismatches |
| Held-pick ROM / C / linked 6502 comparisons | 3,888 cases; 0 position, direction or artwork mismatches |
| SELECT GAME pixels and input | Original glyphs match; all 0–9 keys start their mine immediately; fire starts mine 0 |
| Mine-entry display | 246 frames checked; no stale objects; gameplay restored |

Some 600-frame sample windows contain 599 foreground-entry events because a
blanking handler can finish on either side of the emulator's frame boundary.
The missed-frame counter remains zero; this is a measurement-window boundary,
not a skipped game tick. The longer autonomous test records exactly 10,000
entries in 10,000 frames. Raw reports are included under `native/build/`.

## Scope and remaining fidelity work

The display performance requirement is met in the tested scenarios. The native
game logic remains ROM-checked, with the missing held-pick control rule restored
and object clearing corrected for mine entry. This is not certification of an
exact Odyssey² replica.
Falling boulders currently share the normal boulder palette; the original uses
a different palette in that state. The HUD starts one scanline lower than in
the earlier mixed-mode renderer. Full original-game random-phase replay,
whole-waveform sound equivalence and exhaustive original collision timing
remain unverified. The floor-removal routine still lacks a dedicated ROM oracle.
PAL and a physical 800XL have not been tested. Unusual states outside the tested
movement ranges are not covered by the timing claim.
The worst blanking case now finishes one scanline before the playfield; that
is a narrow measured margin, not a claim of spare capacity for more work.

## Build and source

From the project root:

```sh
python3 native/build.py
```

The included cc65 binaries are Linux binaries. `CC65_BIN` can select a compatible
toolchain with `../lib/none.lib`. Verification scripts use Python, NumPy, Pillow
and py65; the original-ROM oracle also uses a C compiler. Emulator cores and
their existing license/provenance material are included.

The build produces the game and standalone demo XEX files in `native/build/`.
`generate_fixed.py`, `fixed_renderer.s`, `display_source.s`, and `display_demo.s`
define the new display. `generate_select.py` defines the BIOS-style startup.
`game.c`, `terrain.s`, `objects.s`, and `contacts.s` contain the game rules.
`generate_hud.py` and `audio.s` contain the
shortened HUD and sound paths. No multiplexer source is required by this build.

The original ROM/disassemblies and asset provenance are included for the same
private comparison/build workflow as the parent branch. Original artwork and
ROM contents retain their original ownership. Tool licenses are in `licenses/`.
