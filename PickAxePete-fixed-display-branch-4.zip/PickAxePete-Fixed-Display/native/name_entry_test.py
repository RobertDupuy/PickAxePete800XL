"""Original-ROM keyboard comparison and Atari record-holder regression."""
from pathlib import Path
import sys, ctypes as C
import numpy as np
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools'))
from core_host import Host
lab={x.split()[2][1:]:int(x.split()[1],16) for x in (root/'native/build/labels.txt').read_text().splitlines()}
o=Host(root/'tools/o2em/o2em_libretro.so',root/'reference');o.load(root/'reference/pickaxe.bin');o.run(180)
o.lib.retro_debug_ram.argtypes=[C.c_int];o.lib.retro_debug_ram.restype=C.POINTER(C.c_ubyte)
e=o.lib.retro_debug_ram(1)
h=Host(root/'tools/atari800core/atari800_libretro.so',root/'reference',{'atari800_system':'800XL (64K)','atari800_ntscpal':'NTSC','atari800_internalbasic':'disabled'})
h.load(root/'native/build/PickAxePete-native-64K.xex');h.run(180)
r=(C.c_ubyte*65536).from_address(h.lib.retro_get_memory_data(2))
def key(host,c,fire=False):
 host.keys={ord(c)};host.joy={0} if fire else set();host.run(3)
 host.keys=set();host.joy=set();host.run(8)
def name():return bytes(r[lab['_name_chars']:lab['_name_chars']+6])
for host in (o,h):key(host,'0')
for c in 'mark    a ':
 for host in (o,h):key(host,c)
 assert name()==bytes(e[5:11]), (c,name(),bytes(e[5:11]))
expected=bytes([38,32,19,31,12,12])
assert name()==expected
key(h,'\r');assert r[lab['_name_cursor']]==255
pixels=h.video[238:252,158:254].copy()
for n in range(24):
 key(h,' ',True);assert name()==expected
 assert np.array_equal(pixels,h.video[238:252,158:254])
# Controlled score fixtures exercise the real comparison/restart path.
def finish(value):
 for i in range(4):r[lab['_score']+i]=int(f'{value:04d}'[i])
 key(h,'0')
finish(9)
assert name()==bytes([13]*6) and r[lab['_name_cursor']]==0
assert bytes(r[lab['_high_score']:lab['_high_score']+4])==bytes([0,0,0,9])
for c in 'mark':key(h,c)
key(h,'\r');assert name()==expected
finish(8);assert name()==expected and r[lab['_name_cursor']]==255
finish(9);assert name()==bytes([13]*6) and r[lab['_name_cursor']]==0
for c in 'john  ':key(h,c)
john=name();assert john!=expected and 13 not in john
finish(8);assert name()==john
finish(10);assert name()==bytes([13]*6)
for c in 'mark':key(h,c)
key(h,'\r')
for n in range(8):key(h,' ',True)
assert name()==expected
h.savepng(root/'native/build/name-entry-saved.png')
print('PASS: real Odyssey2/Atari keyboard parity; no wrap; optional Return; Space/fire protection; lower/equal/higher record cases; new holder JOHN without a special key')
