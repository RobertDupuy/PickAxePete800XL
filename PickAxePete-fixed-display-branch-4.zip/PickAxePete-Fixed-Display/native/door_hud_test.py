"""ROM door-color oracle plus actual NTSC door pixels and HUD raster checks."""
from pathlib import Path
import ctypes as C
import json
import re
import sys
import numpy as np

root = Path(__file__).resolve().parents[1]
p = root / 'native/build'
sys.path.insert(0, str(root / 'tools'))
from core_host import Host

labels = {s.split()[2][1:]: int(s.split()[1], 16)
          for s in (p / 'labels.txt').read_text().splitlines()}
raw = (root / 'reference/o2em-cset.c').read_text().split('uint8_t cset[512]= {')[1].split('}')[0]
font = bytes(int(x, 16) for x in re.findall(r'0x([a-fA-F0-9]+)', raw))
cart = (root / 'reference/pickaxe.bin').read_bytes()
bank0 = bytes(1024) + cart[2048:]
assert bank0[0x6cd:0x6cf] == bytes([0xbd, 0x16])
assert bank0[0x6d1:0x6d3] == bytes([0xbd, 0x2f])

o2 = Host(root / 'tools/o2em/o2em_libretro.so', root / 'reference')
o2.load(root / 'reference/pickaxe.bin')
o2.lib.retro_debug_ram.restype = C.c_void_p
ir = (C.c_ubyte * 64).from_address(o2.lib.retro_debug_ram(0))
ex = (C.c_ubyte * 256).from_address(o2.lib.retro_debug_ram(1))
seen = set()
rom_cases = 0
for timer in range(256):
    for old_color in range(8):
        for flags in (0x80, 0x81, 0xa0, 0xa1):
            ir[24] = 0x4e  # RB1 R0: first door's attribute byte.
            ex[0x4e] = flags | (old_color << 1)
            o2.lib.retro_debug_set_timer(timer)
            # Run the seven original instructions $466-$46e. Stop before
            # its absolute jump, outside this isolated color-update block.
            pc = o2.lib.retro_debug_invoke(0, 0x466, 7)
            assert pc == 0x46f
            assert ex[0x4e] == (flags & 0x81) | (timer & 14)
            seen.add((ex[0x4e] >> 1) & 7)
            rom_cases += 1
assert seen == set(range(8))
o2.lib.retro_unload_game()
o2.lib.retro_deinit()

h = Host(root / 'tools/atari800core/atari800_libretro.so', root / 'reference',
         {'atari800_system': '800XL (64K)', 'atari800_ntscpal': 'NTSC',
          'atari800_internalbasic': 'disabled'})
h.load(p / 'PickAxePete-native-64K.xex')
h.run(180)
h.joy = {0}
h.run(3)
h.joy = set()
h.run(40)
r = (C.c_ubyte * 65536).from_address(h.lib.retro_get_memory_data(2))
r[labels['_game_tick']] = 0x60  # Only the controlled visual fixture is frozen.

def put(name, value):
    r[labels['_' + name]] = value

for name in ('pete_y', 'ladder_y', 'item_y', 'effect_y'):
    put(name, 248)
for i in range(5):
    r[labels['_rock_y'] + i] = 248
put('pick_life', 0)
put('item_kind', 0)
h.run(8)
background = h.video[72, 180].copy()
door_cases = 0
gray = None
for color in range(8):
    for opened in (0, 1):
        for phase in (0, 4):
            put('frame', phase)
            for door in range(3):
                r[labels['_door_color'] + door] = color
                r[labels['_door_open'] + door] = opened
            h.run(5)
            glyph = 22 if opened and phase else 47
            mask = np.array([[bool(font[glyph * 8 + y // 2] & (128 >> x))
                              for x in range(8) for _ in range(2)]
                             for y in range(14)])
            for source_y in (178, 106, 34):
                # Native source -> physical ANTIC +16 -> libretro image +22.
                pixels = h.video[source_y + 38:source_y + 52, 198:214]
                actual = np.any(pixels != background, axis=2)
                assert np.array_equal(actual, mask), (color, opened, phase, source_y)
                assert len(np.unique(pixels[mask], axis=0)) == 1
                if color == 0:
                    gray = pixels[mask][0].tolist()
                door_cases += 1
h.savepng(p / 'door-colors-verified.png')

# Compare all 16 HUD scanlines to the original character ROM, including the
# first line that used to contain boulder-font fragments. Keep all players
# outside the HUD, vary boulder font banks every frame, and run sound IRQs.
for name, value in {'pete_x': 50, 'pete_y': 100, 'pete_shape': 18,
                    'ladder_x': 90, 'ladder_y': 100, 'ladder_shape': 2,
                    'item_kind': 2, 'item_x': 120, 'item_y': 100, 'item_shape': 4,
                    'effect_x': 20, 'effect_y': 100, 'effect_shape': 1,
                    'effect_size': 1, 'effect_color': 0}.items():
    put(name, value)
for i in range(5):
    r[labels['_rock_x'] + i] = 28 + i * 24
    r[labels['_rock_y'] + i] = 60 + i * 18
xs = [17, 25, 33, 41, 113, 121, 129, 137, 57, 65, 73, 81, 89, 97]
chars = [0] * 8 + [13] * 6
ink = np.zeros((16, 256), dtype=np.uint8)
for field, (x0, ch) in enumerate(zip(xs, chars)):
    for y in range(14):
        for x in range(8):
            if font[ch * 8 + y // 2] & (128 >> x):
                ink[y, (x0 + x - 17) * 2:(x0 + x - 16) * 2] = 2 if field < 4 else 3
for y in range(14):
    for x in range(8):
        if font[54 * 8 + y // 2] & (128 >> x):
            ink[y, (49 + x - 17) * 2:(49 + x - 16) * 2] = 2
h.run(8)
colors = {0: background}
for code in (2, 3):
    y, x = np.argwhere((ink == code) & (np.arange(16)[:, None] >= 4))[0]
    colors[code] = h.video[238 + y, 74 + x].copy()
    assert np.any(colors[code] != background)
expected = np.empty((16, 256, 3), dtype=np.uint8)
for code, color in colors.items():
    expected[ink == code] = color
h.lib.retro_debug_watch(0, labels['hud_font_switch'])
h.lib.retro_debug_reset_log()
for frame in range(1024):
    put('frame', frame & 255)
    put('sound_event', 0x6a if frame % 32 == 0 else 0)
    h.run()
    assert np.array_equal(h.video[238:254, 74:330], expected), frame
h.lib.retro_debug_log.restype = C.c_void_p
count = h.lib.retro_debug_log_count()
events = np.frombuffer(C.string_at(h.lib.retro_debug_log(), count * 12),
                       dtype=np.uint32).reshape(-1, 3)
assert count == 1024 and np.all(events[:, 2] == 215)
h.savepng(p / 'hud-raster-verified.png')
report = {'rom_color_updates': rom_cases, 'rom_colors': sorted(seen),
          'rendered_door_states': door_cases, 'gray_door_rgb': gray,
          'hud_frames_with_sound': 1024, 'hud_pixel_checks': 1024 * 16 * 256,
          'hud_font_switch_scanline': 215, 'first_hud_scanline': 216,
          'mismatches': 0}
(p / 'door-hud-test.json').write_text(json.dumps(report, indent=2))
print(report)
